; CYX Dayz 启动器 - Inno Setup 安装脚本
; 用 build_installer.ps1 编译，或 ISCC.exe 直接编译本文件

#define MyAppName "CYX Dayz 启动器"
#define MyAppVersion "1.2.9"
#define MyAppPublisher "CYX"
#define MyAppExeName "CYX Dayz 启动器.exe"

[Setup]
AppId={{A8C7E2F1-4B3D-4E9A-9C21-7D6E5F4A3B2C}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\CYX Dayz Launcher
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
AllowNoIcons=yes
OutputDir=..\installer_output
OutputBaseFilename=CYX_Dayz_启动器_安装包
SetupIconFile=..\assets\app_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
VersionInfoVersion={#MyAppVersion}
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription={#MyAppName}
VersionInfoProductName={#MyAppName}
CloseApplications=force
RestartApplications=no

[Languages]
Name: "chinesesimplified"; MessagesFile: "Languages\ChineseSimplified.isl"

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; GroupDescription: "附加选项:"; Flags: checkedonce

[Files]
; 主程序：始终覆盖为最新
Source: "..\dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
; 服务器列表：随版本更新（服主改 IP/名称时玩家重装即可同步）
Source: "..\dist\server_config.json"; DestDir: "{app}"; Flags: ignoreversion
; 玩家本地配置：仅首次安装写入，升级不覆盖角色名/目录等
Source: "defaults\launcher_config.json"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{group}\卸载 {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "立即运行 {#MyAppName}"; Flags: nowait postinstall skipifsilent unchecked

[Code]
var
  StartupCheckBox: TNewCheckBox;

function StartupAlreadyEnabled: Boolean;
var
  RunKey: String;
  LinkPath: String;
begin
  RunKey := 'Software\Microsoft\Windows\CurrentVersion\Run';
  LinkPath := ExpandConstant('{userstartup}\{#MyAppName}.lnk');
  Result := RegValueExists(HKCU, RunKey, '{#MyAppName}') or FileExists(LinkPath);
end;

procedure InitializeWizard;
begin
  StartupCheckBox := TNewCheckBox.Create(WizardForm);
  StartupCheckBox.Parent := WizardForm.FinishedPage;
  StartupCheckBox.Caption := '开机启动 {#MyAppName}';
  StartupCheckBox.Checked := False;
  StartupCheckBox.Visible := False;
end;

procedure LayoutFinishedPage;
var
  Gap: Integer;
begin
  Gap := ScaleY(10);
  StartupCheckBox.Left := WizardForm.FinishedLabel.Left;
  StartupCheckBox.Width := WizardForm.FinishedLabel.Width;
  StartupCheckBox.Top := WizardForm.FinishedLabel.Top + WizardForm.FinishedLabel.Height + Gap;
  WizardForm.RunList.Top := StartupCheckBox.Top + ScaleY(22);
  WizardForm.RunList.Left := StartupCheckBox.Left;
  StartupCheckBox.BringToFront;
end;

procedure CurPageChanged(CurPageID: Integer);
begin
  if CurPageID = wpFinished then
  begin
    LayoutFinishedPage;
    StartupCheckBox.Checked := StartupAlreadyEnabled;
    StartupCheckBox.Visible := True;
  end;
end;

procedure ApplyStartupPreference;
var
  RunKey: String;
  ExePath: String;
  LinkPath: String;
begin
  RunKey := 'Software\Microsoft\Windows\CurrentVersion\Run';
  ExePath := ExpandConstant('"{app}\{#MyAppExeName}"');
  LinkPath := ExpandConstant('{userstartup}\{#MyAppName}.lnk');
  if StartupCheckBox.Checked then
  begin
    RegWriteStringValue(HKCU, RunKey, '{#MyAppName}', ExePath);
    CreateShellLink(
      LinkPath,
      '',
      ExpandConstant('{app}\{#MyAppExeName}'),
      '',
      ExpandConstant('{app}'),
      '',
      0,
      SW_SHOWNORMAL);
  end
  else
  begin
    RegDeleteValue(HKCU, RunKey, '{#MyAppName}');
    if FileExists(LinkPath) then
      DeleteFile(LinkPath);
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssDone then
    ApplyStartupPreference;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  LinkPath: String;
begin
  if CurUninstallStep = usPostUninstall then
  begin
    RegDeleteValue(HKCU, 'Software\Microsoft\Windows\CurrentVersion\Run', '{#MyAppName}');
    LinkPath := ExpandConstant('{userstartup}\{#MyAppName}.lnk');
    if FileExists(LinkPath) then
      DeleteFile(LinkPath);
  end;
end;
