from cyx_launcher.updater import maybe_run_update_helper


if __name__ == "__main__":
    helper_result = maybe_run_update_helper()
    if helper_result is not None:
        raise SystemExit(helper_result)

    from cyx_launcher.ui import run_app
    from cyx_launcher.single_instance import (
        acquire_single_instance,
        activate_existing_window,
        release_single_instance,
    )

    if not acquire_single_instance():
        activate_existing_window()
    else:
        try:
            run_app()
        finally:
            release_single_instance()
