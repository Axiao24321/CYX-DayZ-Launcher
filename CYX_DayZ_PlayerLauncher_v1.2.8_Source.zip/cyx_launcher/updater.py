from __future__ import annotations

import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import requests


ProgressCallback = Callable[[int, int], None]


@dataclass(frozen=True)
class UpdatePart:
    url: str
    sha256: str
    size: int
    mirrors: tuple[str, ...] = ()


@dataclass(frozen=True)
class UpdateManifest:
    version: str
    mandatory: bool
    url: str
    sha256: str
    size: int
    notes: str = ""
    parts: tuple[UpdatePart, ...] = ()
    mirrors: tuple[str, ...] = ()


def version_tuple(version: str) -> tuple[int, ...]:
    text = str(version).strip().lstrip("vV")
    parts = text.split(".")
    if not parts or any(not p.isdigit() for p in parts):
        raise ValueError(f"无效版本号：{version}")
    return tuple(int(p) for p in parts)


def is_newer_version(candidate: str, current: str) -> bool:
    left = version_tuple(candidate)
    right = version_tuple(current)
    width = max(len(left), len(right))
    return left + (0,) * (width - len(left)) > right + (0,) * (width - len(right))


def _require_https(url: str, field: str) -> str:
    value = str(url).strip()
    parsed = urlsplit(value)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise ValueError(f"{field} 必须是有效的 HTTPS 地址")
    return value


def _parse_mirrors(raw: object, field: str, primary: str) -> tuple[str, ...]:
    if raw in (None, ""):
        return ()
    if not isinstance(raw, list):
        raise ValueError(f"{field}必须是地址列表")
    result: list[str] = []
    for index, item in enumerate(raw, start=1):
        value = _require_https(str(item), f"{field} {index}")
        if value != primary and value not in result:
            result.append(value)
    return tuple(result)


def parse_manifest(raw: dict) -> UpdateManifest:
    if not isinstance(raw, dict):
        raise ValueError("更新清单格式错误")
    version = str(raw.get("version", "")).strip()
    version_tuple(version)
    url = _require_https(str(raw.get("url", "")), "安装包地址")
    mirrors = _parse_mirrors(raw.get("mirrors"), "安装包镜像", url)
    sha256 = str(raw.get("sha256", "")).strip().lower()
    if len(sha256) != 64 or any(c not in "0123456789abcdef" for c in sha256):
        raise ValueError("更新清单的 SHA-256 无效")
    size = int(raw.get("size", 0))
    if size <= 0:
        raise ValueError("更新清单的安装包大小无效")
    parts: list[UpdatePart] = []
    raw_parts = raw.get("parts", [])
    if raw_parts:
        if not isinstance(raw_parts, list):
            raise ValueError("更新清单的分片列表无效")
        for index, item in enumerate(raw_parts, start=1):
            if not isinstance(item, dict):
                raise ValueError(f"更新分片 {index} 格式无效")
            part_url = _require_https(str(item.get("url", "")), f"更新分片 {index} 地址")
            part_mirrors = _parse_mirrors(item.get("mirrors"), f"更新分片 {index} 镜像", part_url)
            part_hash = str(item.get("sha256", "")).strip().lower()
            part_size = int(item.get("size", 0))
            if len(part_hash) != 64 or any(c not in "0123456789abcdef" for c in part_hash):
                raise ValueError(f"更新分片 {index} 的 SHA-256 无效")
            if part_size <= 0:
                raise ValueError(f"更新分片 {index} 的大小无效")
            parts.append(UpdatePart(part_url, part_hash, part_size, part_mirrors))
        if sum(part.size for part in parts) != size:
            raise ValueError("更新分片总大小与安装包大小不一致")
    return UpdateManifest(
        version=version,
        mandatory=bool(raw.get("mandatory", False)),
        url=url,
        sha256=sha256,
        size=size,
        notes=str(raw.get("notes", "")).strip(),
        parts=tuple(parts),
        mirrors=mirrors,
    )


def _cache_busted(url: str) -> str:
    parsed = urlsplit(url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query["_ts"] = str(int(time.time()))
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))


def fetch_update_manifest(url: str, timeout: float = 8.0) -> UpdateManifest:
    manifest_url = _require_https(url, "更新清单地址")
    response = requests.get(
        _cache_busted(manifest_url),
        timeout=timeout,
        headers={"User-Agent": "CYX-DayZ-Launcher-Updater/1"},
    )
    response.raise_for_status()
    try:
        raw = response.json()
    except (json.JSONDecodeError, requests.exceptions.JSONDecodeError) as exc:
        raise ValueError("更新清单不是有效 JSON") from exc
    return parse_manifest(raw)


def fetch_update_manifest_from_urls(urls: list[str] | tuple[str, ...], timeout: float = 8.0) -> UpdateManifest:
    """按配置顺序尝试更新源，主源不可用时自动切到备用源。"""
    errors: list[str] = []
    for url in urls:
        try:
            return fetch_update_manifest(url, timeout=timeout)
        except Exception as exc:
            errors.append(f"{url}: {exc}")
    if not errors:
        raise ValueError("未配置更新源")
    raise RuntimeError("所有更新源均无法连接：" + " | ".join(errors))


def download_update(
    manifest: UpdateManifest,
    progress: ProgressCallback | None = None,
    destination_dir: Path | None = None,
) -> Path:
    root = destination_dir or Path(tempfile.gettempdir()) / "CYX_DayZ_Launcher_Update"
    root.mkdir(parents=True, exist_ok=True)
    final_path = root / f"CYX_Dayz_启动器_{manifest.version}_安装包.exe"
    part_path = final_path.with_suffix(".exe.part")
    if part_path.exists():
        part_path.unlink()

    downloaded = 0
    digest = hashlib.sha256()
    chunk_paths: list[Path] = []
    try:
        sources = manifest.parts or (UpdatePart(manifest.url, manifest.sha256, manifest.size, manifest.mirrors),)
        with part_path.open("wb") as output:
            for index, source in enumerate(sources, start=1):
                chunk_path = root / f".{final_path.name}.chunk{index}"
                chunk_paths.append(chunk_path)
                source_error: Exception | None = None
                for source_url in (source.url, *source.mirrors):
                    chunk_path.unlink(missing_ok=True)
                    part_digest = hashlib.sha256()
                    part_downloaded = 0
                    try:
                        with chunk_path.open("wb") as chunk_output, requests.get(
                            source_url,
                            stream=True,
                            timeout=(10, 60),
                            headers={"User-Agent": "CYX-DayZ-Launcher-Updater/1"},
                        ) as response:
                            response.raise_for_status()
                            for chunk in response.iter_content(chunk_size=1024 * 256):
                                if not chunk:
                                    continue
                                chunk_output.write(chunk)
                                part_digest.update(chunk)
                                part_downloaded += len(chunk)
                                if part_downloaded > source.size:
                                    raise ValueError(f"更新分片 {index} 下载大小超出清单记录值")
                        if part_downloaded != source.size:
                            raise ValueError(f"更新分片 {index} 大小校验失败")
                        if part_digest.hexdigest().lower() != source.sha256:
                            raise ValueError(f"更新分片 {index} SHA-256 校验失败")
                        source_error = None
                        break
                    except Exception as exc:
                        source_error = exc
                        chunk_path.unlink(missing_ok=True)
                if source_error is not None:
                    raise source_error
                if not chunk_path.is_file():
                    raise RuntimeError(f"更新分片 {index} 的所有镜像均下载失败")

                with chunk_path.open("rb") as chunk_input:
                    while True:
                        chunk = chunk_input.read(1024 * 256)
                        if not chunk:
                            break
                        output.write(chunk)
                        digest.update(chunk)
                        downloaded += len(chunk)
                        if downloaded > manifest.size:
                            raise ValueError("安装包下载大小超出清单记录值")
                        if progress:
                            progress(downloaded, manifest.size)
                chunk_path.unlink(missing_ok=True)
        if downloaded != manifest.size:
            raise ValueError(f"安装包大小校验失败：{downloaded} / {manifest.size}")
        if digest.hexdigest().lower() != manifest.sha256:
            raise ValueError("安装包 SHA-256 校验失败，已阻止安装")
        os.replace(part_path, final_path)
        return final_path
    except Exception:
        if part_path.exists():
            part_path.unlink()
        for chunk_path in chunk_paths:
            chunk_path.unlink(missing_ok=True)
        raise


def launch_update_helper(installer_path: Path, installed_exe: Path | None = None) -> None:
    installer = installer_path.resolve()
    target = (installed_exe or Path(sys.executable)).resolve()
    if not installer.is_file():
        raise FileNotFoundError(f"更新安装包不存在：{installer}")

    args = ["--apply-update", str(installer), str(os.getpid()), str(target)]
    if getattr(sys, "frozen", False):
        helper = Path(tempfile.gettempdir()) / f"CYX_Update_Helper_{os.getpid()}.exe"
        shutil.copy2(sys.executable, helper)
        command = [str(helper), *args]
    else:
        main_py = Path(__file__).resolve().parent.parent / "main.py"
        command = [sys.executable, str(main_py), *args]
    subprocess.Popen(command, close_fds=True)


def _wait_for_process_exit(pid: int, timeout_ms: int = 120_000) -> None:
    if os.name != "nt":
        return
    synchronize = 0x00100000
    handle = ctypes.windll.kernel32.OpenProcess(synchronize, False, int(pid))
    if not handle:
        return
    try:
        ctypes.windll.kernel32.WaitForSingleObject(handle, timeout_ms)
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def _show_helper_error(message: str) -> None:
    if os.name == "nt":
        ctypes.windll.user32.MessageBoxW(None, message, "CYX 启动器更新失败", 0x10)


def run_update_helper(installer: Path, parent_pid: int, installed_exe: Path) -> int:
    _wait_for_process_exit(parent_pid)
    command = [
        str(installer),
        "/VERYSILENT",
        "/SUPPRESSMSGBOXES",
        "/NORESTART",
        "/SP-",
        "/CLOSEAPPLICATIONS",
    ]
    try:
        result = subprocess.run(command, timeout=900, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"安装程序退出码：{result.returncode}")
        if installed_exe.is_file():
            subprocess.Popen([str(installed_exe)], close_fds=True)
        try:
            installer.unlink(missing_ok=True)
        except OSError:
            pass
        return 0
    except Exception as exc:
        _show_helper_error(f"新版安装失败：{exc}\n\n请重新打开启动器后重试。")
        if installed_exe.is_file():
            try:
                subprocess.Popen([str(installed_exe)], close_fds=True)
            except OSError:
                pass
        return 1


def maybe_run_update_helper(argv: list[str] | None = None) -> int | None:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] != "--apply-update":
        return None
    if len(args) != 4:
        _show_helper_error("更新助手参数不完整。")
        return 2
    try:
        return run_update_helper(Path(args[1]), int(args[2]), Path(args[3]))
    except (OSError, ValueError) as exc:
        _show_helper_error(f"更新助手启动失败：{exc}")
        return 2
