from __future__ import annotations



from dataclasses import dataclass



from .config import (

    get_builtin_servers,

    load_launcher_config,

    resolve_selected_server,

    save_launcher_config,

)

from .game_launch import launch_dayz

from .server_query import query_server_mods

from .steam_paths import SteamPaths, repair_dayz_workshop_links, resolve_paths

from .workshop import (

    ModStatus,

    compute_download_progress,

    evaluate_mods,

    summarize_gate,

    trigger_workshop_downloads,

    workshop_mod_launch_names,

)





@dataclass

class SyncReport:

    server_name: str

    map_name: str

    statuses: list[ModStatus]

    can_join: bool

    gate_message: str

    paths: SteamPaths

    dlc_flags: int = 0

    player_count: int | None = None

    max_players: int | None = None


def _repair_target_ids(
    statuses: list[ModStatus],
    ugc_flags: dict[int, bool],
    force_all: bool = False,
) -> list[int]:
    """返回需要交给 Steam 修理的 Workshop ID；默认只选缺失/待更新目标。"""
    ids: list[int] = []
    seen: set[int] = set()
    for s in statuses:
        wid = s.workshop_id
        if wid <= 0 or wid in seen:
            continue
        # s.needs_update 只来自 Steam 状态位、登录态线上时间戳或 ACF 权威清单；
        # 不采用文件体积/PBO 启发式结论，避免健康模组被重新下载。
        if (
            force_all
            or s.missing
            or s.needs_update
            or ugc_flags.get(wid)
        ):
            ids.append(wid)
            seen.add(wid)
    return ids


def _missing_workshop_ids(statuses: list[ModStatus]) -> list[int]:
    """返回尚未安装或已取消订阅的 Workshop ID。"""
    ids: list[int] = []
    seen: set[int] = set()
    for status in statuses:
        wid = int(status.workshop_id)
        if wid > 0 and status.missing and wid not in seen:
            ids.append(wid)
            seen.add(wid)
    return ids





class LauncherService:

    def __init__(self) -> None:

        self.launcher = load_launcher_config()

        self.server = resolve_selected_server(str(self.launcher.get("selected_server_id", "")))

        self.last_report: SyncReport | None = None

        self.last_fast_link_repairs = 0

        self.last_fast_link_errors: list[str] = []



    def reload(self) -> None:

        self.launcher = load_launcher_config()

        self.server = resolve_selected_server(str(self.launcher.get("selected_server_id", "")))



    def save_launcher(self, launcher: dict) -> None:

        save_launcher_config(launcher)

        self.reload()



    def list_servers(self) -> list[dict]:

        return get_builtin_servers()



    def select_server(self, server_id: str) -> None:

        data = dict(self.launcher)

        data["selected_server_id"] = server_id

        self.save_launcher(data)

        self.last_report = None



    def resolve(self) -> SteamPaths:

        return resolve_paths(

            steam_override=self.launcher.get("steam_path", ""),

            dayz_override=self.launcher.get("dayz_path", ""),

        )



    def query_and_evaluate(self, steam_verify: bool = False) -> SyncReport:

        self.reload()

        paths = self.resolve()

        q = query_server_mods(self.server["server_ip"], int(self.server["query_port"]))

        mods = [(m.workshop_id, m.name) for m in q.mods]

        statuses = evaluate_mods(

            paths,

            mods,

            api_key=str(self.launcher.get("steam_api_key", "") or ""),

            steam_verify=steam_verify,

        )

        can_join, msg = summarize_gate(statuses)

        report = SyncReport(

            server_name=q.server_name or self.server.get("server_name", ""),

            map_name=q.map_name,

            statuses=statuses,

            can_join=can_join,

            gate_message=msg,

            paths=paths,

            dlc_flags=int(q.dlc_flags or 0),

            player_count=q.player_count,

            max_players=q.max_players,

        )

        self.last_report = report

        return report

    def refresh_current_report(self, refresh_remote: bool = False) -> SyncReport:
        """不重新查询服务器模组列表，只刷新当前报告的本地/Steam 状态。"""
        if self.last_report is None:
            return self.query_and_evaluate()
        paths = self.resolve()
        mods = [(status.workshop_id, status.name) for status in self.last_report.statuses]
        statuses = evaluate_mods(
            paths,
            mods,
            api_key=str(self.launcher.get("steam_api_key", "") or ""),
            steam_verify=False,
            refresh_remote=refresh_remote,
        )
        can_join, message = summarize_gate(statuses)
        self.last_report.statuses = statuses
        self.last_report.can_join = can_join
        self.last_report.gate_message = message
        self.last_report.paths = paths
        return self.last_report

    def missing_workshop_ids(self) -> list[int]:
        if self.last_report is None:
            return []
        return _missing_workshop_ids(self.last_report.statuses)

    def subscribe_workshop_items(self, workshop_ids: list[int]) -> tuple[int, str]:
        from .steam_ugc import subscribe_workshop_items

        paths = self.last_report.paths if self.last_report is not None else self.resolve()
        return subscribe_workshop_items(paths, workshop_ids)

    def content_log_offset(self) -> int:
        from .steam_ugc import workshop_content_log_size

        paths = self.last_report.paths if self.last_report is not None else self.resolve()
        return workshop_content_log_size(paths)



    def repair_outdated_and_missing(self, force_all: bool = False) -> tuple[int, list[int]]:
        """
        只修理真正需要的模组。
        先快速重建 !Workshop 链接；只有真实缺失或 Steam 明确 NeedsUpdate
        才调用下载。启动器不做深度完整性验证，也不改写 ACF。
        force_all 仅内部调试用，UI 不再调用。
        """
        if self.last_report is None:
            self.query_and_evaluate()
        assert self.last_report is not None

        link_result = repair_dayz_workshop_links(
            self.last_report.paths,
            [(s.workshop_id, s.name) for s in self.last_report.statuses],
        )
        self.last_fast_link_repairs = link_result.created
        self.last_fast_link_errors = list(link_result.errors or [])

        from .steam_ugc import clear_ugc_flag_cache, read_ugc_need_update_flags

        all_ids = [s.workshop_id for s in self.last_report.statuses if s.workshop_id > 0]
        clear_ugc_flag_cache()
        ugc_flags = read_ugc_need_update_flags(self.last_report.paths, all_ids)

        # 服务器模组列表已在按钮入口取得；这里只刷新本地/Steam
        # 状态，避免修理前重复查询 A2S、WebAPI 和全部在线详情。
        self.refresh_current_report(refresh_remote=False)
        assert self.last_report is not None

        ids = _repair_target_ids(self.last_report.statuses, ugc_flags, force_all=force_all)

        if ids:
            # 与官方启动器一致，先只处理一个。UI 会在完成后重新检测，
            # 再逐个下达仍然需要修理的项目。
            self.trigger_repair_item(ids[0])
        return len(ids), ids

    def trigger_repair_item(self, workshop_id: int) -> None:
        """只处理真实缺失/Steam 权威元数据确认需更新项，保留增量清单基线。"""
        wid = int(workshop_id)
        if wid <= 0:
            return
        paths = self.last_report.paths if self.last_report is not None else self.resolve()
        verified_outdated: set[int] = set()
        if self.last_report is not None:
            verified_outdated = {
                s.workshop_id
                for s in self.last_report.statuses
                if s.workshop_id == wid and s.needs_update
            }
        trigger_workshop_downloads(
            paths,
            [wid],
            fast_repair=True,
            verified_outdated_ids=verified_outdated,
        )



    def progress_for(self, target_ids: list[int], content_log_offset: int = 0):

        if self.last_report is None:

            return compute_download_progress(
                self.resolve(), [], target_ids, content_log_offset=content_log_offset
            )

        return compute_download_progress(
            self.last_report.paths,
            self.last_report.statuses,
            target_ids,
            content_log_offset=content_log_offset,
        )



    def join_if_allowed(self) -> None:

        if self.launcher.get("auto_check_updates_before_join", True) or self.last_report is None:

            report = self.query_and_evaluate()

        else:

            report = self.last_report

        if not report.can_join:

            raise RuntimeError(report.gate_message)



        # 设置服务器要求的全部模组（含顺序），再进服

        present_statuses = [s for s in report.statuses if s.present and not s.needs_update]

        if len(present_statuses) != len(report.statuses):

            raise RuntimeError("仍有模组缺失或待更新，无法设置模组并进服。")

        mod_paths = workshop_mod_launch_names(report.paths, present_statuses)



        launch_dayz(

            report.paths,

            server_ip=str(self.server["server_ip"]),

            server_port=int(self.server["server_port"]),

            query_port=int(self.server.get("query_port") or self.server["server_port"]),

            mod_paths=mod_paths,

            player_name=str(self.launcher.get("player_name", "") or ""),

            dlc_flags=int(report.dlc_flags or 0),

            use_battleye=True,

        )


