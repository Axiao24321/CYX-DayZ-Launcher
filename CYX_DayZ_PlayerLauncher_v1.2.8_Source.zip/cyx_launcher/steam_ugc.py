from __future__ import annotations

import ctypes
import os
import re
import time
from ctypes import c_bool, c_int32, c_uint32, c_uint64, c_void_p, cdll, create_string_buffer
from dataclasses import dataclass
from pathlib import Path

from .steam_paths import DAYZ_APP_ID, SteamPaths


# ISteamUGC item state flags (steam_api)
# Steamworks ISteamUGC::EItemState 官方位值。
# 2 是 LegacyItem，不是 Installed；旧实现从这里开始整体错位，导致 state=5
# （Subscribed|Installed）被误判成 NeedsUpdate。
ITEM_SUBSCRIBED = 1
ITEM_LEGACY = 2
ITEM_INSTALLED = 4
ITEM_NEEDS_UPDATE = 8
ITEM_DOWNLOADING = 16
ITEM_DOWNLOAD_PENDING = 32

STEAM_UGC_QUERY_COMPLETED_CALLBACK = 3401


class _SteamUgcQueryCompleted(ctypes.Structure):
    _fields_ = [
        ("handle", c_uint64),
        ("result", c_int32),
        ("num_results", c_uint32),
        ("total_results", c_uint32),
        ("cached", c_bool),
        ("next_cursor", ctypes.c_char * 256),
    ]


class _SteamUgcDetails(ctypes.Structure):
    """ISteamUGC v017 的 SteamUGCDetails_t（Steamworks SDK 布局）。"""

    _fields_ = [
        ("published_file_id", c_uint64),
        ("result", c_int32),
        ("file_type", c_int32),
        ("creator_app_id", c_uint32),
        ("consumer_app_id", c_uint32),
        ("title", ctypes.c_char * 129),
        ("description", ctypes.c_char * 8000),
        ("owner_steam_id", c_uint64),
        ("time_created", c_uint32),
        ("time_updated", c_uint32),
        ("time_added_to_user_list", c_uint32),
        ("visibility", c_int32),
        ("banned", c_bool),
        ("accepted_for_use", c_bool),
        ("tags_truncated", c_bool),
        ("tags", ctypes.c_char * 1025),
        ("file_handle", c_uint64),
        ("preview_file_handle", c_uint64),
        ("file_name", ctypes.c_char * 260),
        ("file_size", c_int32),
        ("preview_file_size", c_int32),
        ("url", ctypes.c_char * 256),
        ("votes_up", c_uint32),
        ("votes_down", c_uint32),
        ("score", ctypes.c_float),
        ("num_children", c_uint32),
        ("total_files_size", c_uint64),
    ]


@dataclass
class AuthenticatedItemDetails:
    workshop_id: int
    title: str
    time_updated: int
    total_files_size: int


class SteamUgcError(RuntimeError):
    pass


def _find_steam_api64(paths: SteamPaths) -> Path:
    p = paths.dayz_root / "steam_api64.dll"
    if p.is_file():
        return p
    raise FileNotFoundError(f"找不到 steam_api64.dll（期望在 {paths.dayz_root}）")


class SteamUgcSession:
    """用 DayZ 自带的 steam_api64 flat API 调用 ISteamUGC（与官方启动器同路）。"""

    def __init__(self, paths: SteamPaths) -> None:
        self.paths = paths
        self._dll = None
        self._ugc = None
        self._old_cwd = Path.cwd()

    def __enter__(self) -> "SteamUgcSession":
        api = _find_steam_api64(self.paths)
        appid = self.paths.dayz_root / "steam_appid.txt"
        if not appid.is_file():
            appid.write_text(f"{DAYZ_APP_ID}\n", encoding="ascii")
        os.chdir(self.paths.dayz_root)

        dll = cdll.LoadLibrary(str(api))
        dll.SteamAPI_Init.restype = c_bool
        dll.SteamAPI_Shutdown.restype = None
        if hasattr(dll, "SteamAPI_RunCallbacks"):
            dll.SteamAPI_RunCallbacks.restype = None
        dll.SteamAPI_SteamUGC_v017.restype = c_void_p
        dll.SteamAPI_ISteamUGC_DownloadItem.argtypes = [c_void_p, c_uint64, c_bool]
        dll.SteamAPI_ISteamUGC_DownloadItem.restype = c_bool
        dll.SteamAPI_ISteamUGC_SubscribeItem.argtypes = [c_void_p, c_uint64]
        dll.SteamAPI_ISteamUGC_SubscribeItem.restype = c_uint64
        dll.SteamAPI_ISteamUGC_GetItemState.argtypes = [c_void_p, c_uint64]
        dll.SteamAPI_ISteamUGC_GetItemState.restype = c_uint32
        dll.SteamAPI_ISteamUGC_GetItemInstallInfo.argtypes = [
            c_void_p,
            c_uint64,
            c_void_p,
            c_void_p,
            c_uint32,
            c_void_p,
        ]
        dll.SteamAPI_ISteamUGC_GetItemInstallInfo.restype = c_bool
        dll.SteamAPI_ISteamUGC_GetItemDownloadInfo.argtypes = [
            c_void_p,
            c_uint64,
            c_void_p,
            c_void_p,
        ]
        dll.SteamAPI_ISteamUGC_GetItemDownloadInfo.restype = c_bool

        if not dll.SteamAPI_Init():
            raise SteamUgcError("SteamAPI_Init 失败（请确认 Steam 已登录且在线）")
        ugc = dll.SteamAPI_SteamUGC_v017()
        if not ugc:
            dll.SteamAPI_Shutdown()
            raise SteamUgcError("获取 ISteamUGC 失败")
        self._dll = dll
        self._ugc = ugc
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            if self._dll is not None:
                self._dll.SteamAPI_Shutdown()
        finally:
            try:
                os.chdir(self._old_cwd)
            except OSError:
                pass
            self._dll = None
            self._ugc = None

    def item_state(self, workshop_id: int) -> int:
        assert self._dll is not None and self._ugc is not None
        return int(self._dll.SteamAPI_ISteamUGC_GetItemState(self._ugc, c_uint64(workshop_id)))

    def download_info(self, workshop_id: int) -> tuple[int, int]:
        """返回 (已下载字节, 总字节)。"""
        assert self._dll is not None and self._ugc is not None
        downloaded = c_uint64(0)
        total = c_uint64(0)
        ok = self._dll.SteamAPI_ISteamUGC_GetItemDownloadInfo(
            self._ugc,
            c_uint64(workshop_id),
            ctypes.byref(downloaded),
            ctypes.byref(total),
        )
        if not ok:
            return 0, 0
        return int(downloaded.value), int(total.value)

    def download_item(self, workshop_id: int, high_priority: bool = False) -> bool:
        assert self._dll is not None and self._ugc is not None
        return bool(
            self._dll.SteamAPI_ISteamUGC_DownloadItem(
                self._ugc, c_uint64(workshop_id), c_bool(high_priority)
            )
        )

    def subscribe_item(self, workshop_id: int) -> int:
        """通过当前登录的 Steam 用户恢复 Workshop 订阅。"""
        assert self._dll is not None and self._ugc is not None
        return int(
            self._dll.SteamAPI_ISteamUGC_SubscribeItem(
                self._ugc, c_uint64(workshop_id)
            )
        )

    def run_callbacks(self) -> None:
        assert self._dll is not None
        if hasattr(self._dll, "SteamAPI_RunCallbacks"):
            self._dll.SteamAPI_RunCallbacks()

    def query_item_details(
        self, workshop_ids: list[int], timeout_seconds: float = 5.0
    ) -> dict[int, AuthenticatedItemDetails]:
        """用当前 Steam 登录态只读查询 UGC 元数据，支持朋友可见项目。"""
        assert self._dll is not None and self._ugc is not None
        ids = list(dict.fromkeys(int(x) for x in workshop_ids if int(x) > 0))
        if not ids:
            return {}

        dll = self._dll
        iface = self._ugc
        dll.SteamAPI_ISteamUGC_CreateQueryUGCDetailsRequest.argtypes = [
            c_void_p,
            ctypes.POINTER(c_uint64),
            c_uint32,
        ]
        dll.SteamAPI_ISteamUGC_CreateQueryUGCDetailsRequest.restype = c_uint64
        dll.SteamAPI_ISteamUGC_SendQueryUGCRequest.argtypes = [c_void_p, c_uint64]
        dll.SteamAPI_ISteamUGC_SendQueryUGCRequest.restype = c_uint64
        dll.SteamAPI_ISteamUGC_GetQueryUGCResult.argtypes = [
            c_void_p,
            c_uint64,
            c_uint32,
            ctypes.POINTER(_SteamUgcDetails),
        ]
        dll.SteamAPI_ISteamUGC_GetQueryUGCResult.restype = c_bool
        dll.SteamAPI_ISteamUGC_ReleaseQueryUGCRequest.argtypes = [c_void_p, c_uint64]
        dll.SteamAPI_ISteamUGC_ReleaseQueryUGCRequest.restype = c_bool
        dll.SteamAPI_SteamUtils_v010.restype = c_void_p
        dll.SteamAPI_ISteamUtils_IsAPICallCompleted.argtypes = [
            c_void_p,
            c_uint64,
            ctypes.POINTER(c_bool),
        ]
        dll.SteamAPI_ISteamUtils_IsAPICallCompleted.restype = c_bool
        dll.SteamAPI_ISteamUtils_GetAPICallResult.argtypes = [
            c_void_p,
            c_uint64,
            c_void_p,
            c_int32,
            c_int32,
            ctypes.POINTER(c_bool),
        ]
        dll.SteamAPI_ISteamUtils_GetAPICallResult.restype = c_bool

        array = (c_uint64 * len(ids))(*ids)
        query_handle = int(
            dll.SteamAPI_ISteamUGC_CreateQueryUGCDetailsRequest(iface, array, len(ids))
        )
        if query_handle == 0xFFFFFFFFFFFFFFFF:
            return {}
        try:
            api_call = int(dll.SteamAPI_ISteamUGC_SendQueryUGCRequest(iface, query_handle))
            if api_call == 0:
                return {}
            utils = dll.SteamAPI_SteamUtils_v010()
            if not utils:
                return {}

            io_failed = c_bool(False)
            deadline = time.monotonic() + max(0.1, timeout_seconds)
            completed = False
            while time.monotonic() < deadline:
                self.run_callbacks()
                completed = bool(
                    dll.SteamAPI_ISteamUtils_IsAPICallCompleted(
                        utils, c_uint64(api_call), ctypes.byref(io_failed)
                    )
                )
                if completed or io_failed.value:
                    break
                time.sleep(0.05)
            if not completed or io_failed.value:
                return {}

            completed_result = _SteamUgcQueryCompleted()
            callback_failed = c_bool(False)
            ok = dll.SteamAPI_ISteamUtils_GetAPICallResult(
                utils,
                c_uint64(api_call),
                ctypes.byref(completed_result),
                ctypes.sizeof(completed_result),
                STEAM_UGC_QUERY_COMPLETED_CALLBACK,
                ctypes.byref(callback_failed),
            )
            if not ok or callback_failed.value or completed_result.result != 1:
                return {}

            out: dict[int, AuthenticatedItemDetails] = {}
            for index in range(int(completed_result.num_results)):
                details = _SteamUgcDetails()
                if not dll.SteamAPI_ISteamUGC_GetQueryUGCResult(
                    iface, c_uint64(query_handle), index, ctypes.byref(details)
                ):
                    continue
                if details.result != 1 or details.published_file_id <= 0:
                    continue
                title = bytes(details.title).split(b"\0", 1)[0].decode(
                    "utf-8", errors="replace"
                )
                wid = int(details.published_file_id)
                out[wid] = AuthenticatedItemDetails(
                    workshop_id=wid,
                    title=title,
                    time_updated=int(details.time_updated),
                    total_files_size=int(details.total_files_size),
                )
            return out
        finally:
            dll.SteamAPI_ISteamUGC_ReleaseQueryUGCRequest(iface, c_uint64(query_handle))

    def needs_update(self, workshop_id: int) -> bool:
        st = self.item_state(workshop_id)
        return bool(st & (ITEM_NEEDS_UPDATE | ITEM_DOWNLOADING | ITEM_DOWNLOAD_PENDING))


@dataclass(frozen=True)
class WorkshopDownloadEvent:
    workshop_id: int
    status: str
    message: str
    key: str


_WORKSHOP_DOWNLOAD_REQUEST_RE = re.compile(
    r"\[AppID 221100\]\s+Download item\s+(\d+)\s+requested by app"
)
_WORKSHOP_DOWNLOAD_RESULT_RE = re.compile(
    r"\[AppID 221100\]\s+Download item\s+(\d+)\s+result\s*:\s*(.+?)\s*$"
)
_WORKSHOP_UPDATE_CANCELED_RE = re.compile(
    r"\[AppID 221100\]\s+Update canceled:\s*(.+?)\s*$"
)


def read_workshop_download_events(
    paths: SteamPaths,
    workshop_ids: list[int],
) -> dict[int, WorkshopDownloadEvent]:
    """读取每个目标最近一次 Steam Workshop 请求/结果。"""
    wanted = {int(x) for x in workshop_ids if int(x) > 0}
    if not wanted:
        return {}
    log_path = paths.steam_root / "logs" / "workshop_log.txt"
    try:
        with log_path.open("rb") as stream:
            size = stream.seek(0, os.SEEK_END)
            start = max(0, size - 4 * 1024 * 1024)
            stream.seek(start)
            raw = stream.read()
        if start:
            first_newline = raw.find(b"\n")
            if first_newline >= 0:
                raw = raw[first_newline + 1 :]
        text = raw.decode("utf-8", errors="replace")
    except (OSError, TypeError, ValueError):
        return {}

    events: dict[int, WorkshopDownloadEvent] = {}
    active_id: int | None = None
    last_error = ""
    for line in text.splitlines():
        requested = _WORKSHOP_DOWNLOAD_REQUEST_RE.search(line)
        if requested:
            wid = int(requested.group(1))
            active_id = wid
            last_error = ""
            if wid in wanted:
                events[wid] = WorkshopDownloadEvent(
                    workshop_id=wid,
                    status="pending",
                    message="Steam 已接收下载请求",
                    key=line.strip(),
                )
            continue

        canceled = _WORKSHOP_UPDATE_CANCELED_RE.search(line)
        if canceled and active_id in wanted:
            last_error = canceled.group(1).strip()
            continue

        result = _WORKSHOP_DOWNLOAD_RESULT_RE.search(line)
        if not result:
            continue
        wid = int(result.group(1))
        if wid not in wanted:
            continue
        result_text = result.group(2).strip()
        success = result_text.casefold() in {"ok", "success"}
        failure_message = last_error or result_text
        if (
            "content unavailable" in failure_message.casefold()
            or "no download source" in failure_message.casefold()
        ):
            failure_message = "内容源暂不可用（Steam CDN 尚未同步）"
        events[wid] = WorkshopDownloadEvent(
            workshop_id=wid,
            status="success" if success else "failure",
            message=result_text if success else failure_message,
            key=line.strip(),
        )
        if active_id == wid:
            active_id = None
            last_error = ""
    return events


def force_download_items(
    paths: SteamPaths,
    workshop_ids: list[int],
    *,
    verified_outdated_ids: set[int] | None = None,
) -> tuple[int, str]:
    """
    请求 Steam 下载真实缺失或已由 Steam 权威元数据确认过期的项目。

    健康的已安装项目会在最底层被跳过，保证快速修复不会因为上层误判而
    触发重新下载。verified_outdated_ids 可包含登录态线上时间戳比本地新的
    项目；这类项目即使 NeedsUpdate 状态位尚未刷新，也要像官方启动器一样
    调用一次普通优先级 DownloadItem(false)，由 Steam 执行增量校验/下载。
    这里不得使用高优先级，也不得从其他通道重复排队。
    返回 (成功下达数量, 说明)。
    """
    ids = list(dict.fromkeys(int(x) for x in workshop_ids if int(x) > 0))
    verified = {
        int(x)
        for x in (verified_outdated_ids or set())
        if int(x) > 0
    }
    if not ids:
        return 0, "无目标"
    ok_n = 0
    latest_events = read_workshop_download_events(paths, ids)
    failed_ids = {
        wid for wid, event in latest_events.items() if event.status == "failure"
    }
    try:
        with SteamUgcSession(paths) as ugc:
            for wid in ids:
                state = ugc.item_state(wid)
                if not state & ITEM_SUBSCRIBED:
                    # 用当前登录态恢复订阅；不再通过快速修复手工改 VDF。
                    ugc.subscribe_item(wid)
                if (
                    state & (ITEM_DOWNLOADING | ITEM_DOWNLOAD_PENDING)
                    and wid not in failed_ids
                ):
                    # Steam 已经在处理该项，不重复调用 DownloadItem。
                    ok_n += 1
                    continue
                if (
                    state & ITEM_INSTALLED
                    and not state & ITEM_NEEDS_UPDATE
                    and wid not in verified
                ):
                    # 已安装且 Steam 没有明确标记更新：快速修复到此结束。
                    ok_n += 1
                    continue
                # 缺失、NeedsUpdate 或线上时间戳确认过期才使用 Normal（false）。
                if ugc.download_item(wid, high_priority=False):
                    ok_n += 1
            time.sleep(0.5)
    except Exception as e:
        return ok_n, f"Steamworks 修理失败：{e}"
    return ok_n, f"已通过 Steamworks 下达修理/下载 {ok_n}/{len(ids)} 个"


def subscribe_workshop_items(
    paths: SteamPaths,
    workshop_ids: list[int],
) -> tuple[int, str]:
    """用当前 Steam 账号一次性订阅缺失的服务器模组。

    新订阅由 Steam 自动排队下载；对已订阅但本地缺失的项目，
    只使用普通优先级 DownloadItem(false) 恢复下载。整批共用一个
    SteamUGC 会话，避免反复初始化 SteamAPI 影响客户端下载。
    """
    ids = list(dict.fromkeys(int(x) for x in workshop_ids if int(x) > 0))
    if not ids:
        return 0, "无需订阅"

    accepted = 0
    try:
        with SteamUgcSession(paths) as ugc:
            for wid in ids:
                state = ugc.item_state(wid)
                if state & ITEM_SUBSCRIBED:
                    if state & (ITEM_DOWNLOADING | ITEM_DOWNLOAD_PENDING):
                        accepted += 1
                    elif ugc.download_item(wid, high_priority=False):
                        # 这个函数只接收上层已确认「本地缺失」
                        # 的项目；即使 Steam 状态位暂时残留 Installed，
                        # 也需要交给 Steam 恢复内容。
                        accepted += 1
                    continue

                if ugc.subscribe_item(wid):
                    accepted += 1

            # SubscribeItem 是异步请求；短暂派发回调即可交给
            # Steam 后台，不在启动器内长时间占用 SteamAPI。
            for _ in range(4):
                ugc.run_callbacks()
                time.sleep(0.05)
    except Exception as e:
        return accepted, f"Steamworks 订阅失败：{e}"
    return accepted, f"已向 Steam 提交订阅/下载 {accepted}/{len(ids)} 个"


@dataclass
class ItemInstallInfo:
    folder: Path | None
    size_on_disk: int
    timestamp: int


def read_item_install_infos(paths: SteamPaths, workshop_ids: list[int]) -> dict[int, ItemInstallInfo]:
    """读取 Steam 记录的模组安装路径与体积（多盘库时比猜 workshop_content 更准）。"""
    ids = [int(x) for x in workshop_ids if int(x) > 0]
    out: dict[int, ItemInstallInfo] = {}
    if not ids:
        return out
    try:
        with SteamUgcSession(paths) as ugc:
            assert ugc._dll is not None and ugc._ugc is not None
            dll = ugc._dll
            iface = ugc._ugc
            for wid in ids:
                size = c_uint64(0)
                folder_buf = create_string_buffer(4096)
                ts = c_uint32(0)
                ok = dll.SteamAPI_ISteamUGC_GetItemInstallInfo(
                    iface,
                    c_uint64(wid),
                    ctypes.byref(size),
                    folder_buf,
                    4096,
                    ctypes.byref(ts),
                )
                folder_text = folder_buf.value.decode("utf-8", errors="ignore").strip()
                folder = Path(folder_text) if folder_text else None
                if ok and folder is not None and not folder.is_dir():
                    folder = None
                out[wid] = ItemInstallInfo(
                    folder=folder,
                    size_on_disk=int(size.value),
                    timestamp=int(ts.value),
                )
    except Exception:
        return {}
    return out


def read_authenticated_item_details(
    paths: SteamPaths, workshop_ids: list[int]
) -> dict[int, AuthenticatedItemDetails]:
    """读取登录用户可见的工坊元数据；失败时静默回退其他检测来源。"""
    ids = list(dict.fromkeys(int(x) for x in workshop_ids if int(x) > 0))
    if not ids:
        return {}
    try:
        with SteamUgcSession(paths) as ugc:
            return ugc.query_item_details(ids)
    except Exception:
        return {}


@dataclass
class ItemDownloadProgress:
    downloaded: int
    total: int
    state: int
    pending: bool


@dataclass
class WorkshopUpdatePlan:
    """Steam content_log 中的真实网络下载/本地复用/磁盘处理计划。"""

    downloaded: int
    download_total: int
    reused: int
    reuse_total: int
    staged: int
    stage_total: int


_VALIDATING_WORKSHOP_RE = re.compile(r"Validating active workshop item\s+(\d+)\s*\.\.\.")
_UPDATE_STARTED_RE = re.compile(
    r"AppID\s+221100\s+update started\s*:\s*"
    r"download\s+(\d+)/(\d+),\s*"
    r"store\s+\d+/\d+,\s*"
    r"reuse\s+(\d+)/(\d+),\s*"
    r"delta\s+\d+/\d+,\s*"
    r"stage\s+(\d+)/(\d+)"
)


def read_workshop_update_plans(
    paths: SteamPaths,
    workshop_ids: list[int],
    content_log_offset: int = 0,
) -> dict[int, WorkshopUpdatePlan]:
    """
    读取 Steam content_log 中最新的 Workshop 更新计划。

    GetItemDownloadInfo 的 total 在大型 Workshop 更新时常表示需要
    校验/重建的文件量，不是真实联网下载量。content_log 的
    download/reuse/stage 三组字节才能把这三者区分开。
    """
    wanted = {int(x) for x in workshop_ids if int(x) > 0}
    if not wanted:
        return {}
    log_path = paths.steam_root / "logs" / "content_log.txt"
    try:
        # 传入本批操作开始前的 EOF 偏移时，只读新增日志，
        # 避免把旧下载任务的体积误显示为本次下载量。
        with log_path.open("rb") as stream:
            size = stream.seek(0, os.SEEK_END)
            requested = max(0, int(content_log_offset or 0))
            if 0 < requested <= size:
                start = requested
                exact_batch_offset = True
            else:
                start = max(0, size - 16 * 1024 * 1024)
                exact_batch_offset = False
            stream.seek(start)
            raw = stream.read()
        if start and not exact_batch_offset:
            first_newline = raw.find(b"\n")
            if first_newline >= 0:
                raw = raw[first_newline + 1 :]
        text = raw.decode("utf-8", errors="replace")
    except OSError:
        return {}

    current_id: int | None = None
    plans: dict[int, WorkshopUpdatePlan] = {}
    for line in text.splitlines():
        validating = _VALIDATING_WORKSHOP_RE.search(line)
        if validating:
            current_id = int(validating.group(1))
            continue
        started = _UPDATE_STARTED_RE.search(line)
        if started and current_id in wanted:
            plans[current_id] = WorkshopUpdatePlan(
                downloaded=int(started.group(1)),
                download_total=int(started.group(2)),
                reused=int(started.group(3)),
                reuse_total=int(started.group(4)),
                staged=int(started.group(5)),
                stage_total=int(started.group(6)),
            )
    return plans


def workshop_content_log_size(paths: SteamPaths) -> int:
    """返回 Steam content_log 当前字节位置，用于隔离本次下载信息。"""
    try:
        return int((paths.steam_root / "logs" / "content_log.txt").stat().st_size)
    except OSError:
        return 0


def item_needs_download(state: int, downloaded: int, total: int) -> bool:
    """只信 Steam 状态位；残留的下载字节统计不作为更新依据。"""
    needs_update = bool(state & ITEM_NEEDS_UPDATE)
    downloading = bool(state & ITEM_DOWNLOADING)
    return needs_update or downloading


def read_item_download_progress(
    paths: SteamPaths, workshop_ids: list[int]
) -> dict[int, ItemDownloadProgress]:
    ids = [int(x) for x in workshop_ids if int(x) > 0]
    out: dict[int, ItemDownloadProgress] = {}
    if not ids:
        return out
    try:
        with SteamUgcSession(paths) as ugc:
            for wid in ids:
                st = ugc.item_state(wid)
                downloaded, total = ugc.download_info(wid)
                out[wid] = ItemDownloadProgress(
                    downloaded=downloaded,
                    total=total,
                    state=st,
                    pending=item_needs_download(st, downloaded, total),
                )
    except Exception:
        return {}
    return out


def probe_workshop_updates(paths: SteamPaths, workshop_ids: list[int]) -> dict[int, ItemDownloadProgress]:
    """
    兼容旧调用名的只读检测。检测阶段严禁调用 DownloadItem，
    朋友可见项目的更新时间由 read_authenticated_item_details 获取。
    """
    return read_item_download_progress(paths, workshop_ids)


_ugc_flag_cache: dict[int, bool] = {}
_ugc_flag_cache_ts: float = 0.0


def clear_ugc_flag_cache() -> None:
    global _ugc_flag_cache, _ugc_flag_cache_ts
    _ugc_flag_cache = {}
    _ugc_flag_cache_ts = 0.0


def read_ugc_need_update_flags(paths: SteamPaths, workshop_ids: list[int]) -> dict[int, bool]:
    """读取 Steam 客户端认为需要更新的 Workshop 项。"""
    global _ugc_flag_cache, _ugc_flag_cache_ts

    ids = [int(x) for x in workshop_ids if int(x) > 0]
    out: dict[int, bool] = {}
    if not ids:
        return out

    now = time.time()
    if now - _ugc_flag_cache_ts < 10 and all(i in _ugc_flag_cache for i in ids):
        return {i: _ugc_flag_cache[i] for i in ids}

    try:
        with SteamUgcSession(paths) as ugc:
            for wid in ids:
                st = ugc.item_state(wid)
                downloaded, total = ugc.download_info(wid)
                # 单独 DownloadPending 和残留字节统计都不算更新；只信
                # NeedsUpdate/Downloading 状态位。
                out[wid] = item_needs_download(st, downloaded, total)
        _ugc_flag_cache.update(out)
        _ugc_flag_cache_ts = now
    except Exception:
        return dict(_ugc_flag_cache) if _ugc_flag_cache else {}
    return out
