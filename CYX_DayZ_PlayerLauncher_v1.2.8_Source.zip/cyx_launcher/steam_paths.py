from __future__ import annotations

import re
import os
import subprocess
import winreg
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


DAYZ_APP_ID = 221100
STEAM_ID64_BASE = 76561197960265728


@dataclass
class SteamPaths:
    steam_root: Path
    dayz_root: Path
    workshop_content: Path
    workshop_acf: Path
    steam_exe: Path


@dataclass
class WorkshopLinkRepairResult:
    checked: int = 0
    created: int = 0
    already_ok: int = 0
    errors: list[str] | None = None

    def __post_init__(self) -> None:
        if self.errors is None:
            self.errors = []


def steam_id64_to_account_id(steam_id64: str | int) -> int:
    return int(steam_id64) - STEAM_ID64_BASE


def _subscriptions_vdf_path(steam_root: Path, steam_id64: str = "") -> Path | None:
    account_ids: list[int] = []
    if steam_id64:
        try:
            account_ids.append(steam_id64_to_account_id(steam_id64))
        except (TypeError, ValueError):
            pass
    ugc_root = steam_root / "userdata"
    scored: list[tuple[float, int, Path]] = []
    if ugc_root.is_dir():
        for child in ugc_root.iterdir():
            if not child.is_dir() or not child.name.isdigit():
                continue
            sub = child / "ugc" / f"{DAYZ_APP_ID}_subscriptions.vdf"
            if sub.is_file():
                scored.append((sub.stat().st_mtime, int(child.name), sub))
    scored.sort(reverse=True)
    for _, aid, path in scored:
        if aid in account_ids:
            return path
    if scored:
        return scored[0][2]
    for aid in account_ids:
        path = steam_root / "userdata" / str(aid) / "ugc" / f"{DAYZ_APP_ID}_subscriptions.vdf"
        if path.is_file():
            return path
    return None


def _parse_subscription_ids(text: str) -> set[int]:
    ids: set[int] = set()
    for block in re.finditer(r'"\d+"\s*\{([^{}]*)\}', text, flags=re.DOTALL):
        body = block.group(1)
        fields = dict(re.findall(r'"([^"]+)"\s+"([^"]*)"', body))
        pid = fields.get("publishedfileid", "").strip()
        if not pid.isdigit():
            continue
        if fields.get("disabled_locally", "0").strip() == "1":
            continue
        ids.add(int(pid))
    return ids


def read_dayz_workshop_subscriptions(steam_root: Path, steam_id64: str = "") -> set[int] | None:
    """
    读取当前账号对 DayZ Workshop 的订阅列表。
    来源：userdata/<account>/ugc/221100_subscriptions.vdf
    返回 None 表示读不到文件（此时不要把「未订阅」当缺失，避免误伤）。
    """
    path = _subscriptions_vdf_path(steam_root, steam_id64)
    if path is None:
        return None
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
    return _parse_subscription_ids(text)


def ensure_dayz_workshop_subscriptions(
    steam_root: Path,
    workshop_ids: list[int],
    steam_id64: str = "",
) -> tuple[Path | None, list[int]]:
    """
    把缺失的 Workshop ID 写进订阅 VDF。
    取消订阅后仅发 download 指令往往无效，需要先恢复订阅记录。
    返回 (订阅文件路径, 新写入的 id 列表)。
    """
    import time

    ids = [int(x) for x in workshop_ids if int(x) > 0]
    if not ids:
        return None, []
    path = _subscriptions_vdf_path(steam_root, steam_id64)
    if path is None:
        try:
            aid = steam_id64_to_account_id(steam_id64) if steam_id64 else None
        except (TypeError, ValueError):
            aid = None
        if aid is None:
            return None, []
        path = steam_root / "userdata" / str(aid) / "ugc" / f"{DAYZ_APP_ID}_subscriptions.vdf"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            f'"subscribedfiles"\n{{\n\t"appid"\t\t"{DAYZ_APP_ID}"\n'
            f'\t"time_last_updated"\t\t"{int(time.time())}"\n}}\n',
            encoding="utf-8",
            newline="\n",
        )

    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return path, []

    existing = _parse_subscription_ids(text)
    missing = [wid for wid in ids if wid not in existing]
    if not missing:
        return path, []

    idxs = [int(x) for x in re.findall(r'"(\d+)"\s*\{\s*"publishedfileid"', text)]
    next_idx = (max(idxs) + 1) if idxs else 0
    now = str(int(time.time()))
    chunks: list[str] = []
    for wid in missing:
        chunks.append(
            f'\t"{next_idx}"\n'
            f"\t{{\n"
            f'\t\t"publishedfileid"\t\t"{wid}"\n'
            f'\t\t"time_subscribed"\t\t"{now}"\n'
            f'\t\t"disabled_locally"\t\t"0"\n'
            f"\t}}\n"
        )
        next_idx += 1

    insert = "".join(chunks)
    text2 = re.sub(
        r'("time_last_updated"\s+")(\d+)(")',
        rf"\g<1>{now}\3",
        text,
        count=1,
    )
    pos = text2.rstrip().rfind("}")
    if pos < 0:
        return path, []
    new_text = text2[:pos] + insert + text2[pos:]
    try:
        path.write_text(new_text, encoding="utf-8", newline="\n")
    except OSError:
        return path, []
    return path, missing


def _read_reg_steam_path() -> Path | None:
    for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        try:
            key = winreg.OpenKey(root, r"Software\Valve\Steam")
            value, _ = winreg.QueryValueEx(key, "SteamPath")
            path = Path(str(value))
            if path.exists():
                return path
        except OSError:
            continue
    return None


def _parse_library_folders(steam_root: Path) -> list[Path]:
    libs = [steam_root]
    vdf = steam_root / "steamapps" / "libraryfolders.vdf"
    if not vdf.exists():
        return libs
    text = vdf.read_text(encoding="utf-8", errors="ignore")
    for match in re.finditer(r'"path"\s+"([^"]+)"', text):
        p = Path(match.group(1).replace("\\\\", "\\"))
        if p.exists() and p not in libs:
            libs.append(p)
    return libs


def all_workshop_content_roots(steam_root: Path) -> list[Path]:
    """所有 Steam 库里的 DayZ Workshop 内容根目录（多盘安装时必须全扫）。"""
    roots: list[Path] = []
    for lib in _parse_library_folders(steam_root):
        cand = lib / "steamapps" / "workshop" / "content" / str(DAYZ_APP_ID)
        if cand.is_dir():
            roots.append(cand)
    if not roots:
        roots.append(steam_root / "steamapps" / "workshop" / "content" / str(DAYZ_APP_ID))
    return roots


def _library_from_dayz_root(dayz_root: Path) -> Path | None:
    """从 .../steamapps/common/DayZ 反推出 Steam 库根目录。"""
    try:
        root = dayz_root.resolve()
    except OSError:
        root = dayz_root
    common = root.parent
    steamapps = common.parent
    if common.name.lower() == "common" and steamapps.name.lower() == "steamapps":
        return steamapps.parent
    return None


def find_workshop_content_dir(
    paths: SteamPaths,
    workshop_id: int,
    *,
    prefer: Path | None = None,
) -> Path | None:
    """只定位 Steam 的真实 Workshop 内容目录，不回退到 !Workshop 链接。"""
    if prefer is not None:
        try:
            if prefer.is_dir() and any(prefer.iterdir()):
                return prefer
        except OSError:
            pass
    roots = [paths.workshop_content]
    for root in all_workshop_content_roots(paths.steam_root):
        if root not in roots:
            roots.append(root)
    for root in roots:
        folder = root / str(workshop_id)
        try:
            if folder.is_dir() and any(folder.iterdir()):
                return folder
        except OSError:
            continue
    return None


def find_workshop_mod_dir(
    paths: SteamPaths,
    workshop_id: int,
    *,
    prefer: Path | None = None,
) -> Path | None:
    """定位模组实际安装目录；优先真实内容，再回退到 !Workshop 链接。"""
    content = find_workshop_content_dir(paths, workshop_id, prefer=prefer)
    if content is not None:
        return content
    return _find_bang_workshop_folder(paths, workshop_id)


def _find_bang_workshop_folder(paths: SteamPaths, workshop_id: int) -> Path | None:
    bang = paths.dayz_root / "!Workshop"
    if not bang.is_dir():
        return None
    for child in bang.iterdir():
        if not child.is_dir():
            continue
        meta = child / "meta.cpp"
        if not meta.exists():
            continue
        text = meta.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"publishedid\s*=\s*(\d+)", text, re.I)
        if m and int(m.group(1)) == workshop_id:
            return child
    return None


def _safe_workshop_link_name(name: str, workshop_id: int) -> str:
    """生成 DayZ !Workshop 使用的 @模组名，并过滤 Windows 非法字符。"""
    clean = str(name or "").strip().lstrip("@").strip()
    clean = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", clean).rstrip(" .")
    if not clean:
        clean = str(int(workshop_id))
    # 给完整路径和可能的同名后缀留出空间。
    clean = clean[:120].rstrip(" .") or str(int(workshop_id))
    return f"@{clean}"


def repair_dayz_workshop_links(
    paths: SteamPaths,
    mods: Iterable[tuple[int, str]],
) -> WorkshopLinkRepairResult:
    """
    快速修复 DayZ/!Workshop Junction。

    只为已经存在的真实 Workshop 内容创建入口；不删除普通目录、不删除真实
    Workshop 内容，也不会触发 Steam 下载。已有任意指向同一 WorkshopID 的
    !Workshop 入口时视为正常，避免模组改名后制造重复链接。
    """
    result = WorkshopLinkRepairResult()
    bang = paths.dayz_root / "!Workshop"
    try:
        bang.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        result.errors.append(f"无法创建 !Workshop：{exc}")
        return result

    seen: set[int] = set()
    for raw_id, title in mods:
        wid = int(raw_id)
        if wid <= 0 or wid in seen:
            continue
        seen.add(wid)
        result.checked += 1

        target = find_workshop_content_dir(paths, wid)
        if target is None:
            continue
        if _find_bang_workshop_folder(paths, wid) is not None:
            result.already_ok += 1
            continue

        link = bang / _safe_workshop_link_name(title, wid)
        if link.exists() or link.is_symlink():
            # 同名普通目录或指向其他模组的链接不自动删除，防止误伤玩家文件。
            result.errors.append(f"{link.name} 已被其他目录占用")
            continue

        comspec = os.environ.get("COMSPEC", "cmd.exe")
        creationflags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            completed = subprocess.run(
                [comspec, "/d", "/c", "mklink", "/J", str(link), str(target)],
                cwd=str(bang),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=creationflags,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            result.errors.append(f"{link.name} 创建失败：{exc}")
            continue
        if completed.returncode == 0 and link.is_dir():
            result.created += 1
        else:
            detail = (completed.stderr or completed.stdout or "mklink 失败").strip()
            result.errors.append(f"{link.name} 创建失败：{detail}")
    return result


def find_dayz_root(steam_root: Path | None = None, override: str = "") -> Path | None:
    if override:
        p = Path(override)
        if (p / "DayZ_x64.exe").exists():
            return p
        # 用户可能选到了上一级或 steamapps
        for cand in (p / "DayZ", p / "common" / "DayZ", p / "steamapps" / "common" / "DayZ"):
            if (cand / "DayZ_x64.exe").exists():
                return cand

    if steam_root is None:
        steam_root = _read_reg_steam_path()
    if steam_root is None:
        return None

    # 1) 各 Steam 库里的 common/DayZ
    for lib in _parse_library_folders(steam_root):
        candidate = lib / "steamapps" / "common" / "DayZ"
        if (candidate / "DayZ_x64.exe").exists():
            return candidate

    # 2) 读 appmanifest_221100.acf 的 installdir（更稳）
    for lib in _parse_library_folders(steam_root):
        manifest = lib / "steamapps" / "appmanifest_221100.acf"
        if not manifest.exists():
            continue
        text = manifest.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r'"installdir"\s+"([^"]+)"', text)
        if not m:
            continue
        candidate = lib / "steamapps" / "common" / m.group(1)
        if (candidate / "DayZ_x64.exe").exists():
            return candidate

    return None


def detect_dayz_path_text(steam_override: str = "", dayz_override: str = "") -> str:
    """返回自动检测到的 DayZ 绝对路径；失败返回空字符串。"""
    try:
        steam = find_steam_root(steam_override)
        dayz = find_dayz_root(steam, dayz_override)
        return str(dayz.resolve()) if dayz else ""
    except OSError:
        return ""


def find_steam_root(override: str = "") -> Path | None:
    if override:
        p = Path(override)
        if (p / "steam.exe").exists() or (p / "Steam.exe").exists():
            return p
    return _read_reg_steam_path()


def resolve_paths(steam_override: str = "", dayz_override: str = "") -> SteamPaths:
    steam_root = find_steam_root(steam_override)
    if steam_root is None:
        raise FileNotFoundError("未找到 Steam 安装目录，请在设置里手动指定。")
    dayz_root = find_dayz_root(steam_root, dayz_override)
    if dayz_root is None:
        raise FileNotFoundError("未找到 DayZ 安装目录，请在设置里手动指定。")

    # workshop content：优先 DayZ 所在库，并保留全库扫描能力（find_workshop_mod_dir）
    workshop_content = None
    dayz_lib = _library_from_dayz_root(dayz_root)
    dayz_resolved = dayz_root.resolve()
    for lib in _parse_library_folders(steam_root):
        try:
            if dayz_lib is None and dayz_resolved.is_relative_to(lib.resolve()):
                dayz_lib = lib
                break
        except ValueError:
            continue
    search_libs: list[Path] = []
    if dayz_lib is not None:
        search_libs.append(dayz_lib)
    for lib in _parse_library_folders(steam_root):
        if lib not in search_libs:
            search_libs.append(lib)
    for lib in search_libs:
        if lib is None:
            continue
        cand = lib / "steamapps" / "workshop" / "content" / str(DAYZ_APP_ID)
        if cand.exists():
            workshop_content = cand
            break
    if workshop_content is None:
        workshop_content = steam_root / "steamapps" / "workshop" / "content" / str(DAYZ_APP_ID)
        workshop_content.mkdir(parents=True, exist_ok=True)

    workshop_acf = steam_root / "steamapps" / "workshop" / f"appworkshop_{DAYZ_APP_ID}.acf"
    acf_libs: list[Path] = []
    if dayz_lib is not None:
        acf_libs.append(dayz_lib)
    for lib in _parse_library_folders(steam_root):
        if lib not in acf_libs:
            acf_libs.append(lib)
    for lib in acf_libs:
        cand_acf = lib / "steamapps" / "workshop" / f"appworkshop_{DAYZ_APP_ID}.acf"
        if cand_acf.is_file():
            workshop_acf = cand_acf
            break
    steam_exe = steam_root / "steam.exe"
    if not steam_exe.exists():
        steam_exe = steam_root / "Steam.exe"
    return SteamPaths(
        steam_root=steam_root,
        dayz_root=dayz_root,
        workshop_content=workshop_content,
        workshop_acf=workshop_acf,
        steam_exe=steam_exe,
    )


def parse_workshop_acf(acf_path: Path) -> dict[str, dict[str, str]]:
    """Parse WorkshopItemsInstalled entries: id -> {timeupdated, size, manifest}."""
    if not acf_path.exists():
        return {}
    text = acf_path.read_text(encoding="utf-8", errors="ignore")
    installed: dict[str, dict[str, str]] = {}
    block = re.search(
        r'"WorkshopItemsInstalled"\s*\{(.*)\}\s*"WorkshopItemDetails"',
        text,
        re.S,
    )
    if not block:
        block = re.search(r'"WorkshopItemsInstalled"\s*\{(.*)\}\s*\}', text, re.S)
    if not block:
        return {}
    body = block.group(1)
    for m in re.finditer(
        r'"(\d+)"\s*\{\s*"size"\s*"(\d+)"\s*"timeupdated"\s*"(\d+)"\s*"manifest"\s*"([^"]*)"',
        body,
    ):
        wid, size, timeupdated, manifest = m.groups()
        installed[wid] = {
            "size": size,
            "timeupdated": timeupdated,
            "manifest": manifest,
        }
    return installed


def parse_workshop_item_details(acf_path: Path) -> dict[str, dict[str, str]]:
    """
    Parse WorkshopItemDetails: id -> fields including latest_timeupdated / latest_manifest.
    Steam 在「知道有新版本但尚未下完」时，会把 latest_* 写成新值，而 Installed 仍是旧值。
    私有/未列出工坊 WebAPI 常返回 result=9，必须靠这个本地清单判断更新。
    """
    if not acf_path.exists():
        return {}
    text = acf_path.read_text(encoding="utf-8", errors="ignore")
    m = re.search(r'"WorkshopItemDetails"\s*\{(.*)\}\s*$', text, re.S | re.M)
    if not m:
        m = re.search(r'"WorkshopItemDetails"\s*\{(.*)', text, re.S)
    if not m:
        return {}
    body = m.group(1)
    out: dict[str, dict[str, str]] = {}
    for block in re.finditer(r'"(\d+)"\s*\{([^{}]*)\}', body):
        wid = block.group(1)
        fields = dict(re.findall(r'"([^"]+)"\s+"([^"]*)"', block.group(2)))
        out[wid] = fields
    return out


def read_dayz_launcher_update_flags() -> dict[int, bool]:
    """
    读取官方 DayZ Launcher 缓存的 IsUpdateAvailable（若存在）。
    仅作补充信号；没有官方启动器缓存时返回空。
    """
    import json
    import os

    path = Path(os.environ.get("LOCALAPPDATA", "")) / "DayZ Launcher" / "Steam.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[int, bool] = {}
    for ext in data.get("Extensions", []) or []:
        eid = str(ext.get("Id", "") or "")
        if not eid.startswith("steam:"):
            continue
        try:
            wid = int(eid.split(":", 1)[1])
        except ValueError:
            continue
        if "IsUpdateAvailable" in ext:
            out[wid] = bool(ext.get("IsUpdateAvailable"))
    return out


def mark_workshop_items_need_repair(acf_path: Path, workshop_ids: list[int]) -> list[int]:
    """
    把已安装项的 manifest/timeupdated 改成过期，逼 Steam 像官方「修理」一样重新校验下载。
    只改 WorkshopItemsInstalled，保留 WorkshopItemDetails.latest_* 作为目标版本。
    返回实际改写成功的 id。
    """
    ids = [int(x) for x in workshop_ids if int(x) > 0]
    if not ids or not acf_path.is_file():
        return []
    try:
        text = acf_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []

    changed: list[int] = []

    def _patch_installed_block(match: re.Match[str]) -> str:
        wid = int(match.group(1))
        if wid not in ids:
            return match.group(0)
        body = match.group(2)
        body2 = re.sub(r'("size"\s+")(\d+)(")', r"\g<1>0\3", body, count=1)
        body2 = re.sub(r'("timeupdated"\s+")(\d+)(")', r"\g<1>1\3", body2, count=1)
        body2 = re.sub(r'("manifest"\s+")([^"]*)(")', r'\g<1>0\3', body2, count=1)
        if body2 != body:
            changed.append(wid)
        return f'"{wid}"\n\t\t{{{body2}}}'

    # 只替换 WorkshopItemsInstalled 段内的块，避免误伤 Details
    inst = re.search(
        r'("WorkshopItemsInstalled"\s*\{)(.*?)(\}\s*"WorkshopItemDetails")',
        text,
        re.S,
    )
    if not inst:
        return []
    head, body, tail = inst.group(1), inst.group(2), inst.group(3)
    body2 = re.sub(
        r'"(\d+)"\s*\{([^{}]*)\}',
        _patch_installed_block,
        body,
    )
    if body2 == body:
        return []
    new_text = text[: inst.start()] + head + body2 + tail + text[inst.end() :]
    try:
        acf_path.write_text(new_text, encoding="utf-8", newline="\n")
    except OSError:
        return []
    # 去重保持顺序
    seen: set[int] = set()
    ordered: list[int] = []
    for wid in changed:
        if wid not in seen:
            seen.add(wid)
            ordered.append(wid)
    return ordered
