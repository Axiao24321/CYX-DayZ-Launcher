from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from cyx_launcher.updater import (
    UpdateManifest,
    download_update,
    fetch_update_manifest_from_urls,
    is_newer_version,
    parse_manifest,
    version_tuple,
)


class FakeResponse:
    def __init__(self, chunks: list[bytes]) -> None:
        self.chunks = chunks

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def raise_for_status(self) -> None:
        return None

    def iter_content(self, chunk_size: int):
        del chunk_size
        yield from self.chunks


class FailingResponse(FakeResponse):
    def raise_for_status(self) -> None:
        raise RuntimeError("mirror unavailable")


class UpdaterTests(unittest.TestCase):
    def test_version_comparison_is_numeric(self) -> None:
        self.assertEqual(version_tuple("v1.2.0"), (1, 2, 0))
        self.assertTrue(is_newer_version("1.10.0", "1.9.9"))
        self.assertFalse(is_newer_version("1.2", "1.2.0"))

    def test_manifest_requires_https_and_sha256(self) -> None:
        parsed = parse_manifest(
            {
                "version": "1.2.0",
                "mandatory": True,
                "url": "https://updates.example/launcher.exe",
                "sha256": "a" * 64,
                "size": 123,
                "notes": "test",
            }
        )
        self.assertTrue(parsed.mandatory)
        with self.assertRaises(ValueError):
            parse_manifest(
                {
                    "version": "1.2.0",
                    "url": "http://updates.example/launcher.exe",
                    "sha256": "a" * 64,
                    "size": 123,
                }
            )

    def test_download_verifies_size_and_hash(self) -> None:
        payload = b"CYX launcher update"
        manifest = UpdateManifest(
            version="1.2.0",
            mandatory=True,
            url="https://updates.example/launcher.exe",
            sha256=hashlib.sha256(payload).hexdigest(),
            size=len(payload),
        )
        progress: list[tuple[int, int]] = []
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get", return_value=FakeResponse([payload[:5], payload[5:]])
        ):
            result = download_update(manifest, lambda done, total: progress.append((done, total)), Path(temp))
            self.assertEqual(result.read_bytes(), payload)
            self.assertEqual(progress[-1], (len(payload), len(payload)))

    def test_download_rejects_bad_hash_and_removes_partial(self) -> None:
        payload = b"tampered"
        manifest = UpdateManifest(
            version="1.2.0",
            mandatory=True,
            url="https://updates.example/launcher.exe",
            sha256="0" * 64,
            size=len(payload),
        )
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get", return_value=FakeResponse([payload])
        ):
            with self.assertRaises(ValueError):
                download_update(manifest, destination_dir=Path(temp))
            self.assertEqual(list(Path(temp).glob("*.part")), [])

    def test_manifest_and_download_support_verified_parts(self) -> None:
        one, two = b"first-part", b"second-part"
        whole = one + two
        manifest = parse_manifest(
            {
                "version": "1.2.1",
                "mandatory": True,
                "url": "https://updates.example/launcher.exe",
                "sha256": hashlib.sha256(whole).hexdigest(),
                "size": len(whole),
                "parts": [
                    {"url": "https://updates.example/1", "sha256": hashlib.sha256(one).hexdigest(), "size": len(one)},
                    {"url": "https://updates.example/2", "sha256": hashlib.sha256(two).hexdigest(), "size": len(two)},
                ],
            }
        )
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get",
            side_effect=[FakeResponse([one]), FakeResponse([two])],
        ):
            result = download_update(manifest, destination_dir=Path(temp))
            self.assertEqual(result.read_bytes(), whole)

    def test_download_falls_back_to_verified_part_mirror(self) -> None:
        payload = b"mirror-payload"
        manifest = parse_manifest(
            {
                "version": "1.2.3",
                "mandatory": True,
                "url": "https://primary.example/launcher.exe",
                "mirrors": ["https://backup.example/launcher.exe"],
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get",
            side_effect=[FailingResponse([]), FakeResponse([payload])],
        ):
            result = download_update(manifest, destination_dir=Path(temp))
            self.assertEqual(result.read_bytes(), payload)

    def test_manifest_check_falls_back_to_second_source(self) -> None:
        expected = UpdateManifest(
            version="1.2.3",
            mandatory=True,
            url="https://backup.example/launcher.exe",
            sha256="a" * 64,
            size=123,
        )
        with patch(
            "cyx_launcher.updater.fetch_update_manifest",
            side_effect=[RuntimeError("primary unavailable"), expected],
        ) as fetch:
            result = fetch_update_manifest_from_urls(
                ["https://primary.example/latest.json", "https://backup.example/latest.json"]
            )
        self.assertEqual(result, expected)
        self.assertEqual(fetch.call_count, 2)


if __name__ == "__main__":
    unittest.main()
