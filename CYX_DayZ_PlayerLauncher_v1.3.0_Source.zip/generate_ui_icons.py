from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "assets" / "icons"
FONT = Path(r"C:\Windows\Fonts\segmdl2.ttf")


ICONS = {
    "settings": ("\ue713", "#E7B650"),
    "profile": ("\ue77b", "#E7B650"),
    "server": ("\ue968", "#E7B650"),
    "shield": ("\uea18", "#72D23B"),
    "package": ("\ue7b8", "#E7B650"),
    "sync": ("\ue895", "#E7B650"),
    "repair": ("\ue90f", "#E7B650"),
    "repair_red": ("\ue90f", "#FF554F"),
    "trash": ("\ue74d", "#E7B650"),
    "refresh": ("\ue72c", "#D9D5CC"),
    "download": ("\ue896", "#E7B650"),
    "play": ("\ue768", "#17110A"),
    "folder": ("\ue8b7", "#E7B650"),
    "power": ("\ue7e8", "#FF7068"),
    "people": ("\ue716", "#72D23B"),
    "crown": ("\ue7c1", "#E7B650"),
    "running": ("\ueada", "#E7B650"),
}


def main() -> None:
    if not FONT.is_file():
        raise FileNotFoundError(FONT)
    OUT.mkdir(parents=True, exist_ok=True)
    font = ImageFont.truetype(str(FONT), 44)
    for name, (glyph, color) in ICONS.items():
        image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        box = draw.textbbox((0, 0), glyph, font=font)
        width = box[2] - box[0]
        height = box[3] - box[1]
        x = (64 - width) / 2 - box[0]
        y = (64 - height) / 2 - box[1]
        draw.text((x, y), glyph, font=font, fill=color)
        image.save(OUT / f"{name}.png")


if __name__ == "__main__":
    main()
