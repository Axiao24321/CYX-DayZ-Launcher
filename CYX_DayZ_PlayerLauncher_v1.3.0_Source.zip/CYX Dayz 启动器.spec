# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher\\assets\\app_icon.png', 'assets'), ('D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher\\assets\\app_icon.ico', 'assets'), ('D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher\\assets\\launcher_background.png', 'assets'), ('D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher\\assets\\icons', 'assets\\icons')]
binaries = []
hiddenimports = ['customtkinter', 'a2s', 'dayzquery', 'requests']
tmp_ret = collect_all('customtkinter')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('dayzquery')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['main.py'],
    pathex=['D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='CYX Dayz 启动器',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version='D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher\\version_info.txt',
    icon=['D:\\DayZ_轻量调试\\tools\\CYX_DayZ_PlayerLauncher\\assets\\app_icon.ico'],
)
