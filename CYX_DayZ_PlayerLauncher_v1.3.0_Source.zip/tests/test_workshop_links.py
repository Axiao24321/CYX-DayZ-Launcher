import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from cyx_launcher.steam_paths import repair_dayz_workshop_links


class WorkshopLinkRepairTests(unittest.TestCase):
    def _paths(self, root: Path):
        dayz = root / "steamapps" / "common" / "DayZ"
        content = root / "steamapps" / "workshop" / "content" / "221100"
        dayz.mkdir(parents=True)
        content.mkdir(parents=True)
        return SimpleNamespace(
            steam_root=root,
            dayz_root=dayz,
            workshop_content=content,
        )

    def test_creates_junction_without_touching_content(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            paths = self._paths(Path(tmp))
            target = paths.workshop_content / "123"
            target.mkdir()
            (target / "meta.cpp").write_text("publishedid = 123;", encoding="utf-8")
            (target / "payload.pbo").write_bytes(b"payload")

            result = repair_dayz_workshop_links(paths, [(123, "Test Mod")])

            link = paths.dayz_root / "!Workshop" / "@Test Mod"
            self.assertEqual(result.created, 1)
            self.assertTrue(link.is_dir())
            self.assertTrue((target / "payload.pbo").is_file())

    def test_existing_link_is_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            paths = self._paths(Path(tmp))
            target = paths.workshop_content / "123"
            target.mkdir()
            (target / "meta.cpp").write_text("publishedid = 123;", encoding="utf-8")
            (target / "payload.pbo").write_bytes(b"payload")

            first = repair_dayz_workshop_links(paths, [(123, "Test Mod")])
            second = repair_dayz_workshop_links(paths, [(123, "Renamed Mod")])

            self.assertEqual(first.created, 1)
            self.assertEqual(second.created, 0)
            self.assertEqual(second.already_ok, 1)
            self.assertFalse((paths.dayz_root / "!Workshop" / "@Renamed Mod").exists())

    def test_does_not_delete_occupied_normal_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            paths = self._paths(Path(tmp))
            target = paths.workshop_content / "123"
            target.mkdir()
            (target / "payload.pbo").write_bytes(b"payload")
            occupied = paths.dayz_root / "!Workshop" / "@Test Mod"
            occupied.mkdir(parents=True)
            sentinel = occupied / "keep.txt"
            sentinel.write_text("keep", encoding="utf-8")

            result = repair_dayz_workshop_links(paths, [(123, "Test Mod")])

            self.assertEqual(result.created, 0)
            self.assertTrue(result.errors)
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "keep")


if __name__ == "__main__":
    unittest.main()
