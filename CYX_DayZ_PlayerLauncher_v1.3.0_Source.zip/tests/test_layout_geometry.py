import unittest

from cyx_launcher.layout import floating_left_panel_geometry


class LayoutGeometryTests(unittest.TestCase):
    def test_same_logical_geometry_across_dpi_scales(self) -> None:
        baseline = floating_left_panel_geometry(420, 790, 1.0)
        scaled_150 = floating_left_panel_geometry(630, 1185, 1.5)
        scaled_200 = floating_left_panel_geometry(840, 1580, 2.0)

        self.assertEqual(baseline, scaled_150)
        self.assertEqual(baseline, scaled_200)

    def test_minimum_size_is_logical_not_physical(self) -> None:
        _x, _y, width, height = floating_left_panel_geometry(300, 500, 2.0)

        self.assertEqual(width, 280.0)
        self.assertEqual(height, 560.0)


if __name__ == "__main__":
    unittest.main()
