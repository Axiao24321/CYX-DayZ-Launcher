import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from cyx_launcher.steam_paths import SteamPaths
from cyx_launcher.workshop import ModStatus, compute_download_progress


class Probe:
    def __init__(self, downloaded: int, total: int, state: int = 0) -> None:
        self.downloaded = downloaded
        self.total = total
        self.state = state


class WorkshopProgressTests(unittest.TestCase):
    def _paths(self) -> SteamPaths:
        root = Path("C:/Steam")
        return SteamPaths(
            steam_root=root,
            dayz_root=root / "steamapps/common/DayZ",
            workshop_content=root / "steamapps/workshop/content/221100",
            workshop_acf=root / "steamapps/workshop/appworkshop_221100.acf",
            steam_exe=root / "steam.exe",
        )

    def _status(self, needs_update: bool = True) -> ModStatus:
        return ModStatus(
            workshop_id=3756677544,
            name="CYX_Hard_PVE",
            present=True,
            local_updated=1,
            remote_updated=2,
            needs_update=needs_update,
            missing=False,
        )

    def test_byte_complete_counts_done_even_if_status_is_stale(self) -> None:
        with patch(
            "cyx_launcher.steam_ugc.read_item_download_progress",
            return_value={3756677544: Probe(995, 1000)},
        ):
            progress = compute_download_progress(
                self._paths(),
                [self._status(needs_update=True)],
                [3756677544],
            )

        self.assertEqual(progress.done, 1)
        self.assertEqual(progress.total, 1)
        self.assertEqual(progress.fraction, 1.0)

    def test_partial_download_stays_pending(self) -> None:
        with patch(
            "cyx_launcher.steam_ugc.read_item_download_progress",
            return_value={3756677544: Probe(500, 1000)},
        ):
            progress = compute_download_progress(
                self._paths(),
                [self._status(needs_update=True)],
                [3756677544],
            )

        self.assertEqual(progress.done, 0)
        self.assertEqual(progress.total, 1)
        self.assertGreater(progress.fraction, 0.49)
        self.assertLess(progress.fraction, 0.51)

    def test_healthy_pending_without_size_counts_done(self) -> None:
        with patch(
            "cyx_launcher.steam_ugc.read_item_download_progress",
            return_value={3756677544: Probe(0, 0, state=32)},
        ):
            progress = compute_download_progress(
                self._paths(),
                [self._status(needs_update=False)],
                [3756677544],
            )

        self.assertEqual(progress.done, 1)
        self.assertEqual(progress.total, 1)
        self.assertEqual(progress.fraction, 1.0)

    def test_outdated_pending_without_size_waits_for_steam(self) -> None:
        with patch(
            "cyx_launcher.steam_ugc.read_item_download_progress",
            return_value={3756677544: Probe(0, 0, state=45)},
        ):
            progress = compute_download_progress(
                self._paths(),
                [self._status(needs_update=True)],
                [3756677544],
            )

        self.assertEqual(progress.done, 0)
        self.assertEqual(progress.total, 1)
        self.assertLess(progress.fraction, 0.1)

    def test_progress_shows_only_aggregated_actual_network_download(self) -> None:
        plans = {
            3756677544: SimpleNamespace(downloaded=1024, download_total=2048),
            999: SimpleNamespace(downloaded=2048, download_total=4096),
        }
        other = ModStatus(
            workshop_id=999,
            name="Other",
            present=False,
            local_updated=None,
            remote_updated=2,
            needs_update=False,
            missing=True,
        )
        with (
            patch(
                "cyx_launcher.steam_ugc.read_item_download_progress",
                return_value={
                    3756677544: Probe(10, 100),
                    999: Probe(10, 100),
                },
            ),
            patch(
                "cyx_launcher.steam_ugc.read_workshop_update_plans",
                return_value=plans,
            ) as read_plans,
        ):
            progress = compute_download_progress(
                self._paths(),
                [self._status(needs_update=True), other],
                [3756677544, 999],
                content_log_offset=123,
            )

        self.assertIn("实际下载", progress.detail)
        self.assertNotIn("本地复用", progress.detail)
        self.assertNotIn("Steam 文件处理", progress.detail)
        read_plans.assert_called_once_with(
            self._paths(),
            [3756677544, 999],
            content_log_offset=123,
        )


if __name__ == "__main__":
    unittest.main()
