import tempfile
import unittest
from pathlib import Path

from cyx_launcher.steam_paths import SteamPaths
from cyx_launcher.steam_ugc import read_workshop_download_events


class WorkshopDownloadEventTests(unittest.TestCase):
    def _paths(self, root: Path) -> SteamPaths:
        return SteamPaths(
            steam_root=root,
            dayz_root=root / "steamapps/common/DayZ",
            workshop_content=root / "steamapps/workshop/content/221100",
            workshop_acf=root / "steamapps/workshop/appworkshop_221100.acf",
            steam_exe=root / "steam.exe",
        )

    def test_reports_content_source_failure_in_plain_chinese(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            logs = root / "logs"
            logs.mkdir()
            (logs / "workshop_log.txt").write_text(
                "\n".join(
                    [
                        "[2026-07-23 18:15:36] [AppID 221100] Download item 3756677544 requested by app",
                        '[2026-07-23 18:16:44] [AppID 221100] Update canceled: Failed updating depot 221100 (Content unavailable) "No Download Source"',
                        "[2026-07-23 18:16:44] [AppID 221100] Download item 3756677544 result : Failure",
                    ]
                ),
                encoding="utf-8",
            )

            event = read_workshop_download_events(
                self._paths(root), [3756677544]
            )[3756677544]

        self.assertEqual(event.status, "failure")
        self.assertIn("Steam CDN", event.message)

    def test_new_request_supersedes_previous_failure(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            logs = root / "logs"
            logs.mkdir()
            (logs / "workshop_log.txt").write_text(
                "\n".join(
                    [
                        "[2026-07-23 18:16:44] [AppID 221100] Download item 3756677544 result : Failure",
                        "[2026-07-23 18:17:00] [AppID 221100] Download item 3756677544 requested by app",
                    ]
                ),
                encoding="utf-8",
            )

            event = read_workshop_download_events(
                self._paths(root), [3756677544]
            )[3756677544]

        self.assertEqual(event.status, "pending")

    def test_operation_offset_ignores_historical_failure(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            logs = root / "logs"
            logs.mkdir()
            log = logs / "workshop_log.txt"
            log.write_text(
                "[2026-08-01 10:00:00] [AppID 221100] Download item 123 requested by app\n"
                "[2026-08-01 10:00:01] [AppID 221100] Download item 123 result : Failure\n",
                encoding="utf-8",
            )
            offset = log.stat().st_size
            with log.open("a", encoding="utf-8") as stream:
                stream.write(
                    "[2026-08-01 10:05:00] [AppID 221100] "
                    "Download item 456 requested by app\n"
                )

            events = read_workshop_download_events(
                self._paths(root),
                [123],
                log_offset=offset,
            )

        self.assertEqual(events, {})


if __name__ == "__main__":
    unittest.main()
