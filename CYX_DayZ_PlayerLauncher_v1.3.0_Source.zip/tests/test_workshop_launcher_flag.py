import unittest

from cyx_launcher.workshop import _launcher_flag_is_stale


class Probe:
    downloaded = 1000
    total = 1000
    state = 5


class PendingHealthyProbe:
    downloaded = 0
    total = 0
    state = 37


class WorkshopLauncherFlagTests(unittest.TestCase):
    def test_launcher_flag_is_stale_when_manifest_and_bytes_are_complete(self) -> None:
        installed = {
            "manifest": "560190878239618649",
            "timeupdated": "1783876875",
        }
        details = {
            "manifest": "560190878239618649",
            "latest_manifest": "560190878239618649",
            "latest_timeupdated": "1783876875",
            "BytesDownloaded": "213432768",
            "BytesToDownload": "213432768",
        }

        self.assertTrue(_launcher_flag_is_stale(installed, details, Probe()))

    def test_launcher_flag_is_not_stale_when_acf_has_new_manifest(self) -> None:
        installed = {
            "manifest": "old",
            "timeupdated": "100",
        }
        details = {
            "latest_manifest": "new",
            "latest_timeupdated": "200",
            "BytesDownloaded": "0",
            "BytesToDownload": "1000",
        }

        self.assertFalse(_launcher_flag_is_stale(installed, details, None))

    def test_pending_only_with_matching_manifest_is_stale(self) -> None:
        installed = {"manifest": "same", "timeupdated": "100"}
        details = {
            "latest_manifest": "same",
            "latest_timeupdated": "100",
        }

        self.assertTrue(
            _launcher_flag_is_stale(installed, details, PendingHealthyProbe())
        )


if __name__ == "__main__":
    unittest.main()
