import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from cyx_launcher.steam_paths import SteamPaths
from cyx_launcher.steam_ugc import read_workshop_update_plans
from cyx_launcher.workshop import _steam_probe_hint


class SteamContentLogTests(unittest.TestCase):
    def _paths(self, root: Path) -> SteamPaths:
        return SteamPaths(
            steam_root=root,
            dayz_root=root / "steamapps/common/DayZ",
            workshop_content=root / "steamapps/workshop/content/221100",
            workshop_acf=root / "steamapps/workshop/appworkshop_221100.acf",
            steam_exe=root / "steam.exe",
        )

    def test_reads_network_reuse_and_stage_bytes_for_each_workshop_item(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            logs = root / "logs"
            logs.mkdir()
            (logs / "content_log.txt").write_text(
                "\n".join(
                    [
                        "Validating active workshop item 3759985985 ...",
                        "AppID 221100 update started : download 0/80702048, store 0/0, reuse 0/5165484088, delta 0/0, stage 0/5485810978",
                        "Validating active workshop item 3756677544 ...",
                        "AppID 221100 update started : download 0/3709184, store 0/0, reuse 0/245471619, delta 0/0, stage 0/271070393",
                    ]
                ),
                encoding="utf-8",
            )

            plans = read_workshop_update_plans(
                self._paths(root), [3759985985, 3756677544]
            )

        self.assertEqual(plans[3759985985].download_total, 80702048)
        self.assertEqual(plans[3759985985].reuse_total, 5165484088)
        self.assertEqual(plans[3759985985].stage_total, 5485810978)
        self.assertEqual(plans[3756677544].download_total, 3709184)

    def test_hint_does_not_call_disk_processing_network_download(self) -> None:
        probe = SimpleNamespace(downloaded=0, total=4313000000)
        plan = SimpleNamespace(
            download_total=80702048,
            reuse_total=5165484088,
            stage_total=5485810978,
        )

        hint = _steam_probe_hint(probe, plan)

        self.assertIn("实际下载约 77.0 MB", hint)
        self.assertNotIn("本地复用", hint)
        self.assertNotIn("Steam 文件处理", hint)
        self.assertNotIn("下载中", hint)

    def test_batch_offset_ignores_previous_download_plan(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            logs = root / "logs"
            logs.mkdir()
            log = logs / "content_log.txt"
            log.write_text(
                "Validating active workshop item 111 ...\n"
                "AppID 221100 update started : download 0/999999999, store 0/0, "
                "reuse 0/0, delta 0/0, stage 0/999999999\n",
                encoding="utf-8",
            )
            offset = log.stat().st_size
            with log.open("a", encoding="utf-8") as stream:
                stream.write(
                    "Validating active workshop item 222 ...\n"
                    "AppID 221100 update started : download 0/4096, store 0/0, "
                    "reuse 0/0, delta 0/0, stage 0/4096\n"
                )

            plans = read_workshop_update_plans(
                self._paths(root),
                [111, 222],
                content_log_offset=offset,
            )

        self.assertNotIn(111, plans)
        self.assertEqual(plans[222].download_total, 4096)


if __name__ == "__main__":
    unittest.main()
