import json
import logging
import tempfile
import unittest
from pathlib import Path

from cyx_launcher.diagnostics import LOGGER_NAME, configure_diagnostics, log_event


class DiagnosticsTests(unittest.TestCase):
    def tearDown(self) -> None:
        logger = logging.getLogger(LOGGER_NAME)
        for handler in list(logger.handlers):
            handler.close()
            logger.removeHandler(handler)
        setattr(logger, "_cyx_configured", False)
        setattr(logger, "_cyx_log_path", "")

    def test_json_log_redacts_sensitive_fields(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = configure_diagnostics(Path(tmp))
            log_event(
                "test_event",
                operation_id="check-123",
                workshop_id=42,
                steam_api_key="do-not-log",
            )
            for handler in logging.getLogger(LOGGER_NAME).handlers:
                handler.flush()
            payload = json.loads(path.read_text(encoding="utf-8").strip())
            logger = logging.getLogger(LOGGER_NAME)
            for handler in list(logger.handlers):
                handler.close()
                logger.removeHandler(handler)
            setattr(logger, "_cyx_configured", False)
            setattr(logger, "_cyx_log_path", "")

        self.assertEqual(payload["operation_id"], "check-123")
        self.assertEqual(payload["workshop_id"], 42)
        self.assertEqual(payload["steam_api_key"], "***REDACTED***")


if __name__ == "__main__":
    unittest.main()
