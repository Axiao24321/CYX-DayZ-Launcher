from __future__ import annotations

import unittest
from unittest.mock import patch

from cyx_launcher.config import get_update_manifest_url, get_update_manifest_urls


class UpdateSourceConfigTests(unittest.TestCase):
    def test_multiple_sources_are_ordered_and_deduplicated(self) -> None:
        with patch(
            "cyx_launcher.config._load_json",
            return_value={
                "update_manifest_urls": [
                    "https://primary.example/latest.json",
                    "https://backup.example/latest.json",
                    "https://primary.example/latest.json",
                ],
                "update_manifest_url": "https://legacy.example/latest.json",
            },
        ):
            self.assertEqual(
                get_update_manifest_urls(),
                [
                    "https://primary.example/latest.json",
                    "https://backup.example/latest.json",
                    "https://legacy.example/latest.json",
                ],
            )
            self.assertEqual(get_update_manifest_url(), "https://primary.example/latest.json")

    def test_legacy_single_source_remains_supported(self) -> None:
        with patch(
            "cyx_launcher.config._load_json",
            return_value={"update_manifest_url": "https://legacy.example/latest.json"},
        ):
            self.assertEqual(get_update_manifest_urls(), ["https://legacy.example/latest.json"])


if __name__ == "__main__":
    unittest.main()
