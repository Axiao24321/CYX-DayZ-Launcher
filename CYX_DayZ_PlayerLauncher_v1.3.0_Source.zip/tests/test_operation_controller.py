import unittest

from cyx_launcher.operation import OperationController


class OperationControllerTests(unittest.TestCase):
    def test_new_operation_invalidates_previous_callback(self) -> None:
        controller = OperationController()
        repair = controller.begin("repair")
        refresh = controller.begin("check")

        self.assertFalse(controller.is_current(repair))
        self.assertTrue(controller.is_current(refresh))
        self.assertNotEqual(repair.operation_id, refresh.operation_id)

    def test_cancel_invalidates_active_operation(self) -> None:
        controller = OperationController()
        token = controller.begin("repair")

        controller.cancel()

        self.assertFalse(controller.is_current(token))
        self.assertEqual(controller.active_kind, "")


if __name__ == "__main__":
    unittest.main()
