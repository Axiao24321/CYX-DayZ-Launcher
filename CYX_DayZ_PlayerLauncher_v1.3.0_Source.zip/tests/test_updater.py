from __future__ import annotations

import hashlib
import base64
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from cyx_launcher.updater import (
    UpdateManifest,
    download_update,
    fetch_update_manifest_from_urls,
    is_newer_version,
    parse_manifest,
    run_update_helper,
    version_tuple,
    _version_matches,
    canonical_manifest_payload,
    verify_manifest_signature,
)


class FakeResponse:
    def __init__(self, chunks: list[bytes]) -> None:
        self.chunks = chunks

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def raise_for_status(self) -> None:
        return None

    def iter_content(self, chunk_size: int):
        del chunk_size
        yield from self.chunks


class FailingResponse(FakeResponse):
    def raise_for_status(self) -> None:
        raise RuntimeError("mirror unavailable")


class UpdaterTests(unittest.TestCase):
    def _signed_manifest(self) -> tuple[dict, str]:
        private = Ed25519PrivateKey.generate()
        public = private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        raw = {
            "version": "1.3.0",
            "mandatory": True,
            "url": "https://updates.example/launcher.exe",
            "sha256": "a" * 64,
            "size": 123,
        }
        signature = private.sign(canonical_manifest_payload(raw))
        raw["signature"] = {
            "algorithm": "ed25519",
            "key_id": "cyx-update-2026-01",
            "value": base64.b64encode(signature).decode("ascii"),
        }
        return raw, base64.b64encode(public).decode("ascii")

    def test_version_comparison_is_numeric(self) -> None:
        self.assertEqual(version_tuple("v1.2.0"), (1, 2, 0))
        self.assertTrue(is_newer_version("1.10.0", "1.9.9"))
        self.assertFalse(is_newer_version("1.2", "1.2.0"))
        self.assertTrue(_version_matches("1.3.0.0", "1.3.0"))
        self.assertFalse(_version_matches("1.2.9.0", "1.3.0"))

    def test_manifest_requires_https_and_sha256(self) -> None:
        parsed = parse_manifest(
            {
                "version": "1.2.0",
                "mandatory": True,
                "url": "https://updates.example/launcher.exe",
                "sha256": "a" * 64,
                "size": 123,
                "notes": "test",
            }
        )
        self.assertTrue(parsed.mandatory)
        with self.assertRaises(ValueError):
            parse_manifest(
                {
                    "version": "1.2.0",
                    "url": "http://updates.example/launcher.exe",
                    "sha256": "a" * 64,
                    "size": 123,
                }
            )

    def test_manifest_signature_is_required_and_tamper_evident(self) -> None:
        raw, public = self._signed_manifest()
        with patch("cyx_launcher.updater.UPDATE_PUBLIC_KEY_B64", public):
            self.assertEqual(verify_manifest_signature(raw), "cyx-update-2026-01")
            tampered = json.loads(json.dumps(raw))
            tampered["size"] = 124
            with self.assertRaisesRegex(ValueError, "签名校验失败"):
                verify_manifest_signature(tampered)
            with self.assertRaisesRegex(ValueError, "缺少"):
                verify_manifest_signature({"version": "1.3.0"})

    def test_download_verifies_size_and_hash(self) -> None:
        payload = b"CYX launcher update"
        manifest = UpdateManifest(
            version="1.2.0",
            mandatory=True,
            url="https://updates.example/launcher.exe",
            sha256=hashlib.sha256(payload).hexdigest(),
            size=len(payload),
        )
        progress: list[tuple[int, int]] = []
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get", return_value=FakeResponse([payload[:5], payload[5:]])
        ):
            result = download_update(manifest, lambda done, total: progress.append((done, total)), Path(temp))
            self.assertEqual(result.read_bytes(), payload)
            self.assertEqual(progress[-1], (len(payload), len(payload)))

    def test_download_rejects_bad_hash_and_removes_partial(self) -> None:
        payload = b"tampered"
        manifest = UpdateManifest(
            version="1.2.0",
            mandatory=True,
            url="https://updates.example/launcher.exe",
            sha256="0" * 64,
            size=len(payload),
        )
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get", return_value=FakeResponse([payload])
        ):
            with self.assertRaises(ValueError):
                download_update(manifest, destination_dir=Path(temp))
            self.assertEqual(list(Path(temp).glob("*.part")), [])

    def test_manifest_and_download_support_verified_parts(self) -> None:
        one, two = b"first-part", b"second-part"
        whole = one + two
        manifest = parse_manifest(
            {
                "version": "1.2.1",
                "mandatory": True,
                "url": "https://updates.example/launcher.exe",
                "sha256": hashlib.sha256(whole).hexdigest(),
                "size": len(whole),
                "parts": [
                    {"url": "https://updates.example/1", "sha256": hashlib.sha256(one).hexdigest(), "size": len(one)},
                    {"url": "https://updates.example/2", "sha256": hashlib.sha256(two).hexdigest(), "size": len(two)},
                ],
            }
        )
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get",
            side_effect=[FakeResponse([one]), FakeResponse([two])],
        ):
            result = download_update(manifest, destination_dir=Path(temp))
            self.assertEqual(result.read_bytes(), whole)

    def test_download_falls_back_to_verified_part_mirror(self) -> None:
        payload = b"mirror-payload"
        manifest = parse_manifest(
            {
                "version": "1.2.3",
                "mandatory": True,
                "url": "https://primary.example/launcher.exe",
                "mirrors": ["https://backup.example/launcher.exe"],
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )
        with tempfile.TemporaryDirectory() as temp, patch(
            "cyx_launcher.updater.requests.get",
            side_effect=[FailingResponse([]), FakeResponse([payload])],
        ):
            result = download_update(manifest, destination_dir=Path(temp))
            self.assertEqual(result.read_bytes(), payload)

    def test_manifest_check_falls_back_to_second_source(self) -> None:
        expected = UpdateManifest(
            version="1.2.3",
            mandatory=True,
            url="https://backup.example/launcher.exe",
            sha256="a" * 64,
            size=123,
        )
        with patch(
            "cyx_launcher.updater.fetch_update_manifest",
            side_effect=[RuntimeError("primary unavailable"), expected],
        ) as fetch:
            result = fetch_update_manifest_from_urls(
                ["https://primary.example/latest.json", "https://backup.example/latest.json"]
            )
        self.assertEqual(result, expected)
        self.assertEqual(fetch.call_count, 2)

    def test_update_helper_restores_previous_exe_on_install_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer = root / "setup.exe"
            installed = root / "launcher.exe"
            installer.write_bytes(b"installer")
            installed.write_bytes(b"old-version")
            with (
                patch("cyx_launcher.updater._wait_for_process_exit"),
                patch(
                    "cyx_launcher.updater.subprocess.run",
                    return_value=SimpleNamespace(returncode=5),
                ),
                patch("cyx_launcher.updater.subprocess.Popen") as popen,
                patch("cyx_launcher.updater._show_helper_error"),
                patch("cyx_launcher.diagnostics.configure_diagnostics"),
                patch("cyx_launcher.diagnostics.log_event"),
            ):
                result = run_update_helper(installer, 123, installed, "1.3.0")

            self.assertEqual(result, 1)
            self.assertEqual(installed.read_bytes(), b"old-version")
            popen.assert_called_once_with([str(installed)], close_fds=True)

    def test_update_helper_verifies_installed_version_before_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer = root / "setup.exe"
            installed = root / "launcher.exe"
            installer.write_bytes(b"installer")
            installed.write_bytes(b"old-version")
            with (
                patch("cyx_launcher.updater._wait_for_process_exit"),
                patch(
                    "cyx_launcher.updater.subprocess.run",
                    return_value=SimpleNamespace(returncode=0),
                ),
                patch("cyx_launcher.updater._windows_file_version", return_value="1.3.0.0"),
                patch("cyx_launcher.updater.subprocess.Popen") as popen,
                patch("cyx_launcher.diagnostics.configure_diagnostics"),
                patch("cyx_launcher.diagnostics.log_event"),
            ):
                result = run_update_helper(installer, 123, installed, "1.3.0")

            self.assertEqual(result, 0)
            popen.assert_called_once_with([str(installed)], close_fds=True)


if __name__ == "__main__":
    unittest.main()
