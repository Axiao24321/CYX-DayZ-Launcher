import unittest
from types import SimpleNamespace
from unittest.mock import patch

from cyx_launcher.server_query import query_server_mods, query_server_population


class ServerPopulationTests(unittest.TestCase):
    @patch("a2s.info")
    def test_population_uses_a2s_player_fields(self, info) -> None:
        info.return_value = SimpleNamespace(player_count=17, max_players=60)

        result = query_server_population("127.0.0.1", 2305, retries=1)

        self.assertEqual((result.player_count, result.max_players), (17, 60))
        info.assert_called_once_with(("127.0.0.1", 2305), timeout=4.0)

    @patch("a2s.info")
    @patch("cyx_launcher.server_query.dayzquery.dayz_rules")
    def test_mod_query_keeps_population_in_report(self, dayz_rules, info) -> None:
        dayz_rules.return_value = SimpleNamespace(
            mods=[SimpleNamespace(workshop_id=123, name="Test Mod")],
            dlc_flags=0,
            description="Fallback name",
        )
        info.return_value = SimpleNamespace(
            server_name="CYX Test",
            map_name="chernarusplus",
            player_count=8,
            max_players=40,
        )

        result = query_server_mods("127.0.0.1", 2305, retries=1)

        self.assertEqual(result.server_name, "CYX Test")
        self.assertEqual(result.map_name, "chernarusplus")
        self.assertEqual((result.player_count, result.max_players), (8, 40))


if __name__ == "__main__":
    unittest.main()
