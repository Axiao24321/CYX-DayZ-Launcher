import unittest
from unittest.mock import MagicMock, call, patch

from cyx_launcher.game_process import DAYZ_CLIENT_PROCESSES, close_dayz_client


class CloseGameTests(unittest.TestCase):
    def test_allowed_targets_exclude_server_and_steam(self) -> None:
        self.assertEqual(DAYZ_CLIENT_PROCESSES, ("DayZ_x64.exe", "DayZ_BE.exe"))
        self.assertNotIn("DayZServer_x64.exe", DAYZ_CLIENT_PROCESSES)
        self.assertNotIn("steam.exe", tuple(name.lower() for name in DAYZ_CLIENT_PROCESSES))

    @patch("cyx_launcher.game_process.subprocess.run")
    @patch("cyx_launcher.game_process._is_process_running")
    def test_closes_only_detected_client_processes(self, is_running, run) -> None:
        is_running.side_effect = lambda name: name == "DayZ_x64.exe"
        run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        result = close_dayz_client()

        self.assertEqual(result.closed_processes, ("DayZ_x64.exe",))
        self.assertFalse(result.errors)
        command = run.call_args.args[0]
        self.assertEqual(command, ["taskkill", "/IM", "DayZ_x64.exe", "/T", "/F"])
        self.assertNotIn("DayZServer_x64.exe", command)

    @patch("cyx_launcher.game_process.subprocess.run")
    @patch("cyx_launcher.game_process._is_process_running", return_value=False)
    def test_no_running_game_does_not_call_taskkill(self, _is_running, run) -> None:
        result = close_dayz_client()

        self.assertFalse(result.closed)
        self.assertEqual(result.message, "DayZ 游戏客户端当前未运行。")
        run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
