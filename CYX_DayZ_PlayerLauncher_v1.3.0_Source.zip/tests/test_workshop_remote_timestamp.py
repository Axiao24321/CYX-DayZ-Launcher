import unittest

from cyx_launcher.workshop import _remote_metadata_is_newer


class WorkshopRemoteTimestampTests(unittest.TestCase):
    def test_authenticated_remote_timestamp_detects_new_publish_before_state_flag(self) -> None:
        self.assertTrue(
            _remote_metadata_is_newer(
                1784135995,
                1784192939,
                remote_ok=True,
            )
        )

    def test_equal_timestamp_is_current(self) -> None:
        self.assertFalse(
            _remote_metadata_is_newer(
                1784192939,
                1784192939,
                remote_ok=True,
            )
        )

    def test_unavailable_remote_metadata_cannot_mark_update(self) -> None:
        self.assertFalse(
            _remote_metadata_is_newer(
                1784135995,
                1784192939,
                remote_ok=False,
            )
        )


if __name__ == "__main__":
    unittest.main()
