import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from cyx_launcher.workshop import trigger_workshop_downloads


class WorkshopTriggerTests(unittest.TestCase):
    def _paths(self, root: Path):
        steam_exe = root / "steam.exe"
        steam_exe.touch()
        return SimpleNamespace(
            steam_exe=steam_exe,
            steam_root=root,
            workshop_acf=root / "appworkshop_221100.acf",
        )

    @patch("cyx_launcher.steam_profile.load_steam_profile", return_value=None)
    @patch("cyx_launcher.steam_paths.ensure_dayz_workshop_subscriptions", return_value=(None, []))
    @patch("cyx_launcher.steam_ugc.force_download_items", return_value=(2, "ok"))
    @patch("subprocess.Popen")
    def test_successful_steamworks_repair_does_not_also_queue_cli(
        self, popen, _force, _ensure, _profile
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            paths = self._paths(Path(tmp))
            trigger_workshop_downloads(paths, [111, 222, 111], fast_repair=True)

        # 修理只通过 Steamworks 下达，不打开下载页，也不重复执行 CLI。
        popen.assert_not_called()
        _ensure.assert_not_called()

    @patch("cyx_launcher.workshop.time.sleep")
    @patch("cyx_launcher.steam_profile.load_steam_profile", return_value=None)
    @patch("cyx_launcher.steam_paths.ensure_dayz_workshop_subscriptions", return_value=(None, []))
    @patch("cyx_launcher.steam_ugc.force_download_items", return_value=(0, "failed"))
    @patch("subprocess.Popen")
    def test_failed_official_repair_never_falls_back_to_cli(
        self, popen, force, _ensure, _profile, sleep
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            paths = self._paths(Path(tmp))
            with self.assertRaisesRegex(RuntimeError, "failed"):
                trigger_workshop_downloads(paths, [111, 222], fast_repair=True)

        popen.assert_not_called()
        self.assertEqual(force.call_count, 3)
        self.assertEqual(sleep.call_count, 2)

    @patch("cyx_launcher.workshop.time.sleep")
    @patch("cyx_launcher.steam_profile.load_steam_profile", return_value=None)
    @patch("cyx_launcher.steam_paths.ensure_dayz_workshop_subscriptions", return_value=(None, []))
    @patch("cyx_launcher.steam_ugc.force_download_items", return_value=(0, "failed"))
    @patch("subprocess.Popen")
    def test_failed_steamworks_never_rewrites_acf(
        self, _popen, _force, _ensure, _profile, _sleep
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            paths = self._paths(Path(tmp))
            sentinel = b'"AppWorkshop"\n{\n\t"unchanged"\t"1"\n}\n'
            paths.workshop_acf.write_bytes(sentinel)
            with self.assertRaisesRegex(RuntimeError, "failed"):
                trigger_workshop_downloads(paths, [111], fast_repair=True)
            self.assertEqual(paths.workshop_acf.read_bytes(), sentinel)


if __name__ == "__main__":
    unittest.main()
