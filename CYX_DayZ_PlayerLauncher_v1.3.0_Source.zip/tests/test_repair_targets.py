import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from cyx_launcher.service import (
    LauncherService,
    SyncReport,
    _missing_workshop_ids,
    _preserve_remote_update_evidence,
    _repair_target_ids,
)
from cyx_launcher.workshop import ModStatus


def status(
    workshop_id: int,
    *,
    present: bool = True,
    needs_update: bool = False,
    missing: bool = False,
) -> ModStatus:
    return ModStatus(
        workshop_id=workshop_id,
        name=f"mod-{workshop_id}",
        present=present,
        local_updated=1 if present else None,
        remote_updated=1,
        needs_update=needs_update,
        missing=missing,
    )


class RepairTargetTests(unittest.TestCase):
    def test_lightweight_refresh_keeps_confirmed_remote_update_blocked(self) -> None:
        previous = ModStatus(
            workshop_id=101,
            name="mod-101",
            present=True,
            local_updated=100,
            remote_updated=200,
            remote_size=4096,
            needs_update=True,
            missing=False,
            downloading_hint="有更新（Steam 在线元数据）",
        )
        current = ModStatus(
            workshop_id=101,
            name="mod-101",
            present=True,
            local_updated=100,
            remote_updated=None,
            needs_update=False,
            missing=False,
        )

        _preserve_remote_update_evidence(previous, current)

        self.assertTrue(current.needs_update)
        self.assertEqual(current.remote_updated, 200)
        self.assertEqual(current.remote_size, 4096)
        self.assertIn("等待 Steam 完成", current.downloading_hint)

    def test_lightweight_refresh_releases_gate_after_local_manifest_catches_up(self) -> None:
        previous = ModStatus(
            workshop_id=101,
            name="mod-101",
            present=True,
            local_updated=100,
            remote_updated=200,
            needs_update=True,
            missing=False,
        )
        current = ModStatus(
            workshop_id=101,
            name="mod-101",
            present=True,
            local_updated=200,
            remote_updated=None,
            needs_update=False,
            missing=False,
        )

        _preserve_remote_update_evidence(previous, current)

        self.assertFalse(current.needs_update)
        self.assertEqual(current.remote_updated, 200)

    @patch("cyx_launcher.service.evaluate_mods")
    def test_report_refresh_cannot_temporarily_open_join_gate(self, evaluate_mods) -> None:
        paths = MagicMock()
        previous = ModStatus(
            workshop_id=101,
            name="mod-101",
            present=True,
            local_updated=100,
            remote_updated=200,
            needs_update=True,
            missing=False,
        )
        evaluate_mods.return_value = [
            ModStatus(
                workshop_id=101,
                name="mod-101",
                present=True,
                local_updated=100,
                remote_updated=None,
                needs_update=False,
                missing=False,
            )
        ]
        service = LauncherService.__new__(LauncherService)
        service.launcher = {"steam_api_key": ""}
        service.resolve = MagicMock(return_value=paths)
        service.last_report = SyncReport(
            server_name="test",
            map_name="chernarusplus",
            statuses=[previous],
            can_join=False,
            gate_message="待更新 1 个。更新完成前禁止进入服务器。",
            paths=paths,
        )

        refreshed = service.refresh_current_report(refresh_remote=False)

        self.assertFalse(refreshed.can_join)
        self.assertTrue(refreshed.statuses[0].needs_update)
        self.assertIn("待更新 1 个", refreshed.gate_message)

    def test_selects_missing_and_authoritatively_outdated_mods(self) -> None:
        statuses = [
            status(101),
            status(102, needs_update=True),
            status(103, present=False, missing=True),
        ]

        self.assertEqual(
            _repair_target_ids(statuses, {101: False, 102: False, 103: False}),
            [102, 103],
        )
        self.assertEqual(_repair_target_ids(statuses, {}), [102, 103])
        self.assertEqual(_repair_target_ids(statuses, {102: True}), [102, 103])

    def test_all_healthy_returns_no_targets(self) -> None:
        statuses = [status(101), status(102), status(103)]

        self.assertEqual(_repair_target_ids(statuses, {}), [])

    def test_missing_subscription_targets_are_unique_workshop_items(self) -> None:
        statuses = [
            status(101, present=False, missing=True),
            status(101, present=False, missing=True),
            status(102, needs_update=True),
            status(0, present=False, missing=True),
        ]

        self.assertEqual(_missing_workshop_ids(statuses), [101])

    def test_steam_ugc_flag_marks_target(self) -> None:
        statuses = [status(101), status(102), status(103)]

        self.assertEqual(_repair_target_ids(statuses, {102: True}), [102])

    def test_force_all_is_internal_escape_hatch(self) -> None:
        statuses = [status(101), status(0), status(102)]

        self.assertEqual(_repair_target_ids(statuses, {}, force_all=True), [101, 102])

    @patch("cyx_launcher.service.repair_dayz_workshop_links")
    @patch("cyx_launcher.steam_ugc.read_ugc_need_update_flags", return_value={101: True, 102: True})
    @patch("cyx_launcher.steam_ugc.clear_ugc_flag_cache")
    def test_repair_starts_only_first_target(self, _clear, _flags, repair_links) -> None:
        repair_links.return_value = SimpleNamespace(created=0, errors=[])
        service = LauncherService.__new__(LauncherService)
        service.last_report = SimpleNamespace(
            statuses=[status(101, needs_update=True), status(102, needs_update=True)],
            paths=MagicMock(),
        )
        service.query_and_evaluate = MagicMock(return_value=service.last_report)
        service.refresh_current_report = MagicMock(return_value=service.last_report)
        service.trigger_repair_item = MagicMock()

        count, ids = service.repair_outdated_and_missing()

        self.assertEqual((count, ids), (2, [101, 102]))
        service.trigger_repair_item.assert_called_once_with(
            101,
            operation_id="",
            workshop_log_offset=0,
        )

    @patch("cyx_launcher.service.trigger_workshop_downloads")
    def test_trigger_marks_timestamp_outdated_item_for_installed_refresh(self, trigger) -> None:
        service = LauncherService.__new__(LauncherService)
        service.last_report = SimpleNamespace(
            statuses=[status(101, needs_update=True)],
            paths=MagicMock(),
        )

        service.trigger_repair_item(101)

        trigger.assert_called_once_with(
            service.last_report.paths,
            [101],
            fast_repair=True,
            verified_outdated_ids={101},
            workshop_log_offset=0,
        )


if __name__ == "__main__":
    unittest.main()
