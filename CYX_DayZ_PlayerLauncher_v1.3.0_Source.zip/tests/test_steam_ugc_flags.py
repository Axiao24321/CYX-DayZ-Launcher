import unittest
from unittest.mock import MagicMock, patch

from cyx_launcher.steam_ugc import (
    ITEM_DOWNLOAD_PENDING,
    ITEM_DOWNLOADING,
    ITEM_INSTALLED,
    ITEM_LEGACY,
    ITEM_NEEDS_UPDATE,
    ITEM_SUBSCRIBED,
    _SteamUgcDetails,
    _SteamUgcQueryCompleted,
    WorkshopDownloadEvent,
    force_download_items,
    item_needs_download,
    probe_workshop_updates,
    subscribe_workshop_items,
)


class SteamUgcFlagTests(unittest.TestCase):
    def test_official_eitemstate_values(self) -> None:
        self.assertEqual(ITEM_SUBSCRIBED, 1)
        self.assertEqual(ITEM_LEGACY, 2)
        self.assertEqual(ITEM_INSTALLED, 4)
        self.assertEqual(ITEM_NEEDS_UPDATE, 8)
        self.assertEqual(ITEM_DOWNLOADING, 16)
        self.assertEqual(ITEM_DOWNLOAD_PENDING, 32)

    def test_state_five_is_installed_not_outdated(self) -> None:
        state = 5
        self.assertTrue(state & ITEM_SUBSCRIBED)
        self.assertTrue(state & ITEM_INSTALLED)
        self.assertFalse(state & ITEM_NEEDS_UPDATE)

    def test_state_thirteen_is_installed_and_outdated(self) -> None:
        state = 13
        self.assertTrue(state & ITEM_SUBSCRIBED)
        self.assertTrue(state & ITEM_INSTALLED)
        self.assertTrue(state & ITEM_NEEDS_UPDATE)

    def test_queued_update_without_bytes_is_detected(self) -> None:
        # 45 = Subscribed | Installed | NeedsUpdate | DownloadPending
        self.assertTrue(item_needs_download(45, 0, 0))

    def test_healthy_verification_pending_is_not_update(self) -> None:
        # 37 = Subscribed | Installed | DownloadPending
        self.assertFalse(item_needs_download(37, 0, 0))

    def test_stale_partial_bytes_without_update_state_are_ignored(self) -> None:
        self.assertFalse(item_needs_download(5, 100, 1000))

    def test_authenticated_query_struct_layout_matches_v017(self) -> None:
        # 防止 ctypes 布局变化导致朋友可见模组更新时间读错。
        import ctypes

        self.assertEqual(ctypes.sizeof(_SteamUgcQueryCompleted), 280)
        self.assertEqual(ctypes.sizeof(_SteamUgcDetails), 9784)
        self.assertEqual(_SteamUgcDetails.time_updated.offset, 8172)

    @patch("cyx_launcher.steam_ugc.read_item_download_progress", return_value={123: object()})
    def test_legacy_probe_name_is_read_only(self, read_progress) -> None:
        marker = object()
        result = probe_workshop_updates(marker, [123])
        self.assertIn(123, result)
        read_progress.assert_called_once_with(marker, [123])

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_force_download_does_not_resubmit_active_item(self, session_cls, _sleep) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = ITEM_DOWNLOADING | ITEM_DOWNLOAD_PENDING
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = force_download_items(MagicMock(), [123])

        self.assertEqual(count, 1)
        ugc.download_item.assert_not_called()

    @patch(
        "cyx_launcher.steam_ugc.read_workshop_download_events",
        return_value={
            123: WorkshopDownloadEvent(
                workshop_id=123,
                status="failure",
                message="内容源暂不可用",
                key="failure",
            )
        },
    )
    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_force_download_resubmits_active_item_after_logged_failure(
        self, session_cls, _sleep, _events
    ) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = (
            ITEM_SUBSCRIBED
            | ITEM_INSTALLED
            | ITEM_NEEDS_UPDATE
            | ITEM_DOWNLOAD_PENDING
        )
        ugc.download_item.return_value = True
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = force_download_items(MagicMock(), [123])

        self.assertEqual(count, 1)
        ugc.download_item.assert_called_once_with(123, high_priority=False)

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_force_download_matches_official_normal_priority(self, session_cls, _sleep) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = ITEM_SUBSCRIBED | ITEM_INSTALLED | ITEM_NEEDS_UPDATE
        ugc.download_item.return_value = True
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = force_download_items(MagicMock(), [123])

        self.assertEqual(count, 1)
        ugc.download_item.assert_called_once_with(123, high_priority=False)

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_force_download_skips_healthy_installed_item(self, session_cls, _sleep) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = ITEM_SUBSCRIBED | ITEM_INSTALLED
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = force_download_items(MagicMock(), [123])

        self.assertEqual(count, 1)
        ugc.download_item.assert_not_called()
        ugc.subscribe_item.assert_not_called()

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_force_download_refreshes_installed_item_when_remote_timestamp_is_newer(
        self, session_cls, _sleep
    ) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = ITEM_SUBSCRIBED | ITEM_INSTALLED
        ugc.download_item.return_value = True
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = force_download_items(
            MagicMock(),
            [123],
            verified_outdated_ids={123},
        )

        self.assertEqual(count, 1)
        ugc.download_item.assert_called_once_with(123, high_priority=False)
        ugc.subscribe_item.assert_not_called()

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_force_download_resubscribes_without_redownloading_healthy_content(
        self, session_cls, _sleep
    ) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = ITEM_INSTALLED
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = force_download_items(MagicMock(), [123])

        self.assertEqual(count, 1)
        ugc.subscribe_item.assert_called_once_with(123)
        ugc.download_item.assert_not_called()

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_batch_subscription_uses_one_session_and_no_manual_download_for_new_item(
        self, session_cls, _sleep
    ) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = 0
        ugc.subscribe_item.return_value = 42
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = subscribe_workshop_items(MagicMock(), [123, 123])

        self.assertEqual(count, 1)
        ugc.subscribe_item.assert_called_once_with(123)
        ugc.download_item.assert_not_called()
        self.assertEqual(ugc.run_callbacks.call_count, 4)

    @patch("cyx_launcher.steam_ugc.time.sleep")
    @patch("cyx_launcher.steam_ugc.SteamUgcSession")
    def test_batch_subscription_restarts_subscribed_but_missing_item_normally(
        self, session_cls, _sleep
    ) -> None:
        ugc = MagicMock()
        ugc.item_state.return_value = ITEM_SUBSCRIBED
        ugc.download_item.return_value = True
        session_cls.return_value.__enter__.return_value = ugc

        count, _message = subscribe_workshop_items(MagicMock(), [123])

        self.assertEqual(count, 1)
        ugc.subscribe_item.assert_not_called()
        ugc.download_item.assert_called_once_with(123, high_priority=False)


if __name__ == "__main__":
    unittest.main()
