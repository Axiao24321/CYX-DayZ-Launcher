from __future__ import annotations

from dataclasses import dataclass

import dayzquery


@dataclass
class ServerMod:
    workshop_id: int
    name: str

    @property
    def is_workshop(self) -> bool:
        return self.workshop_id > 0


@dataclass
class ServerQueryResult:
    server_name: str
    map_name: str
    mods: list[ServerMod]
    dlc_flags: int = 0
    raw_description: str = ""
    player_count: int | None = None
    max_players: int | None = None


@dataclass(frozen=True)
class ServerPopulation:
    player_count: int
    max_players: int


def query_server_population(
    ip: str,
    query_port: int,
    timeout: float = 4.0,
    retries: int = 2,
) -> ServerPopulation:
    """通过服务器 A2S_INFO 查询当前在线人数，不触碰模组或 Steam 状态。"""
    import a2s

    address = (ip, int(query_port))
    last_err: BaseException | None = None
    for attempt in range(max(1, int(retries))):
        try:
            info = a2s.info(address, timeout=timeout)
            return ServerPopulation(
                player_count=max(0, int(getattr(info, "player_count", 0) or 0)),
                max_players=max(0, int(getattr(info, "max_players", 0) or 0)),
            )
        except Exception as exc:
            last_err = exc
            if attempt + 1 >= max(1, int(retries)):
                break

    assert last_err is not None
    raise TimeoutError(format_query_error(last_err, ip=ip, query_port=int(query_port))) from last_err


def format_query_error(err: BaseException, ip: str = "", query_port: int = 0) -> str:
    """把 python-a2s / socket 超时转成可读中文。"""
    text = str(err).strip() or type(err).__name__
    if text.startswith("查询服务器"):
        return text
    low = text.lower()
    where = f"{ip}:{query_port}" if ip and query_port else ""
    if "timed out" in low or "timeout" in low:
        tip = "查询服务器模组列表超时"
        if where:
            tip += f"（{where}）"
        tip += "。请确认服务器在线、查询端口正确，或稍后重试。"
        return tip
    if where:
        return f"查询服务器失败（{where}）：{text}"
    return f"查询服务器失败：{text}"


def query_server_mods(
    ip: str,
    query_port: int,
    timeout: float = 8.0,
    retries: int = 2,
) -> ServerQueryResult:
    address = (ip, int(query_port))
    last_err: BaseException | None = None

    for attempt in range(max(1, int(retries))):
        try:
            rules = dayzquery.dayz_rules(address, timeout=timeout)
            mods = [
                ServerMod(
                    workshop_id=int(m.workshop_id),
                    name=str(m.name).strip() or f"mod_{m.workshop_id}",
                )
                for m in rules.mods
            ]
            dlc_flags = int(getattr(rules, "dlc_flags", 0) or 0)
            server_name = getattr(rules, "description", "") or ""
            map_name = ""
            player_count = None
            max_players = None
            try:
                import a2s

                info = a2s.info(address, timeout=timeout)
                server_name = info.server_name or server_name
                map_name = info.map_name or ""
                player_count = max(0, int(getattr(info, "player_count", 0) or 0))
                max_players = max(0, int(getattr(info, "max_players", 0) or 0))
            except Exception:
                pass

            return ServerQueryResult(
                server_name=server_name,
                map_name=map_name,
                mods=mods,
                dlc_flags=dlc_flags,
                raw_description=getattr(rules, "description", "") or "",
                player_count=player_count,
                max_players=max_players,
            )
        except Exception as e:
            last_err = e
            if attempt + 1 >= max(1, int(retries)):
                break

    assert last_err is not None
    raise TimeoutError(format_query_error(last_err, ip=ip, query_port=int(query_port))) from last_err
