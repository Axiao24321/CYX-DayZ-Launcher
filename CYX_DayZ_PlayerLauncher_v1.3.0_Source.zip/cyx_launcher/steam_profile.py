from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from .steam_paths import find_steam_root


@dataclass
class SteamProfile:
    steam_id64: str
    persona_name: str
    account_name: str
    avatar_path: Path | None


def _parse_loginusers(vdf_text: str) -> list[dict[str, str]]:
    """解析 Steam config/loginusers.vdf 里的用户块（不依赖 vdf 库）。"""
    users: list[dict[str, str]] = []
    # "7656119..." { ... }
    for m in re.finditer(
        r'"(\d{17})"\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}',
        vdf_text,
        flags=re.DOTALL,
    ):
        sid = m.group(1)
        body = m.group(2)
        fields = dict(re.findall(r'"([^"]+)"\s+"([^"]*)"', body))
        users.append(
            {
                "steam_id64": sid,
                "persona_name": fields.get("PersonaName", "").strip(),
                "account_name": fields.get("AccountName", "").strip(),
                "most_recent": fields.get("MostRecent", "0"),
                "auto_login": fields.get("AutoLogin", "0"),
                "timestamp": fields.get("Timestamp", "0"),
            }
        )
    return users


def _pick_active_user(users: list[dict[str, str]]) -> dict[str, str] | None:
    if not users:
        return None
    for u in users:
        if u.get("most_recent") == "1":
            return u
    for u in users:
        if u.get("auto_login") == "1":
            return u
    return max(users, key=lambda u: int(u.get("timestamp") or "0"))


def _avatar_path(steam_root: Path, steam_id64: str) -> Path | None:
    cand = steam_root / "config" / "avatarcache" / f"{steam_id64}.png"
    if cand.is_file() and cand.stat().st_size > 0:
        return cand
    # 偶发 jpg
    for ext in (".jpg", ".jpeg"):
        alt = steam_root / "config" / "avatarcache" / f"{steam_id64}{ext}"
        if alt.is_file() and alt.stat().st_size > 0:
            return alt
    return None


def load_steam_profile(steam_override: str = "") -> SteamProfile | None:
    """读取本机当前 Steam 账号：昵称、17 位 SteamID64、本地头像缓存。"""
    steam_root = find_steam_root(steam_override)
    if steam_root is None:
        return None
    vdf = steam_root / "config" / "loginusers.vdf"
    if not vdf.is_file():
        return None
    try:
        text = vdf.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
    user = _pick_active_user(_parse_loginusers(text))
    if not user:
        return None
    sid = user["steam_id64"]
    return SteamProfile(
        steam_id64=sid,
        persona_name=user.get("persona_name") or user.get("account_name") or sid,
        account_name=user.get("account_name") or "",
        avatar_path=_avatar_path(steam_root, sid),
    )
