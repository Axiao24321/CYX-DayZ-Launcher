from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import requests

from .diagnostics import log_event
from .steam_paths import (
    DAYZ_APP_ID,
    SteamPaths,
    find_workshop_mod_dir,
    parse_workshop_acf,
    parse_workshop_item_details,
    read_dayz_workshop_subscriptions,
)
from .steam_profile import load_steam_profile


STEAM_DETAILS_URL = "https://api.steampowered.com/ISteamRemoteStorage/GetPublishedFileDetails/v1/"


@dataclass
class ModStatus:
    workshop_id: int
    name: str
    present: bool
    local_updated: int | None
    remote_updated: int | None
    needs_update: bool
    missing: bool
    downloading_hint: str = ""
    is_local_only: bool = False
    remote_size: int | None = None

    @property
    def blocked(self) -> bool:
        return self.missing or self.needs_update


def fetch_remote_details(workshop_ids: Iterable[int], api_key: str = "") -> dict[int, dict]:
    ids = [int(x) for x in workshop_ids if int(x) > 0]
    if not ids:
        return {}
    out: dict[int, dict] = {}
    # Steam allows batches; keep chunks reasonable
    for i in range(0, len(ids), 50):
        chunk = ids[i : i + 50]
        data: dict[str, str] = {"itemcount": str(len(chunk))}
        if api_key:
            data["key"] = api_key
        for idx, wid in enumerate(chunk):
            data[f"publishedfileids[{idx}]"] = str(wid)
        resp = requests.post(STEAM_DETAILS_URL, data=data, timeout=30)
        resp.raise_for_status()
        payload = resp.json().get("response", {})
        for item in payload.get("publishedfiledetails", []):
            wid = int(item.get("publishedfileid") or 0)
            if wid <= 0:
                continue
            # result=1 成功；9=找不到/私有/未列出（匿名 WebAPI 读不到）
            out[wid] = item
    return out


def _int_or_none(value: object) -> int | None:
    try:
        if value is None or value == "":
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _acf_latest_updated(details: dict[str, str] | None) -> int | None:
    if not details:
        return None
    return _int_or_none(details.get("latest_timeupdated")) or _int_or_none(details.get("timeupdated"))


def _remote_metadata_is_newer(
    local_updated: int | None,
    remote_updated: int | None,
    *,
    remote_ok: bool,
) -> bool:
    """
    Steam 登录态/成功 WebAPI 查询返回的线上更新时间比安装时间新时，确认有更新。

    作者刚发布 Workshop 内容后，GetItemState 的 NeedsUpdate 位可能延迟刷新；
    官方 DayZ 启动器仍会依据线上详情把项目标为 Updated，并允许单项维修。
    """
    return bool(
        remote_ok
        and local_updated is not None
        and remote_updated is not None
        and remote_updated > local_updated
    )


def _human_bytes(value: int) -> str:
    size = max(0, int(value))
    if size >= 1024**3:
        return f"{size / 1024**3:.2f} GB"
    return f"{size / 1024**2:.1f} MB"


def _steam_plan_summary(plan: object | None) -> str:
    if plan is None:
        return ""
    network_total = int(getattr(plan, "download_total", 0) or 0)
    network_done = int(getattr(plan, "downloaded", 0) or 0)
    stage_total = int(getattr(plan, "stage_total", 0) or 0)
    if stage_total <= 0:
        return ""
    if network_total <= 0:
        return "实际下载量极小"
    if network_done > 0:
        return f"实际下载 {_human_bytes(network_done)}/{_human_bytes(network_total)}"
    return f"实际下载约 {_human_bytes(network_total)}"


def _steam_plans_summary(plans: list[object]) -> str:
    """汇总当前批次的真实网络下载量，不显示本地校验/复用量。"""
    if not plans:
        return ""
    network_total = sum(int(getattr(plan, "download_total", 0) or 0) for plan in plans)
    network_done = sum(int(getattr(plan, "downloaded", 0) or 0) for plan in plans)
    if network_total <= 0:
        return "实际下载量极小"
    if network_done > 0:
        return f"实际下载 {_human_bytes(network_done)}/{_human_bytes(network_total)}"
    return f"实际下载约 {_human_bytes(network_total)}"


def _steam_probe_hint(probe: object, plan: object | None = None) -> str:
    plan_summary = _steam_plan_summary(plan)
    if plan_summary:
        return f"有更新（{plan_summary}）"
    return "有更新（实际下载量等待 Steam 返回）"


def _acf_needs_update(installed: dict[str, str] | None, details: dict[str, str] | None) -> bool:
    """Steam 本地清单：latest_* 新于已安装，或 manifest 不一致。"""
    if not installed:
        return False
    local_t = _int_or_none(installed.get("timeupdated"))
    latest_t = _acf_latest_updated(details)
    if local_t is not None and latest_t is not None and latest_t > local_t:
        return True
    local_m = (installed.get("manifest") or "").strip()
    latest_m = ""
    if details:
        latest_m = (details.get("latest_manifest") or details.get("manifest") or "").strip()
    if local_m and latest_m and local_m != latest_m:
        return True
    return False


def _bytes_complete(downloaded: int, total: int) -> bool:
    return total > 0 and downloaded >= int(total * 0.995)


def _acf_bytes_complete(details: dict[str, str] | None) -> bool:
    if not details:
        return False
    downloaded = _int_or_none(details.get("BytesDownloaded")) or 0
    total = _int_or_none(details.get("BytesToDownload")) or 0
    return _bytes_complete(downloaded, total)


def _steam_probe_complete(probe: object | None) -> bool:
    if probe is None:
        return False
    downloaded = int(getattr(probe, "downloaded", 0) or 0)
    total = int(getattr(probe, "total", 0) or 0)
    return _bytes_complete(downloaded, total)


def _launcher_flag_is_stale(
    installed: dict[str, str] | None,
    details: dict[str, str] | None,
    probe: object | None,
) -> bool:
    """官方 DayZ Launcher 的 Steam.json 有时不刷新；强证据完整时忽略旧标记。"""
    if _acf_needs_update(installed, details):
        return False
    local_manifest = (installed or {}).get("manifest", "").strip()
    latest_manifest = ""
    if details:
        latest_manifest = (details.get("latest_manifest") or details.get("manifest") or "").strip()
    manifests_match = bool(local_manifest and latest_manifest and local_manifest == latest_manifest)
    state = int(getattr(probe, "state", 0) or 0) if probe is not None else 0
    # 37 = Subscribed|Installed|DownloadPending。单独 Pending 是 DownloadItem
    # 健康校验的常见瞬时状态，不应让官方启动器的旧标记永久卡住门禁。
    steam_confirms_installed = bool(state & 4) and not bool(state & (8 | 16))
    return manifests_match and (
        _acf_bytes_complete(details)
        or _steam_probe_complete(probe)
        or steam_confirms_installed
    )


def _meta_published_id(meta_text: str) -> int | None:
    m = re.search(r"publishedid\s*=\s*(\d+)", meta_text, re.I)
    return int(m.group(1)) if m else None


def _mod_folder(
    paths: SteamPaths,
    workshop_id: int,
    install_folder: Path | None = None,
) -> Path | None:
    return find_workshop_mod_dir(paths, workshop_id, prefer=install_folder)


def _local_mod_folder_exists(
    paths: SteamPaths,
    workshop_id: int,
    install_folder: Path | None = None,
) -> bool:
    """以实际文件夹为准；取消订阅后 ACF 残留不能算已安装。"""
    folder = _mod_folder(paths, workshop_id, install_folder)
    if folder is None:
        return False
    try:
        return any(folder.iterdir())
    except OSError:
        return False


def _find_local_named_mod(paths: SteamPaths, name: str) -> bool:
    if not name:
        return False
    needle = name.strip().lower().replace(" ", "")
    roots = [paths.dayz_root, paths.dayz_root / "!Workshop"]
    for root in roots:
        if not root.exists():
            continue
        for child in root.iterdir():
            if not child.is_dir():
                continue
            n = child.name.lower().replace(" ", "").lstrip("@")
            if needle in n or n in needle:
                return True
    return False


def evaluate_mods(
    paths: SteamPaths,
    mods: list[tuple[int, str]],
    api_key: str = "",
    steam_verify: bool = False,
    refresh_remote: bool = True,
    source_warnings: list[str] | None = None,
    operation_id: str = "",
) -> list[ModStatus]:
    warnings = source_warnings if source_warnings is not None else []

    def source_failed(source: str, exc: BaseException) -> None:
        message = f"{source}不可用: {exc}"
        warnings.append(message)
        log_event(
            "evidence_source_failed",
            operation_id=operation_id,
            category="steam",
            source=source,
            error_type=type(exc).__name__,
            error=str(exc),
        )

    workshop_ids = [wid for wid, _ in mods if wid > 0]
    remote: dict[int, dict] = {}
    if refresh_remote:
        try:
            remote = fetch_remote_details(workshop_ids, api_key=api_key)
        except Exception as exc:
            # WebAPI 读不到时仍可依靠 Steam 本地清单和 SteamUGC 校验。
            remote = {}
            source_failed("Steam 匿名在线详情", exc)
    local_acf = parse_workshop_acf(paths.workshop_acf)
    acf_details = parse_workshop_item_details(paths.workshop_acf)
    install_infos: dict[int, object] = {}
    authenticated_details: dict[int, object] = {}
    steam_probe: dict[int, object] = {}
    update_plans: dict[int, object] = {}
    ugc_flags: dict[int, bool] = {}
    try:
        from .steam_ugc import (
            clear_ugc_flag_cache,
            read_authenticated_item_details,
            read_item_install_infos,
            read_item_download_progress,
            read_workshop_update_plans,
            read_ugc_need_update_flags,
        )
    except Exception as exc:
        source_failed("SteamUGC 模块", exc)
    else:
        try:
            install_infos = read_item_install_infos(paths, workshop_ids, strict=True)
        except Exception as exc:
            source_failed("SteamUGC 安装信息", exc)
        if refresh_remote:
            try:
                authenticated_details = read_authenticated_item_details(
                    paths,
                    workshop_ids,
                    strict=True,
                )
            except Exception as exc:
                source_failed("Steam 登录态在线详情", exc)
        try:
            if steam_verify:
                clear_ugc_flag_cache()
                steam_probe = read_item_download_progress(
                    paths,
                    workshop_ids,
                    strict=True,
                )
                local_acf = parse_workshop_acf(paths.workshop_acf)
                acf_details = parse_workshop_item_details(paths.workshop_acf)
                refreshed_infos = read_item_install_infos(
                    paths,
                    workshop_ids,
                    strict=True,
                )
                if refreshed_infos:
                    install_infos = refreshed_infos
                clear_ugc_flag_cache()
            else:
                steam_probe = read_item_download_progress(
                    paths,
                    workshop_ids,
                    strict=True,
                )
        except Exception as exc:
            source_failed("SteamUGC 下载状态", exc)
        try:
            ugc_flags = read_ugc_need_update_flags(paths, workshop_ids, strict=True)
        except Exception as exc:
            source_failed("SteamUGC 更新标记", exc)
        try:
            update_plans = read_workshop_update_plans(paths, workshop_ids)
        except Exception as exc:
            source_failed("Steam 内容日志", exc)

    if not install_infos:
        try:
            from .steam_ugc import read_item_install_infos

            install_infos = read_item_install_infos(paths, workshop_ids)
        except Exception as exc:
            install_infos = {}
            source_failed("SteamUGC 安装信息回退", exc)
    profile = load_steam_profile(str(paths.steam_root))
    subscribed = read_dayz_workshop_subscriptions(
        paths.steam_root,
        steam_id64=(profile.steam_id64 if profile else ""),
    )

    results: list[ModStatus] = []
    for wid, name in mods:
        if wid <= 0:
            present = _find_local_named_mod(paths, name)
            results.append(
                ModStatus(
                    workshop_id=wid,
                    name=name,
                    present=present,
                    local_updated=None,
                    remote_updated=None,
                    needs_update=False,
                    missing=not present,
                    is_local_only=True,
                    downloading_hint="本地/非 Workshop 模组，需手动放到 DayZ 目录" if not present else "",
                )
            )
            continue

        acf = local_acf.get(str(wid))
        details = acf_details.get(str(wid))
        local_updated = _int_or_none((acf or {}).get("timeupdated"))
        inst = install_infos.get(wid)
        install_folder = inst.folder if inst is not None else None
        steam_install_time = int(inst.timestamp) if inst is not None else 0
        if local_updated is None and steam_install_time > 0:
            local_updated = steam_install_time
        files_ok = _local_mod_folder_exists(paths, wid, install_folder)
        # 能读到订阅表时：取消订阅即使本地残留文件，也视为缺失
        unsubscribed = subscribed is not None and wid not in subscribed
        present = files_ok and not unsubscribed
        remote_item = remote.get(wid)
        api_ok = bool(remote_item) and int(remote_item.get("result", 0) or 0) == 1
        remote_updated = _int_or_none(remote_item.get("time_updated")) if api_ok else None
        authenticated_item = authenticated_details.get(wid)
        authenticated_ok = authenticated_item is not None
        authenticated_updated = (
            int(getattr(authenticated_item, "time_updated", 0) or 0)
            if authenticated_ok
            else 0
        )
        if authenticated_updated > 0 and (
            remote_updated is None or authenticated_updated > remote_updated
        ):
            remote_updated = authenticated_updated
        if remote_updated is None:
            remote_updated = _acf_latest_updated(details)
        title = name
        if api_ok:
            title = (remote_item or {}).get("title") or name
        elif authenticated_ok:
            title = str(getattr(authenticated_item, "title", "") or name)
        remote_ok = api_ok or authenticated_ok
        remote_size = None
        if api_ok and remote_item:
            for key in ("file_size", "file_size_from_bytes", "size"):
                if key in remote_item and remote_item[key] not in (None, ""):
                    remote_size = _int_or_none(remote_item[key])
                    if remote_size is not None:
                        break
        if remote_size is None:
            authenticated_size = (
                int(getattr(authenticated_item, "total_files_size", 0) or 0)
                if authenticated_ok
                else 0
            )
            if authenticated_size > 0:
                remote_size = authenticated_size
        if remote_size is None:
            remote_size = _int_or_none((acf or {}).get("size"))

        needs_update = False
        hint = ""
        if not files_ok:
            hint = "未安装"
        elif unsubscribed:
            hint = "已取消订阅（请点修理重新订阅下载）"
        elif steam_probe.get(wid) and getattr(steam_probe[wid], "pending", False):
            needs_update = True
            hint = _steam_probe_hint(steam_probe[wid], update_plans.get(wid))
        elif ugc_flags.get(wid) is True:
            # 仅当 Steam 明确「已安装且需更新」时采用（见 read_ugc_need_update_flags）
            needs_update = True
            hint = "有更新（Steam 客户端标记）"
        elif _remote_metadata_is_newer(
            local_updated,
            remote_updated,
            remote_ok=remote_ok,
        ):
            # 新发布内容可能已出现在登录态详情中，但 NeedsUpdate 状态位尚未刷新。
            # 线上时间戳是 Steam 权威元数据，可安全地只维修当前这一项。
            needs_update = True
            hint = "有更新（Steam 在线元数据）"
        elif wid not in ugc_flags and _acf_needs_update(acf, details):
            # Steamworks 暂时不可用时才回退本地清单；能读到状态时以状态位为准。
            needs_update = True
            hint = "有更新（Steam 本地清单回退）"
        elif remote_ok and local_updated is None and remote_updated is not None:
            needs_update = False
            hint = "已安装（无本地时间戳）"
        elif not remote_ok:
            hint = "已安装（私有/未列出，深度验证请用官方启动器）"
        else:
            hint = "已是最新（快速检测）"

        results.append(
            ModStatus(
                workshop_id=wid,
                name=title,
                present=present,
                local_updated=local_updated,
                remote_updated=remote_updated,
                needs_update=needs_update,
                missing=not present,
                downloading_hint=hint,
                remote_size=remote_size,
            )
        )
        log_event(
            "mod_evaluated",
            operation_id=operation_id,
            category="steam",
            workshop_id=wid,
            name=title,
            present=present,
            subscribed=not unsubscribed,
            local_updated=local_updated,
            remote_updated=remote_updated,
            needs_update=needs_update,
            missing=not present,
            hint=hint,
            sources={
                "acf": bool(acf),
                "acf_details": bool(details),
                "anonymous_remote": api_ok,
                "authenticated_remote": authenticated_ok,
                "ugc_progress": wid in steam_probe,
                "ugc_flag": ugc_flags.get(wid),
                "content_plan": wid in update_plans,
            },
        )
    return results


def folder_byte_size(path: Path) -> int:
    if not path.exists():
        return 0
    total = 0
    try:
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    total += f.stat().st_size
                except OSError:
                    pass
    except OSError:
        return total
    return total


def mod_local_bytes_for_folder(folder: Path | None) -> int:
    if folder is None:
        return 0
    return folder_byte_size(folder)


def mod_local_bytes(
    paths: SteamPaths,
    workshop_id: int,
    install_folder: Path | None = None,
) -> int:
    folder = _mod_folder(paths, workshop_id, install_folder)
    return mod_local_bytes_for_folder(folder)


@dataclass
class DownloadProgress:
    total: int
    done: int
    fraction: float
    detail: str
    failed_id: int | None = None
    failure_detail: str = ""
    failure_key: str = ""


def compute_download_progress(
    paths: SteamPaths,
    statuses: list[ModStatus],
    target_ids: list[int],
    *,
    content_log_offset: int = 0,
    workshop_log_offset: int = 0,
) -> DownloadProgress:
    """Estimate progress for target workshop mods (done count + size ratio)."""
    targets = {int(x) for x in target_ids if int(x) > 0}
    if not targets:
        return DownloadProgress(0, 0, 1.0, "无需更新")

    steam_dl: dict[int, object] = {}
    update_plans: dict[int, object] = {}
    download_events: dict[int, object] = {}
    item_downloading = 16
    item_download_pending = 32
    try:
        from .steam_ugc import (
            ITEM_DOWNLOADING,
            ITEM_DOWNLOAD_PENDING,
            read_item_download_progress,
            read_workshop_download_events,
            read_workshop_update_plans,
        )

        item_downloading = ITEM_DOWNLOADING
        item_download_pending = ITEM_DOWNLOAD_PENDING
        steam_dl = read_item_download_progress(paths, list(targets))
        update_plans = read_workshop_update_plans(
            paths,
            list(targets),
            content_log_offset=content_log_offset,
        )
        download_events = read_workshop_download_events(
            paths,
            list(targets),
            log_offset=workshop_log_offset,
        )
    except Exception:
        steam_dl = {}

    by_id = {s.workshop_id: s for s in statuses}
    done = 0
    size_ratios: list[float] = []
    pending_names: list[str] = []
    failed_id: int | None = None
    failure_detail = ""
    failure_key = ""
    for wid in targets:
        s = by_id.get(wid)
        if s is None:
            size_ratios.append(0.0)
            pending_names.append(str(wid))
            continue
        event = download_events.get(wid)
        if (
            s.blocked
            and event is not None
            and getattr(event, "status", "") == "failure"
        ):
            failed_id = wid
            failure_detail = str(getattr(event, "message", "") or "Steam 下载失败")
            failure_key = str(getattr(event, "key", "") or f"{wid}:{failure_detail}")
        probe = steam_dl.get(wid)
        if probe is not None:
            downloaded = int(getattr(probe, "downloaded", 0) or 0)
            total = int(getattr(probe, "total", 0) or 0)
            if total > 0:
                raw_ratio = downloaded / total
                byte_complete = downloaded >= int(total * 0.995)
                if byte_complete or (not s.needs_update and not s.missing):
                    done += 1
                    size_ratios.append(1.0)
                    continue
                size_ratios.append(min(0.99, raw_ratio))
                pending_names.append(s.name)
                continue
            state = int(getattr(probe, "state", 0) or 0)
            if not s.missing and not s.needs_update:
                done += 1
                size_ratios.append(1.0)
                continue
            if state & (item_downloading | item_download_pending):
                size_ratios.append(0.02)
                pending_names.append(s.name)
                continue
        if not s.missing and not s.needs_update:
            done += 1
            size_ratios.append(1.0)
            continue
        local = mod_local_bytes(paths, wid)
        remote = int(s.remote_size or 0)
        if remote > 0:
            size_ratios.append(min(0.99, local / remote))
        elif local > 0:
            size_ratios.append(0.35)
        else:
            size_ratios.append(0.0)
        pending_names.append(s.name)

    total = len(targets)
    frac = sum(size_ratios) / total if total else 1.0
    plan_note = _steam_plans_summary(list(update_plans.values()))
    if done == total:
        detail = f"全部完成（{done}/{total}）"
        if plan_note:
            detail += f" · {plan_note}"
    elif pending_names:
        detail = f"已就绪 {done}/{total}"
        if plan_note:
            detail += f" · {plan_note}"
        else:
            detail += " · 等待 Steam 返回实际下载大小"
    else:
        detail = f"已就绪 {done}/{total}"
    return DownloadProgress(
        total=total,
        done=done,
        fraction=frac,
        detail=detail,
        failed_id=failed_id,
        failure_detail=failure_detail,
        failure_key=failure_key,
    )


def summarize_gate(statuses: list[ModStatus]) -> tuple[bool, str]:
    missing = [s for s in statuses if s.missing]
    outdated = [s for s in statuses if s.needs_update]
    if missing or outdated:
        parts = []
        if missing:
            parts.append(f"缺失 {len(missing)} 个")
        if outdated:
            parts.append(f"待更新 {len(outdated)} 个")
        return False, "；".join(parts) + "。更新完成前禁止进入服务器。"
    return True, "全部模组已安装且为最新，可以进入服务器。"


def workshop_mod_launch_names(paths: SteamPaths, statuses: list[ModStatus]) -> list[str]:
    """Build -mod= entries as absolute paths (official DayZLauncher style)."""
    names: list[str] = []
    for s in statuses:
        if s.workshop_id <= 0:
            local_name = s.name if s.name.startswith("@") else f"@{s.name}"
            root_folder = paths.dayz_root / local_name
            bang_folder = paths.dayz_root / "!Workshop" / local_name
            if root_folder.is_dir():
                names.append(str(root_folder.resolve()))
            elif bang_folder.is_dir():
                names.append(str(bang_folder.resolve()))
            else:
                names.append(str((paths.dayz_root / "!Workshop" / local_name).resolve()))
            continue

        folder = find_workshop_mod_dir(paths, s.workshop_id)
        if folder is not None:
            names.append(str(folder.resolve()))
            continue

        content = paths.workshop_content / str(s.workshop_id)
        if content.is_dir():
            try:
                if any(content.iterdir()):
                    names.append(str(content.resolve()))
                    continue
            except OSError:
                pass

        fallback = s.name if s.name.startswith("@") else f"@{s.name}"
        names.append(str((paths.dayz_root / "!Workshop" / fallback).resolve()))
    return names


def trigger_workshop_downloads(
    paths: SteamPaths,
    workshop_ids: list[int],
    *,
    fast_repair: bool = False,
    verified_outdated_ids: set[int] | None = None,
    workshop_log_offset: int = 0,
) -> None:
    """恢复订阅并让 Steam 下载/更新 Workshop 模组。"""
    import subprocess

    from .steam_paths import ensure_dayz_workshop_subscriptions
    from .steam_profile import load_steam_profile
    from .steam_ugc import force_download_items

    if not paths.steam_exe.exists():
        raise FileNotFoundError(f"找不到 steam.exe: {paths.steam_exe}")
    ids = list(dict.fromkeys(int(wid) for wid in workshop_ids if int(wid) > 0))
    if not ids:
        return

    use_cli_download = not fast_repair
    if fast_repair:
        # 快速修复只走 Steamworks 单项请求，不另起 CLI 下载任务。
        msg = ""
        for attempt in range(3):
            steamworks_ok, msg = force_download_items(
                paths,
                ids,
                verified_outdated_ids=verified_outdated_ids,
                workshop_log_offset=workshop_log_offset,
            )
            if steamworks_ok >= len(ids):
                break
            if attempt < 2:
                time.sleep(0.6 * (attempt + 1))
        else:
            # 官方链路失败就明确报错。禁止再回退
            # +workshop_download_item，否则会另起一条下载任务，
            # 用户看到的就可能是重复排队或更大的下载量。
            raise RuntimeError(f"{msg}（已自动重试 3 次）")

    # 非修理用途保留原有 CLI 下载入口；修理永远不走此路径。
    if use_cli_download:
        profile = load_steam_profile(str(paths.steam_root))
        ensure_dayz_workshop_subscriptions(
            paths.steam_root,
            ids,
            steam_id64=(profile.steam_id64 if profile else ""),
        )
        args = [str(paths.steam_exe)]
        for wid in ids:
            args.extend(["+workshop_download_item", str(DAYZ_APP_ID), str(wid)])
        subprocess.Popen(args, cwd=str(paths.steam_root))
