from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

from .config import app_root


LOGGER_NAME = "cyx_launcher"
LOG_DIR_NAME = "logs"
LOG_FILE_NAME = "launcher.log"
_configure_lock = threading.Lock()


def diagnostics_log_path(root: Path | None = None) -> Path:
    return (root or app_root()) / LOG_DIR_NAME / LOG_FILE_NAME


def configure_diagnostics(root: Path | None = None) -> Path:
    """启用 UTF-8 轮转日志；重复调用不会叠加 handler。"""
    log_path = diagnostics_log_path(root).resolve()
    logger = logging.getLogger(LOGGER_NAME)
    with _configure_lock:
        configured_path = str(getattr(logger, "_cyx_log_path", "") or "")
        if getattr(logger, "_cyx_configured", False) and configured_path == str(log_path):
            return log_path
        if getattr(logger, "_cyx_configured", False):
            for old_handler in list(logger.handlers):
                old_handler.close()
                logger.removeHandler(old_handler)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            log_path,
            maxBytes=2 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
        setattr(logger, "_cyx_configured", True)
        setattr(logger, "_cyx_log_path", str(log_path))
    return log_path


def new_operation_id(kind: str) -> str:
    prefix = "".join(ch for ch in str(kind).lower() if ch.isalnum() or ch in "-_")[:16]
    return f"{prefix or 'op'}-{uuid.uuid4().hex[:12]}"


def _safe_value(key: str, value: Any) -> Any:
    lowered = key.casefold()
    if any(word in lowered for word in ("password", "secret", "token", "api_key", "private")):
        return "***REDACTED***" if value else ""
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple, set)):
        return [_safe_value(key, item) for item in value]
    if isinstance(value, dict):
        return {str(k): _safe_value(str(k), v) for k, v in value.items()}
    return str(value)


def log_event(
    event: str,
    *,
    operation_id: str = "",
    category: str = "launcher",
    level: int = logging.INFO,
    **fields: Any,
) -> None:
    """写入一行 JSON，便于按操作和 WorkshopID 对齐证据。"""
    try:
        logger = logging.getLogger(LOGGER_NAME)
        if not getattr(logger, "_cyx_configured", False):
            return
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "event": str(event),
            "category": str(category),
        }
        if operation_id:
            payload["operation_id"] = str(operation_id)
        payload.update({str(k): _safe_value(str(k), v) for k, v in fields.items()})
        logging.getLogger(LOGGER_NAME).log(
            level,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        )
    except (OSError, TypeError, ValueError):
        # 诊断日志绝不能反过来阻断启动器主流程。
        return
