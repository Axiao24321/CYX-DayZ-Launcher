from __future__ import annotations

import subprocess
from dataclasses import dataclass


# 只允许关闭玩家客户端。这里故意不使用 DayZ*.exe 通配符，避免误杀 DayZServer_x64.exe。
DAYZ_CLIENT_PROCESSES = ("DayZ_x64.exe", "DayZ_BE.exe")


@dataclass(frozen=True)
class CloseGameResult:
    closed_processes: tuple[str, ...]
    errors: tuple[str, ...]

    @property
    def closed(self) -> bool:
        return bool(self.closed_processes)

    @property
    def message(self) -> str:
        if self.errors:
            return "关闭 DayZ 失败：" + "；".join(self.errors)
        if self.closed_processes:
            return "已关闭 DayZ 游戏客户端。"
        return "DayZ 游戏客户端当前未运行。"


def _is_process_running(image_name: str) -> bool:
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", f"IMAGENAME eq {image_name}", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            text=True,
            errors="ignore",
        )
        return image_name.lower() in out.lower()
    except Exception:
        return False


def close_dayz_client() -> CloseGameResult:
    """强制结束零售版 DayZ 玩家客户端；绝不关闭 Steam、诊断端或服务器端。"""
    closed: list[str] = []
    errors: list[str] = []

    for image_name in DAYZ_CLIENT_PROCESSES:
        if not _is_process_running(image_name):
            continue
        result = subprocess.run(
            ["taskkill", "/IM", image_name, "/T", "/F"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            capture_output=True,
            text=True,
            errors="ignore",
        )
        if result.returncode == 0 or not _is_process_running(image_name):
            closed.append(image_name)
            continue
        detail = (result.stderr or result.stdout or f"返回代码 {result.returncode}").strip()
        errors.append(f"{image_name}: {detail}")

    return CloseGameResult(tuple(closed), tuple(errors))
