from __future__ import annotations

import subprocess
from pathlib import Path

from .steam_paths import SteamPaths

# dayzquery DLC_FROSTLINE = 2
DLC_FROSTLINE = 2


def _dayz_be_exe(paths: SteamPaths) -> Path:
    be = paths.dayz_root / "DayZ_BE.exe"
    if be.exists():
        return be
    x64 = paths.dayz_root / "DayZ_x64.exe"
    if x64.exists():
        return x64
    raise FileNotFoundError(f"找不到 DayZ 可执行文件: {paths.dayz_root}")


def resolve_frostline_mod_path(dayz_root: Path) -> str | None:
    """官方 Frostline DLC 目录（若本机已安装）。"""
    candidates = [
        dayz_root / "Frostline",
        dayz_root / "@Frostline",
        dayz_root / "DLC" / "Frostline",
        dayz_root / "Addons" / "Frostline",
    ]
    for p in candidates:
        if p.is_dir():
            return str(p.resolve())
    # Steam depot 常见命名兜底
    for child in dayz_root.iterdir():
        if child.is_dir() and "frostline" in child.name.lower():
            return str(child.resolve())
    return None


def build_launch_args(
    paths: SteamPaths,
    *,
    server_ip: str,
    server_port: int,
    query_port: int | None = None,
    mod_paths: list[str],
    player_name: str = "",
    dlc_flags: int = 0,
    use_battleye: bool = True,
) -> tuple[Path, list[str]]:
    """
    对齐官方 DayZLauncher：
      DayZ_BE.exe -exe DayZ_x64.exe -name=... "-mod=abs1;abs2" -connect=ip:game:query
    """
    be = _dayz_be_exe(paths)
    x64 = paths.dayz_root / "DayZ_x64.exe"
    mods = list(mod_paths)

    if dlc_flags & DLC_FROSTLINE:
        frost = resolve_frostline_mod_path(paths.dayz_root)
        if frost and frost not in mods:
            mods.insert(0, frost)

    args: list[str] = [str(be)]
    if be.name.lower() == "dayz_be.exe" and x64.exists():
        args.extend(["-exe", "DayZ_x64.exe"])
    if player_name:
        args.append(f"-name={player_name}")
    if mods:
        args.append("-mod=" + ";".join(mods))

    q = int(query_port) if query_port else int(server_port)
    # 官方格式：-connect=ip:gamePort:queryPort
    args.append(f"-connect={server_ip}:{int(server_port)}:{q}")
    return be, args


def launch_dayz(
    paths: SteamPaths,
    *,
    server_ip: str,
    server_port: int,
    query_port: int | None = None,
    mod_paths: list[str],
    player_name: str = "",
    dlc_flags: int = 0,
    use_battleye: bool = True,
) -> subprocess.Popen:
    if not mod_paths and not (dlc_flags & DLC_FROSTLINE):
        raise RuntimeError("模组列表为空，拒绝以无模组方式进服。")

    exe, args = build_launch_args(
        paths,
        server_ip=server_ip,
        server_port=server_port,
        query_port=query_port,
        mod_paths=mod_paths,
        player_name=player_name,
        dlc_flags=dlc_flags,
        use_battleye=use_battleye,
    )

    try:
        log = paths.dayz_root / "cyx_launcher_last_cmd.txt"
        log.write_text(
            "cwd=" + str(paths.dayz_root) + "\n" + subprocess.list2cmdline(args) + "\n",
            encoding="utf-8",
        )
    except OSError:
        pass

    return subprocess.Popen(args, cwd=str(paths.dayz_root))


def open_path(path: Path) -> None:
    subprocess.Popen(["explorer", str(path)])
