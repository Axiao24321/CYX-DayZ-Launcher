from __future__ import annotations


def floating_left_panel_geometry(
    center_x_pixels: float,
    footer_y_pixels: float,
    widget_scale: float,
    *,
    left_x: float = 10.0,
    left_y: float = 100.0,
) -> tuple[float, float, float, float]:
    """把屏幕像素坐标统一换算成 CTk 逻辑坐标后再计算布局。"""
    scale = max(0.1, float(widget_scale or 1.0))
    center_x = float(center_x_pixels) / scale
    footer_y = float(footer_y_pixels) / scale
    width = max(280.0, center_x - left_x - 6.0)
    height = max(560.0, footer_y - left_y - 8.0)
    return left_x, left_y, width, height
