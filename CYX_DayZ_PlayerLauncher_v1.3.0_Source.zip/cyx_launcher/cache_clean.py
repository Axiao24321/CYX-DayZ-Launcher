from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path


# 安全清理：只删日志/崩溃转储，不动模组配置目录
SAFE_SUFFIXES = {".rpt", ".mdmp", ".log", ".adm", ".bidmp"}
SAFE_NAME_PREFIXES = ("crash_", "script_", "DayZ_x64_", "DayZ_BE_", "CrashReporter")
SAFE_EXACT_NAMES = {
    "CrashReporter.log",
    "error.log",
    "stdout.log",
    "stderr.log",
}


@dataclass
class CacheCleanResult:
    root: Path
    deleted_files: int
    deleted_bytes: int
    skipped: int
    message: str


def dayz_localappdata() -> Path:
    local = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(local) / "DayZ"


def _is_safe_cache_file(path: Path) -> bool:
    name = path.name
    if name in SAFE_EXACT_NAMES:
        return True
    lower = name.lower()
    suffix = path.suffix.lower()
    if suffix in SAFE_SUFFIXES:
        # 保留可能有用的配置类 xml/json 不在此后缀里
        if lower.startswith(SAFE_NAME_PREFIXES) or suffix in {".rpt", ".mdmp", ".adm", ".bidmp"}:
            return True
        if lower.startswith("crash") or "script_" in lower:
            return True
        # 其余 .log 也视为可清理缓存日志
        if suffix == ".log":
            return True
    return False


def estimate_cache_bytes(root: Path | None = None) -> tuple[int, int]:
    """返回 (可清理文件数, 字节数)。"""
    root = root or dayz_localappdata()
    if not root.is_dir():
        return 0, 0
    count = 0
    total = 0
    for item in root.iterdir():
        if not item.is_file():
            continue
        if not _is_safe_cache_file(item):
            continue
        try:
            total += item.stat().st_size
            count += 1
        except OSError:
            pass
    return count, total


def format_bytes(n: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    size = float(n)
    for u in units:
        if size < 1024 or u == units[-1]:
            if u == "B":
                return f"{int(size)} {u}"
            return f"{size:.2f} {u}"
        size /= 1024
    return f"{n} B"


def clear_dayz_cache(root: Path | None = None) -> CacheCleanResult:
    """清理 %LOCALAPPDATA%\\DayZ 下的日志/崩溃缓存，保留模组配置文件夹。"""
    root = root or dayz_localappdata()
    if not root.exists():
        return CacheCleanResult(root, 0, 0, 0, f"未找到缓存目录：{root}")
    if not root.is_dir():
        return CacheCleanResult(root, 0, 0, 0, f"路径不是目录：{root}")

    deleted_files = 0
    deleted_bytes = 0
    skipped = 0
    errors: list[str] = []

    for item in list(root.iterdir()):
        if item.is_dir():
            # 不删任何子目录（里面通常是模组 Profile 配置）
            skipped += 1
            continue
        if not item.is_file():
            continue
        if not _is_safe_cache_file(item):
            skipped += 1
            continue
        try:
            size = item.stat().st_size
            item.unlink()
            deleted_files += 1
            deleted_bytes += size
        except OSError as e:
            errors.append(f"{item.name}: {e}")

    msg = (
        f"已清理 {deleted_files} 个文件（{format_bytes(deleted_bytes)}），"
        f"跳过 {skipped} 项（配置目录等已保留）。"
    )
    if errors:
        msg += f" 有 {len(errors)} 个文件删除失败（可能被占用）。"
    return CacheCleanResult(root, deleted_files, deleted_bytes, skipped, msg)


def is_dayz_running() -> bool:
    """粗略检测 DayZ 是否在运行。"""
    try:
        import subprocess

        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq DayZ_x64.exe", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            text=True,
            errors="ignore",
        )
        if "DayZ_x64.exe" in out:
            return True
        out2 = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq DayZ_BE.exe", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            text=True,
            errors="ignore",
        )
        return "DayZ_BE.exe" in out2
    except Exception:
        return False
