from __future__ import annotations

import threading
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk

from .cache_clean import clear_dayz_cache, dayz_localappdata, estimate_cache_bytes, format_bytes, is_dayz_running
from . import __version__
from .config import (
    app_asset_path,
    app_background_path,
    app_icon_path,
    get_update_manifest_urls,
    server_by_option_label,
    server_option_labels,
)
from .game_process import close_dayz_client
from .player_name import resolve_player_name
from .server_query import query_server_population
from .service import LauncherService
from .steam_paths import detect_dayz_path_text
from .steam_profile import load_steam_profile
from .updater import (
    UpdateManifest,
    download_update,
    fetch_update_manifest_from_urls,
    is_newer_version,
    launch_update_helper,
)
from .diagnostics import log_event
from .operation import OperationController, OperationToken
from .layout import floating_left_panel_geometry

try:
    from PIL import Image, ImageOps, ImageTk
except ImportError:  # pragma: no cover
    Image = None  # type: ignore
    ImageOps = None  # type: ignore
    ImageTk = None  # type: ignore


class LauncherApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self.service = LauncherService()
        self.title(f"CYX DayZ 启动器 v{__version__}")
        self.geometry("1480x860")
        self.minsize(1180, 800)
        self.configure(fg_color="#060909")

        self._busy = False
        self._loading = False
        self._operations = OperationController()
        self._active_repair_token: OperationToken | None = None
        self._repair_poll_job = None
        self._repair_targets: list[int] = []
        self._repair_queue: list[int] = []
        self._repair_active_target: int | None = None
        self._repair_retry_counts: dict[int, int] = {}
        self._repair_handled_failures: set[str] = set()
        self._repair_subscription_only = False
        self._repair_content_log_offset = 0
        self._repair_workshop_log_offset = 0
        self._avatar_image = None
        self._window_icon = None
        self._background_image = None
        self._ui_images: dict[tuple[str, int, int], object] = {}
        self._steam_id64 = ""
        self._copy_tip_job = None
        self._update_checking = False
        self._update_required = False
        self._update_in_progress = False
        self._pending_update: UpdateManifest | None = None
        self._population_job = None
        self._population_querying = False
        self._all_population_querying = False
        self._server_populations: dict[str, tuple[int | None, int | None]] = {}
        self._closing_game = False
        self._layout_job = None
        self._last_status = "系统就绪"
        self._apply_window_icon()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._build()
        self._load_fields()
        self._load_steam_header()
        # 先检查启动器自身更新，再用上次选择的服务器做模组对齐检测。
        self.after(120, self._check_app_update_on_startup)
        self.after(450, self._auto_check_on_startup)
        self.after(1200, self._refresh_all_server_populations_async)

    def _apply_window_icon(self) -> None:
        ico = app_icon_path("ico")
        png = app_icon_path("png")
        try:
            if ico.is_file():
                self.iconbitmap(default=str(ico))
        except tk.TclError:
            pass
        if Image is None or ImageTk is None or not png.is_file():
            return
        try:
            img = Image.open(png).convert("RGBA")
            img = img.resize((64, 64), Image.Resampling.LANCZOS)
            self._window_icon = ImageTk.PhotoImage(img)
            self.iconphoto(True, self._window_icon)
        except Exception:
            pass

    def _ui_icon(self, name: str, width: int = 24, height: int = 24):
        key = (name, int(width), int(height))
        cached = self._ui_images.get(key)
        if cached is not None:
            return cached
        path = app_asset_path("icons", f"{name}.png")
        if Image is None or not path.is_file():
            return None
        try:
            image = Image.open(path).convert("RGBA")
            icon = ctk.CTkImage(
                light_image=image,
                dark_image=image,
                size=(width, height),
            )
            self._ui_images[key] = icon
            return icon
        except OSError:
            return None

    def _build(self) -> None:
        bg = "#060909"
        panel = "#0b1010"
        panel_alt = "#101515"
        border = "#40331d"
        gold = "#d6a440"
        gold_hover = "#b8832b"
        text = "#e8e2d7"
        muted = "#98958d"
        green = "#70cf32"

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self.var_server = tk.StringVar()
        self.var_player = tk.StringVar()
        self.var_dayz = tk.StringVar()
        self.var_minimize = tk.BooleanVar(value=True)

        # 顶部沉浸式横幅
        hero = ctk.CTkFrame(self, height=178, corner_radius=0, fg_color=bg)
        hero.grid(row=0, column=0, sticky="ew")
        hero.grid_propagate(False)
        background = app_background_path()
        if background.is_file() and Image is not None and ImageOps is not None:
            try:
                image = Image.open(background).convert("RGB")
                # 保持原图比例并从中心裁切，不再把人物和建筑纵向压扁。
                image = ImageOps.fit(
                    image,
                    (1480, 240),
                    method=Image.Resampling.LANCZOS,
                    centering=(0.5, 0.43),
                )
                self._background_image = ctk.CTkImage(
                    light_image=image,
                    dark_image=image,
                    size=(1480, 240),
                )
                ctk.CTkLabel(hero, text="", image=self._background_image).place(
                    relx=0,
                    rely=0,
                    relwidth=1,
                    relheight=1,
                )
            except OSError:
                self._background_image = None

        title_box = ctk.CTkFrame(
            hero,
            fg_color="#080b0b",
            border_width=1,
            border_color=border,
            corner_radius=10,
        )
        title_box.place(x=22, y=22)
        ctk.CTkLabel(
            title_box,
            text="CYX DayZ 启动器",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color="#f0c66a",
        ).grid(row=0, column=0, padx=(18, 10), pady=12)
        ctk.CTkLabel(
            title_box,
            text=f"v{__version__}",
            text_color=gold,
            fg_color="#17130c",
            corner_radius=6,
        ).grid(row=0, column=1, padx=(0, 14), pady=12)

        self.btn_app_update = ctk.CTkButton(
            hero,
            text="检查更新",
            image=self._ui_icon("refresh", 17, 17),
            compound="left",
            width=132,
            height=36,
            fg_color="#111512",
            hover_color="#2a2417",
            border_width=1,
            border_color=gold,
            text_color="#efc66b",
            command=self._on_manual_app_update,
        )
        self.btn_app_update.place(relx=1.0, x=-22, y=22, anchor="ne")

        # 三栏主工作区
        main = ctk.CTkFrame(self, fg_color=bg, corner_radius=0)
        main.grid(row=1, column=0, sticky="nsew", padx=10, pady=(8, 8))
        main.grid_propagate(False)
        main.grid_rowconfigure(0, weight=1)
        # uniform 让三栏完全由比例决定，不允许服务器名、状态或按钮文字
        # 在点击后重新撑开某一列，从而造成整个 UI 左右跳动。
        main.grid_columnconfigure(0, weight=26, uniform="launcher_main")
        main.grid_columnconfigure(1, weight=36, uniform="launcher_main")
        main.grid_columnconfigure(2, weight=38, uniform="launcher_main")

        left = ctk.CTkFrame(
            self,
            width=360,
            height=660,
            fg_color=panel,
            border_width=1,
            border_color=border,
            corner_radius=12,
        )
        # 左栏像参考图一样上移覆盖横幅。具体宽高在首次布局后与
        # 中栏和页脚的真实边界对齐，避免 DPI 缩放时依靠 relwidth 压住中栏。
        left.place(
            x=10,
            y=100,
        )
        left.grid_propagate(False)
        left.lift()
        left.grid_columnconfigure(0, weight=1)
        left.grid_rowconfigure(5, weight=1)
        ctk.CTkLabel(
            left,
            text="┃ 玩家信息",
            image=self._ui_icon("profile", 22, 22),
            compound="left",
            anchor="w",
            text_color="#edc165",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 8))

        profile = ctk.CTkFrame(left, fg_color=panel_alt, corner_radius=10)
        profile.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 12))
        profile.grid_columnconfigure(1, weight=1)
        self.avatar_label = ctk.CTkLabel(
            profile,
            text="Steam",
            width=76,
            height=76,
            fg_color="#171d1d",
            corner_radius=9,
        )
        self.avatar_label.grid(row=0, column=0, rowspan=3, padx=12, pady=12)
        self.steam_name_label = ctk.CTkLabel(
            profile,
            text="未检测到 Steam 账号",
            anchor="w",
            text_color=text,
            font=ctk.CTkFont(size=19, weight="bold"),
        )
        self.steam_name_label.grid(row=0, column=1, sticky="sw", padx=(0, 8), pady=(12, 0))
        ctk.CTkLabel(
            profile,
            text="● 在线",
            text_color=green,
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=0, column=2, sticky="e", padx=(0, 12), pady=(12, 0))
        self.steam_id_label = ctk.CTkLabel(
            profile,
            text="SteamID64: —",
            anchor="w",
            text_color=muted,
            font=ctk.CTkFont(size=12),
            cursor="hand2",
        )
        self.steam_id_label.grid(row=1, column=1, columnspan=2, sticky="w", padx=(0, 8))
        self.steam_id_label.bind("<Button-1>", self._on_copy_steam_id)
        self.copy_tip_label = ctk.CTkLabel(
            profile,
            text="",
            anchor="w",
            text_color=green,
            font=ctk.CTkFont(size=11),
        )
        self.copy_tip_label.grid(row=2, column=1, sticky="nw", padx=(0, 8), pady=(0, 10))

        fields = ctk.CTkFrame(left, fg_color="transparent")
        fields.grid(row=2, column=0, sticky="ew", padx=14)
        fields.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(fields, text="角色名", anchor="w", text_color="#d9b45e").grid(
            row=0, column=0, sticky="ew", pady=(0, 4)
        )
        ctk.CTkEntry(
            fields,
            textvariable=self.var_player,
            height=38,
            fg_color="#090d0d",
            border_color="#4a412e",
            text_color=text,
        ).grid(row=1, column=0, sticky="ew", pady=(0, 12))
        ctk.CTkLabel(
            fields,
            text="DayZ 目录",
            anchor="w",
            text_color="#d9b45e",
        ).grid(row=2, column=0, sticky="ew", pady=(0, 4))
        ctk.CTkEntry(
            fields,
            textvariable=self.var_dayz,
            height=38,
            fg_color="#090d0d",
            border_color="#4a412e",
            text_color=text,
        ).grid(row=3, column=0, sticky="ew")
        path_actions = ctk.CTkFrame(fields, fg_color="transparent")
        path_actions.grid(row=4, column=0, sticky="ew", pady=(7, 14))
        path_actions.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(
            path_actions,
            text="自动检测",
            height=32,
            fg_color="#191914",
            hover_color="#292518",
            border_width=1,
            border_color=border,
            text_color="#e4bd65",
            command=self._auto_detect_dayz,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ctk.CTkButton(
            path_actions,
            text="浏览目录",
            image=self._ui_icon("folder", 18, 18),
            compound="left",
            height=32,
            fg_color="#191914",
            hover_color="#292518",
            border_width=1,
            border_color=border,
            text_color="#e4bd65",
            command=self._browse_dayz,
        ).grid(row=0, column=1, sticky="ew", padx=(4, 0))

        local_info = ctk.CTkFrame(left, fg_color=panel_alt, corner_radius=10)
        local_info.grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 12))
        local_info.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(local_info, text="启动器版本", text_color=muted).grid(
            row=0, column=0, sticky="w", padx=12, pady=(10, 4)
        )
        ctk.CTkLabel(local_info, text=f"v{__version__}", text_color=text).grid(
            row=0, column=1, sticky="e", padx=12, pady=(10, 4)
        )
        ctk.CTkLabel(local_info, text="安全状态", text_color=muted).grid(
            row=1, column=0, sticky="w", padx=12, pady=(4, 10)
        )
        ctk.CTkLabel(
            local_info,
            text="Steam 官方通道",
            image=self._ui_icon("shield", 18, 18),
            compound="left",
            text_color=green,
        ).grid(
            row=1, column=1, sticky="e", padx=12, pady=(4, 10)
        )
        self.chk_minimize = ctk.CTkCheckBox(
            left,
            text="进服后最小化启动器",
            variable=self.var_minimize,
            command=self._persist_quiet,
            fg_color=gold,
            hover_color=gold_hover,
            text_color=muted,
        )
        self.chk_minimize.grid(row=4, column=0, sticky="w", padx=16, pady=(2, 10))
        self.btn_close_game = ctk.CTkButton(
            left,
            text="关闭 DayZ 游戏",
            image=self._ui_icon("power", 20, 20),
            compound="left",
            height=38,
            fg_color="#321616",
            hover_color="#522020",
            border_width=1,
            border_color="#743232",
            command=self._on_close_game,
        )
        self.btn_close_game.grid(row=6, column=0, sticky="ew", padx=14, pady=(8, 14))

        center = ctk.CTkFrame(main, fg_color=bg, corner_radius=0)
        center.grid(row=0, column=1, sticky="nsew", padx=6)
        center.grid_columnconfigure(0, weight=1)
        center.grid_rowconfigure(0, weight=3)
        center.grid_rowconfigure(1, weight=2)
        server_panel = ctk.CTkFrame(
            center,
            fg_color=panel,
            border_width=1,
            border_color=border,
            corner_radius=12,
        )
        server_panel.grid(row=0, column=0, sticky="nsew", pady=(0, 6))
        server_panel.grid_columnconfigure(0, weight=1)
        server_panel.grid_rowconfigure(1, weight=1)
        server_header = ctk.CTkFrame(server_panel, fg_color="transparent")
        server_header.grid(row=0, column=0, sticky="ew", padx=14, pady=(10, 6))
        server_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            server_header,
            text="┃ 服务器选择",
            image=self._ui_icon("server", 22, 22),
            compound="left",
            anchor="w",
            text_color="#edc165",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).grid(row=0, column=0, sticky="w")
        self.btn_refresh_servers = ctk.CTkButton(
            server_header,
            text="刷新",
            image=self._ui_icon("refresh", 17, 17),
            compound="left",
            width=82,
            height=30,
            fg_color="#181712",
            hover_color="#2a2417",
            border_width=1,
            border_color=border,
            text_color="#e4bd65",
            command=self._refresh_all_server_populations_async,
        )
        self.btn_refresh_servers.grid(row=0, column=1, sticky="e")
        self.server_menu = ctk.CTkOptionMenu(
            server_panel,
            variable=self.var_server,
            values=server_option_labels(),
            command=self._on_server_changed,
            height=42,
            fg_color="#241f13",
            button_color="#8e6722",
            button_hover_color=gold_hover,
            dropdown_fg_color="#0b1010",
            dropdown_hover_color="#332819",
            text_color="#f1cf85",
        )
        # 保留 OptionMenu 作为配置状态容器，界面改用可点击服务器卡片。
        self.server_card_frames: dict[str, ctk.CTkFrame] = {}
        self.server_card_icons: dict[str, ctk.CTkLabel] = {}
        self.server_card_titles: dict[str, ctk.CTkLabel] = {}
        self.server_card_badges: dict[str, ctk.CTkLabel] = {}
        self.server_card_player_labels: dict[str, ctk.CTkLabel] = {}
        self.server_card_marks: dict[str, ctk.CTkLabel] = {}
        cards = ctk.CTkFrame(server_panel, fg_color="transparent")
        cards.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 12))
        cards.grid_columnconfigure(0, weight=1)
        servers = self.service.list_servers()
        options = server_option_labels()
        for index, (server, option) in enumerate(zip(servers, options)):
            cards.grid_rowconfigure(index, weight=1)
            server_id = str(server["id"])
            card = ctk.CTkFrame(
                cards,
                height=94,
                fg_color="#101515",
                border_width=1,
                border_color="#3a3d35",
                corner_radius=8,
            )
            card.grid(row=index, column=0, sticky="nsew", pady=4)
            card.grid_propagate(False)
            card.grid_columnconfigure(1, weight=1)
            card.grid_rowconfigure((0, 1, 2), weight=1)
            icon = ctk.CTkLabel(
                card,
                text="➤",
                width=42,
                text_color="#e7b650",
                font=ctk.CTkFont(family="Segoe UI Symbol", size=25, weight="bold"),
            )
            icon.grid(row=0, column=0, rowspan=3, padx=(12, 6), pady=10)
            title_line = ctk.CTkFrame(card, fg_color="transparent")
            title_line.grid(row=0, column=1, sticky="sw")
            title = ctk.CTkLabel(
                title_line,
                text=server["label"],
                anchor="w",
                text_color=text,
                font=ctk.CTkFont(size=14, weight="bold"),
            )
            title.grid(row=0, column=0, sticky="w")
            badge = ctk.CTkLabel(
                title_line,
                text="查询中",
                width=48,
                height=20,
                fg_color="#27301b",
                corner_radius=5,
                text_color="#9acb63",
                font=ctk.CTkFont(size=10, weight="bold"),
            )
            badge.grid(row=0, column=1, sticky="w", padx=(8, 0))
            ip_label = ctk.CTkLabel(
                card,
                text=f"IP  {server['server_ip']}:{server['server_port']}",
                anchor="w",
                text_color=muted,
                font=ctk.CTkFont(size=11),
            )
            ip_label.grid(row=1, column=1, sticky="w")
            tags_line = ctk.CTkFrame(card, fg_color="transparent")
            tags_line.grid(row=2, column=1, sticky="nw")
            tag_widgets = []
            for tag_index, tag_text in enumerate(self._server_tags(server)):
                tag = ctk.CTkLabel(
                    tags_line,
                    text=tag_text,
                    height=18,
                    fg_color="#262824",
                    corner_radius=4,
                    text_color="#bbb4a7",
                    font=ctk.CTkFont(size=9),
                )
                tag.grid(row=0, column=tag_index, padx=(0, 5))
                tag_widgets.append(tag)
            players = ctk.CTkLabel(
                card,
                text="—/—\n在线人数",
                anchor="e",
                justify="right",
                text_color=green,
                font=ctk.CTkFont(size=14, weight="bold"),
            )
            players.grid(row=0, column=2, rowspan=3, sticky="e", padx=(8, 10), pady=10)
            mark = ctk.CTkLabel(
                card,
                text="",
                width=18,
                text_color="#f0c66a",
                font=ctk.CTkFont(size=16, weight="bold"),
            )
            mark.grid(row=0, column=3, sticky="ne", padx=(0, 8), pady=(6, 0))
            for widget in (
                card,
                icon,
                title_line,
                title,
                badge,
                ip_label,
                tags_line,
                *tag_widgets,
                players,
                mark,
            ):
                widget.bind("<Button-1>", lambda _event, value=option: self._select_server_card(value))
            self.server_card_frames[server_id] = card
            self.server_card_icons[server_id] = icon
            self.server_card_titles[server_id] = title
            self.server_card_badges[server_id] = badge
            self.server_card_player_labels[server_id] = players
            self.server_card_marks[server_id] = mark

        download_panel = ctk.CTkFrame(
            center,
            fg_color=panel,
            border_width=1,
            border_color=border,
            corner_radius=12,
        )
        download_panel.grid(row=1, column=0, sticky="nsew", pady=(6, 0))
        download_panel.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            download_panel,
            text="┃ 更新中心",
            image=self._ui_icon("download", 22, 22),
            compound="left",
            anchor="w",
            text_color="#edc165",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 8))
        self.gate_label = ctk.CTkLabel(
            download_panel,
            text="等待模组检测",
            anchor="w",
            justify="left",
            wraplength=430,
            text_color="#e6c07b",
            font=ctk.CTkFont(size=13),
        )
        self.gate_label.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 8))
        self.progress_text = ctk.CTkLabel(
            download_panel,
            text="Steam 下载：待命",
            anchor="w",
            text_color=muted,
            font=ctk.CTkFont(size=12),
        )
        self.progress_text.grid(row=2, column=0, sticky="ew", padx=16, pady=(0, 5))
        self.progress_bar = ctk.CTkProgressBar(
            download_panel,
            height=12,
            fg_color="#272a27",
            progress_color=gold,
        )
        self.progress_bar.grid(row=3, column=0, sticky="ew", padx=16, pady=(0, 16))
        self.progress_bar.set(1)

        right = ctk.CTkFrame(
            main,
            fg_color=panel,
            border_width=1,
            border_color=border,
            corner_radius=12,
        )
        right.grid(row=0, column=2, sticky="nsew", padx=(6, 0))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(3, weight=1)
        mod_title_bar = ctk.CTkFrame(right, fg_color="transparent")
        mod_title_bar.grid(row=0, column=0, sticky="ew", padx=14, pady=(10, 6))
        mod_title_bar.grid_columnconfigure(0, weight=1)
        self.mod_sync_title = ctk.CTkLabel(
            mod_title_bar,
            text="┃ 模组同步",
            image=self._ui_icon("sync", 22, 22),
            compound="left",
            anchor="w",
            text_color="#edc165",
            font=ctk.CTkFont(size=16, weight="bold"),
        )
        self.mod_sync_title.grid(row=0, column=0, sticky="w")
        ctk.CTkButton(
            mod_title_bar,
            text="查看详情",
            width=90,
            height=30,
            fg_color="#181712",
            hover_color="#2a2417",
            border_width=1,
            border_color=gold,
            text_color="#efc66b",
            command=self._show_mod_details,
        ).grid(row=0, column=1, sticky="e")
        summary = ctk.CTkFrame(right, fg_color=panel_alt, corner_radius=10)
        summary.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 10))
        summary.grid_columnconfigure((0, 1, 2), weight=1)
        self.mod_ready_value = ctk.CTkLabel(
            summary,
            text="0\n最新",
            image=self._ui_icon("shield", 30, 30),
            compound="left",
            text_color=green,
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        self.mod_ready_value.grid(row=0, column=0, pady=10)
        self.mod_update_value = ctk.CTkLabel(
            summary,
            text="0\n需要处理",
            image=self._ui_icon("repair_red", 30, 30),
            compound="left",
            text_color="#ef9f34",
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        self.mod_update_value.grid(row=0, column=1, pady=10)
        self.mod_total_value = ctk.CTkLabel(
            summary,
            text="总大小\n—",
            image=self._ui_icon("package", 30, 30),
            compound="left",
            text_color="#d8d4cc",
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        self.mod_total_value.grid(row=0, column=2, pady=10)
        mod_table = ctk.CTkFrame(
            right,
            fg_color="#080c0c",
            border_width=1,
            border_color="#242927",
            corner_radius=8,
        )
        mod_table.grid(row=3, column=0, sticky="nsew", padx=14, pady=(0, 10))
        mod_table.grid_columnconfigure(0, weight=1)
        mod_table.grid_rowconfigure(1, weight=1)

        mod_header = ctk.CTkFrame(mod_table, height=38, fg_color="#141a19", corner_radius=6)
        mod_header.grid(row=0, column=0, sticky="ew")
        mod_header.grid_propagate(False)
        self._configure_mod_columns(mod_header)
        for column, label in enumerate(("状态", "WorkshopID", "模组名称", "大小", "")):
            ctk.CTkLabel(
                mod_header,
                text=label,
                anchor="w" if column != 3 else "e",
                text_color="#b7b2aa",
                font=ctk.CTkFont(size=11, weight="bold"),
            ).grid(row=0, column=column, sticky="ew", padx=(8, 4), pady=8)

        self.mod_rows = ctk.CTkScrollableFrame(
            mod_table,
            fg_color="#080c0c",
            corner_radius=0,
            scrollbar_button_color="#6a675f",
            scrollbar_button_hover_color="#a78849",
        )
        self.mod_rows.grid(row=1, column=0, sticky="nsew", padx=1, pady=(1, 1))
        self.mod_rows.grid_columnconfigure(0, weight=1)
        self._mod_row_widgets: list[object] = []
        self._set_mod_list_message("正在等待服务器模组清单…")

        actions = ctk.CTkFrame(right, fg_color="transparent")
        actions.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 10))
        actions.grid_columnconfigure((0, 1), weight=1)
        self.btn_check = ctk.CTkButton(
            actions,
            text="一键对齐模组\n检测并同步所有项目",
            image=self._ui_icon("sync", 27, 27),
            compound="left",
            height=52,
            fg_color="#272116",
            hover_color="#3a2e19",
            border_width=1,
            border_color=gold,
            text_color="#f0c76d",
            command=lambda: self._on_check(),
        )
        self.btn_check.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        self.btn_repair = ctk.CTkButton(
            actions,
            text="快速修复\n修复缺失与待更新",
            image=self._ui_icon("repair", 27, 27),
            compound="left",
            height=52,
            fg_color="#272116",
            hover_color="#3a2e19",
            border_width=1,
            border_color=gold,
            text_color="#f0c76d",
            command=self._on_repair,
        )
        self.btn_repair.grid(row=0, column=1, sticky="ew", padx=4, pady=4)
        self.btn_clean = ctk.CTkButton(
            actions,
            text="清理缓存\n仅清理日志与崩溃文件",
            image=self._ui_icon("trash", 27, 27),
            compound="left",
            height=52,
            fg_color="#171b1a",
            hover_color="#262c29",
            border_width=1,
            border_color="#333b37",
            text_color="#d5d0c7",
            command=self._on_clean_cache,
        )
        self.btn_clean.grid(row=1, column=0, sticky="ew", padx=4, pady=4)
        ctk.CTkButton(
            actions,
            text="更新模组状态\n重新读取 Steam 信息",
            image=self._ui_icon("refresh", 27, 27),
            compound="left",
            height=52,
            fg_color="#171b1a",
            hover_color="#262c29",
            border_width=1,
            border_color="#333b37",
            text_color="#d5d0c7",
            command=self._on_refresh,
        ).grid(row=1, column=1, sticky="ew", padx=4, pady=4)

        footer = ctk.CTkFrame(
            self,
            height=82,
            fg_color=panel,
            border_width=1,
            border_color=border,
            corner_radius=10,
        )
        footer.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
        footer.grid_columnconfigure(0, weight=1)
        footer.grid_propagate(False)
        ctk.CTkLabel(
            footer,
            text="社区与支持   QQ群 1014615974   |   模组状态通过后方可进入服务器",
            anchor="w",
            text_color=muted,
            font=ctk.CTkFont(size=13),
        ).grid(row=0, column=0, sticky="w", padx=18)
        self.btn_join = ctk.CTkButton(
            footer,
            text="进入服务器",
            image=self._ui_icon("play", 34, 34),
            compound="left",
            width=330,
            height=58,
            fg_color="#d7a744",
            hover_color="#efc66b",
            border_width=1,
            border_color="#ffe09a",
            text_color="#17110a",
            font=ctk.CTkFont(size=22, weight="bold"),
            command=self._on_join,
        )
        self.btn_join.grid(row=0, column=1, padx=12, pady=11, sticky="e")
        self.btn_join.configure(state="disabled")

        self._main_panel = main
        self._left_panel = left
        self._center_panel = center
        self._footer_panel = footer
        # 根窗口第一次 Configure 时，main 内部三栏通常还没完成排版。旧逻辑
        # 用 after_idle 立即读取 center_x，发布版在高 DPI 下会读到临时坐标，
        # 把左栏永久压到最小宽度。监听真正影响边界的几个容器，并短暂防抖，
        # 等网格尺寸稳定后再对齐浮动左栏。
        for layout_source in (self, main, center, footer):
            layout_source.bind("<Configure>", self._on_window_layout, add="+")
        self._schedule_left_panel_alignment(80)

        # 本地输入变更后自动保存
        self.var_player.trace_add("write", lambda *_: self._on_field_edited())
        self.var_dayz.trace_add("write", lambda *_: self._on_field_edited())
        self.var_minimize.trace_add("write", lambda *_: self._on_field_edited())

    def _load_steam_header(self) -> None:
        profile = load_steam_profile(str(self.service.launcher.get("steam_path", "") or ""))
        if not profile:
            self._steam_id64 = ""
            self.steam_name_label.configure(text="未检测到 Steam 账号")
            self.steam_id_label.configure(text="SteamID64: —")
            self.avatar_label.configure(image=None, text="?")
            return

        self._steam_id64 = profile.steam_id64
        self.steam_name_label.configure(text=profile.persona_name or "Steam 用户")
        self.steam_id_label.configure(text=f"SteamID64: {profile.steam_id64}")

        if profile.avatar_path and Image is not None:
            try:
                img = Image.open(profile.avatar_path).convert("RGBA")
                img = img.resize((76, 76), Image.Resampling.LANCZOS)
                self._avatar_image = ctk.CTkImage(light_image=img, dark_image=img, size=(76, 76))
                self.avatar_label.configure(image=self._avatar_image, text="")
                return
            except OSError:
                pass
        self.avatar_label.configure(image=None, text="Steam")

    def _on_copy_steam_id(self, _event=None) -> None:
        sid = (self._steam_id64 or "").strip()
        if not sid:
            return
        try:
            self.clipboard_clear()
            self.clipboard_append(sid)
            self.update_idletasks()
        except tk.TclError:
            return
        self.copy_tip_label.configure(text="已复制")
        if self._copy_tip_job is not None:
            try:
                self.after_cancel(self._copy_tip_job)
            except Exception:
                pass
        self._copy_tip_job = self.after(1500, lambda: self.copy_tip_label.configure(text=""))

    def _add_field(self, parent, row, col, label, variable) -> None:
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.grid(row=row, column=col, sticky="ew", padx=6, pady=4)
        box.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(box, text=label).grid(row=0, column=0, sticky="w")
        ctk.CTkEntry(box, textvariable=variable).grid(row=1, column=0, sticky="ew")

    def _on_window_layout(self, event) -> None:
        if event.widget not in (
            self,
            self._main_panel,
            self._center_panel,
            self._footer_panel,
        ):
            return
        self._schedule_left_panel_alignment(35)

    def _schedule_left_panel_alignment(self, delay_ms: int = 35) -> None:
        if self._layout_job is not None:
            try:
                self.after_cancel(self._layout_job)
            except Exception:
                pass
        self._layout_job = self.after(delay_ms, self._align_floating_left_panel)

    def _align_floating_left_panel(self) -> None:
        """让上移的左栏始终停在中栏之前，并在页脚之上结束。"""
        self._layout_job = None
        try:
            root_x = self.winfo_rootx()
            root_y = self.winfo_rooty()
            center_x = self._center_panel.winfo_rootx() - root_x
            footer_y = self._footer_panel.winfo_rooty() - root_y
            # winfo 返回屏幕像素，CTk configure 接收未缩放的逻辑尺寸。
            scale = float(self._left_panel._get_widget_scaling())
            left_x, left_y, width, height = floating_left_panel_geometry(
                center_x,
                footer_y,
                scale,
            )
            self._left_panel.configure(width=width, height=height)
            self._left_panel.place_configure(x=left_x, y=left_y)
            self._left_panel.lift()
        except (AttributeError, tk.TclError):
            return

    @staticmethod
    def _configure_mod_columns(frame) -> None:
        """统一表头和模组行列宽，避免内容改变时列位移。"""
        frame.grid_columnconfigure(0, weight=0, minsize=62)
        frame.grid_columnconfigure(1, weight=0, minsize=112)
        frame.grid_columnconfigure(2, weight=1, minsize=120)
        frame.grid_columnconfigure(3, weight=0, minsize=72)
        frame.grid_columnconfigure(4, weight=0, minsize=28)

    def _clear_mod_rows(self) -> None:
        for widget in self._mod_row_widgets:
            try:
                widget.destroy()
            except tk.TclError:
                pass
        self._mod_row_widgets = []

    def _set_mod_list_message(self, message: str, color: str = "#c8c3ba") -> None:
        self._clear_mod_rows()
        label = ctk.CTkLabel(
            self.mod_rows,
            text=message,
            anchor="nw",
            justify="left",
            wraplength=500,
            text_color=color,
            font=ctk.CTkFont(size=12),
        )
        label.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        self._mod_row_widgets.append(label)

    @staticmethod
    def _format_mod_size(value: int | None) -> str:
        size = int(value or 0)
        if size >= 1024**3:
            return f"{size / 1024**3:.1f} GB"
        if size > 0:
            return f"{size / 1024**2:.1f} MB"
        return "—"

    @staticmethod
    def _short_mod_name(name: str, limit: int = 27) -> str:
        value = str(name or "未命名模组")
        return value if len(value) <= limit else f"{value[: limit - 1]}…"

    def _populate_mod_rows(self, statuses) -> None:
        self._clear_mod_rows()
        ordered = sorted(statuses, key=lambda s: (0 if s.blocked else 1, s.name.lower()))
        for index, status in enumerate(ordered):
            if status.missing:
                label, color = "缺失", "#ff5c5c"
            elif status.needs_update:
                label, color = "更新", "#ef9f34"
            elif status.is_local_only:
                label, color = "本地", "#70cf32"
            else:
                label, color = "最新", "#70cf32"

            row = ctk.CTkFrame(
                self.mod_rows,
                height=34,
                fg_color="#0d1212" if index % 2 == 0 else "#090e0e",
                border_width=1,
                border_color="#1c2220",
                corner_radius=2,
            )
            row.grid(row=index, column=0, sticky="ew", pady=(0, 1))
            row.grid_propagate(False)
            self._configure_mod_columns(row)
            ctk.CTkLabel(
                row,
                text=f"●  {label}",
                anchor="w",
                text_color=color,
                font=ctk.CTkFont(size=11, weight="bold"),
            ).grid(row=0, column=0, sticky="ew", padx=(8, 2), pady=5)
            ctk.CTkLabel(
                row,
                text=str(status.workshop_id),
                anchor="w",
                text_color="#c9c5bd",
                font=ctk.CTkFont(family="Consolas", size=11),
            ).grid(row=0, column=1, sticky="ew", padx=3, pady=5)
            ctk.CTkLabel(
                row,
                text=self._short_mod_name(status.name),
                anchor="w",
                text_color="#d9d5ce",
                font=ctk.CTkFont(size=11),
            ).grid(row=0, column=2, sticky="ew", padx=3, pady=5)
            ctk.CTkLabel(
                row,
                text=self._format_mod_size(status.remote_size),
                anchor="e",
                text_color="#c9c5bd",
                font=ctk.CTkFont(size=11),
            ).grid(row=0, column=3, sticky="ew", padx=3, pady=5)
            if status.blocked:
                ctk.CTkLabel(
                    row,
                    text="",
                    image=self._ui_icon("download", 16, 16),
                    width=20,
                ).grid(row=0, column=4, padx=(2, 5), pady=5)
            self._mod_row_widgets.append(row)

    def _show_mod_details(self) -> None:
        report = self.service.last_report
        if report is None:
            messagebox.showinfo("模组详情", "尚未获取当前服务器的模组清单。")
            return
        blocked = [status for status in report.statuses if status.blocked]
        lines = [
            f"服务器：{report.server_name}",
            f"地图：{report.map_name or '未知'}",
            f"模组：{len(report.statuses)} 个，需要处理 {len(blocked)} 个",
            "",
        ]
        if blocked:
            lines.extend(
                f"{status.workshop_id}  {status.name}"
                + (f"\n  {status.downloading_hint}" if status.downloading_hint else "")
                for status in blocked
            )
        else:
            lines.append("全部模组已就绪。")
        messagebox.showinfo("模组详情", "\n".join(lines))

    @staticmethod
    def _server_tags(server: dict) -> tuple[str, ...]:
        name = f"{server.get('label', '')} {server.get('server_name', '')}"
        if "简单" in name:
            return ("PVE", "简单生存", "新手友好")
        if "硬核" in name:
            return ("PVE", "硬核生存", "高风险")
        return ("DayZ", "CYX 服务器")

    def _refresh_server_info(self) -> None:
        srv = server_by_option_label(self.var_server.get())
        selected_id = str(srv.get("id", ""))
        for server_id, card in self.server_card_frames.items():
            selected = server_id == selected_id
            card.configure(
                fg_color="#30240f" if selected else "#101515",
                border_color="#e0aa32" if selected else "#3a3d35",
                border_width=2 if selected else 1,
            )
            self.server_card_titles[server_id].configure(
                text_color="#f1cf85" if selected else "#e8e2d7"
            )
            self.server_card_icons[server_id].configure(text="♛" if selected else "➤")
            self.server_card_marks[server_id].configure(text="✓" if selected else "")

    def _select_server_card(self, option: str) -> None:
        """用参考图风格的服务器卡片替代下拉框，但保留原有换服检测逻辑。"""
        if self._busy:
            return
        if option == self.var_server.get():
            self._refresh_server_info()
            self._schedule_population_refresh(0, reset=True)
            return
        self.var_server.set(option)
        self._on_server_changed(option)

    def _show_population(self, player_count: int | None, max_players: int | None) -> None:
        srv = server_by_option_label(self.var_server.get())
        self._set_server_population(str(srv.get("id", "")), player_count, max_players)

    def _set_server_population(
        self,
        server_id: str,
        player_count: int | None,
        max_players: int | None,
    ) -> None:
        self._server_populations[server_id] = (player_count, max_players)
        players = self.server_card_player_labels.get(server_id)
        badge = self.server_card_badges.get(server_id)
        if players is None or badge is None:
            return
        if player_count is None or max_players is None:
            players.configure(text="—/—\n在线人数", text_color="#e6c07b")
            badge.configure(text="未知", fg_color="#302a1b", text_color="#e6c07b")
            return
        players.configure(
            text=f"{player_count}/{max_players}\n在线人数",
            text_color="#70cf32",
        )
        badge.configure(text="在线", fg_color="#20361b", text_color="#70cf32")

    def _refresh_all_server_populations_async(self) -> None:
        if self._all_population_querying:
            return
        self._all_population_querying = True
        self.btn_refresh_servers.configure(state="disabled", text="刷新中")
        servers = list(self.service.list_servers())
        for server in servers:
            badge = self.server_card_badges.get(str(server.get("id", "")))
            if badge is not None:
                badge.configure(text="查询中", fg_color="#27301b", text_color="#9acb63")

        def worker() -> None:
            results: list[tuple[str, int | None, int | None]] = []
            for server in servers:
                server_id = str(server.get("id", ""))
                population = None
                try:
                    population = query_server_population(
                        str(server["server_ip"]),
                        int(server["query_port"]),
                        timeout=4.0,
                        retries=1,
                    )
                except Exception:
                    pass
                if population is None:
                    results.append((server_id, None, None))
                else:
                    results.append(
                        (server_id, population.player_count, population.max_players)
                    )

            def done() -> None:
                self._all_population_querying = False
                self.btn_refresh_servers.configure(state="normal", text="刷新")
                for server_id, player_count, max_players in results:
                    self._set_server_population(server_id, player_count, max_players)

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _schedule_population_refresh(self, delay_ms: int = 30000, reset: bool = False) -> None:
        if self._population_job is not None:
            if not reset:
                return
            try:
                self.after_cancel(self._population_job)
            except Exception:
                pass
        self._population_job = self.after(delay_ms, self._refresh_population_async)

    def _refresh_population_async(self) -> None:
        self._population_job = None
        if self._population_querying:
            self._schedule_population_refresh(3000)
            return

        srv = server_by_option_label(self.var_server.get())
        server_id = str(srv.get("id", ""))
        ip = str(srv["server_ip"])
        query_port = int(srv["query_port"])
        self._population_querying = True

        def worker() -> None:
            population = None
            try:
                population = query_server_population(ip, query_port, timeout=4.0, retries=1)
            except Exception:
                pass

            def done() -> None:
                self._population_querying = False
                current = server_by_option_label(self.var_server.get())
                if str(current.get("id", "")) == server_id:
                    if population is None:
                        self._show_population(None, None)
                    else:
                        self._show_population(population.player_count, population.max_players)
                self._schedule_population_refresh()

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _persist_quiet(self) -> None:
        """静默保存当前界面选项（服务器/目录/角色名），供下次启动恢复。"""
        try:
            self.service.save_launcher(self._collect_launcher())
        except Exception:
            pass

    def _on_close(self) -> None:
        """退出前强制保存当前服务器与目录，避免下次回到默认服。"""
        self._operations.cancel()
        try:
            self._persist_quiet()
        finally:
            if self._population_job is not None:
                try:
                    self.after_cancel(self._population_job)
                except Exception:
                    pass
            self.destroy()

    def _on_server_changed(self, _value: str = "") -> None:
        if self._loading:
            return
        self._refresh_server_info()
        self._schedule_population_refresh(0, reset=True)
        self.service.last_report = None
        self._stop_repair_poll()
        self.btn_join.configure(state="disabled")
        self._persist_quiet()
        self._set_gate("已切换服务器，正在自动对齐模组…", "#e6c07b")
        self._set_progress(1.0, "待命")
        # 换服后自动检测，免去再点一次
        self.after(50, self._on_check)

    def _load_fields(self) -> None:
        self._loading = True
        try:
            l = self.service.launcher
            options = server_option_labels()
            self.server_menu.configure(values=options)
            selected = self.service.server
            current = next(
                (
                    opt
                    for opt, s in zip(options, self.service.list_servers())
                    if s["id"] == selected["id"]
                ),
                options[0],
            )
            self.var_server.set(current)
            self._refresh_server_info()
            saved_name = str(l.get("player_name", "")).strip()
            name, source = resolve_player_name(saved_name)
            self.var_player.set(name)
            saved_dayz = str(l.get("dayz_path", "")).strip()
            self.var_dayz.set(saved_dayz)
            # 未保存过路径时，启动即自动填入本机 DayZ 目录并记住
            if not saved_dayz:
                self._auto_detect_dayz(silent=True)
            else:
                self._set_status(f"已恢复上次目录：{saved_dayz}")
            if name:
                self._set_status(f"角色名来自{source}：{name}")
            self.var_minimize.set(bool(l.get("minimize_on_join", True)))
            # 首次从官方抓到的名字立刻写入本地，之后不再跟官方
            self._persist_quiet()
        finally:
            self._loading = False

    def _on_field_edited(self, *_args) -> None:
        if self._loading:
            return
        self._persist_quiet()

    def _auto_check_on_startup(self) -> None:
        if self._update_checking:
            self.after(250, self._auto_check_on_startup)
            return
        if self._update_required or self._update_in_progress:
            return
        if self._busy:
            return
        self._set_gate("正在按上次选择的服务器自动对齐模组…", "#e6c07b")
        self._on_check()

    def _auto_detect_dayz(self, silent: bool = False) -> None:
        path = detect_dayz_path_text(
            steam_override=str(self.service.launcher.get("steam_path", "") or ""),
            dayz_override="",
        )
        if path:
            self.var_dayz.set(path)
            self._persist_quiet()
            self._set_status(f"已自动检测 DayZ：{path}")
            if not silent:
                messagebox.showinfo("自动检测", f"已找到 DayZ 目录：\n{path}")
        else:
            self._set_status("未自动找到 DayZ，请手动浏览")
            if not silent:
                messagebox.showwarning(
                    "自动检测失败",
                    "未能从 Steam 库自动找到 DayZ。\n请确认已安装游戏，或点击「浏览」手动选择 DayZ 目录。",
                )

    def _browse_dayz(self) -> None:
        path = filedialog.askdirectory(title="选择 DayZ 安装目录（含 DayZ_x64.exe）")
        if path:
            self.var_dayz.set(path)
            self._persist_quiet()
            self._set_status(f"已保存 DayZ 目录：{path}")

    def _collect_launcher(self) -> dict:
        srv = server_by_option_label(self.var_server.get())
        data = dict(self.service.launcher)
        data.update(
            {
                "player_name": self.var_player.get().strip(),
                "dayz_path": self.var_dayz.get().strip(),
                "use_battleye": True,
                "minimize_on_join": bool(self.var_minimize.get()),
                "selected_server_id": srv["id"],
            }
        )
        return data

    def _set_busy(self, busy: bool, text: str = "") -> None:
        self._busy = busy
        state = "disabled" if busy else "normal"
        for btn in (self.btn_check, self.btn_repair, self.btn_clean, self.btn_app_update):
            btn.configure(state=state)
        # 「刷新」在修理等待中也可用，用来重新检测
        self.server_menu.configure(state=state)
        if busy:
            self.btn_join.configure(state="disabled")
        elif self._update_required:
            self.btn_join.configure(state="disabled")
        else:
            can = bool(self.service.last_report and self.service.last_report.can_join)
            self.btn_join.configure(state="normal" if can else "disabled")
        if text:
            self._set_status(text)

    def _set_status(self, text: str) -> None:
        # 状态详情由中部更新中心呈现；右上角不再堆叠第二个状态框。
        self._last_status = str(text or "")

    def _set_update_button_state(
        self,
        text: str,
        tone: str = "idle",
        state: str = "normal",
    ) -> None:
        palette = {
            "idle": ("#111512", "#2a2417", "#d6a440", "#efc66b", "refresh"),
            "busy": ("#211b10", "#2a2417", "#d6a440", "#efc66b", "refresh"),
            "ok": ("#102015", "#183522", "#397e46", "#70cf32", "shield"),
            "error": ("#241313", "#3a1919", "#934141", "#ff7068", "refresh"),
        }
        fg, hover, border, color, icon_name = palette.get(tone, palette["idle"])
        self.btn_app_update.configure(
            text=text,
            state=state,
            fg_color=fg,
            hover_color=hover,
            border_color=border,
            text_color=color,
            text_color_disabled=color,
            image=self._ui_icon(icon_name, 17, 17),
        )

    def _set_gate(self, text: str, color: str = "#e6c07b") -> None:
        self.gate_label.configure(text=text, text_color=color)

    def _set_progress(self, fraction: float, detail: str) -> None:
        self.progress_bar.set(max(0.0, min(1.0, float(fraction))))
        self.progress_text.configure(text=f"Steam 下载：{detail}")

    def _stop_repair_poll(self, *, invalidate: bool = True) -> None:
        if invalidate:
            self._operations.cancel()
        if self._repair_poll_job is not None:
            try:
                self.after_cancel(self._repair_poll_job)
            except Exception:
                pass
            self._repair_poll_job = None
        self._repair_targets = []
        self._repair_queue = []
        self._repair_active_target = None
        self._repair_retry_counts = {}
        self._repair_handled_failures = set()
        self._repair_subscription_only = False
        self._repair_content_log_offset = 0
        self._repair_workshop_log_offset = 0
        self._active_repair_token = None

    def _on_refresh(self) -> None:
        """刷新模组状态（也会停掉修理等待轮询）。"""
        if self._busy and not self._repair_targets:
            return
        self._stop_repair_poll()
        self._set_busy(False)
        self._on_check()

    def _start_repair_poll(
        self,
        target_ids: list[int],
        *,
        subscription_only: bool = False,
        content_log_offset: int = 0,
        workshop_log_offset: int = 0,
        token: OperationToken,
    ) -> None:
        if not self._operations.is_current(token):
            return
        self._stop_repair_poll(invalidate=False)
        self._active_repair_token = token
        self._repair_targets = list(target_ids)
        self._repair_subscription_only = bool(subscription_only)
        self._repair_content_log_offset = max(0, int(content_log_offset or 0))
        self._repair_workshop_log_offset = max(0, int(workshop_log_offset or 0))
        self._repair_active_target = (
            None if subscription_only else (target_ids[0] if target_ids else None)
        )
        self._repair_queue = [] if subscription_only else list(target_ids[1:])
        self._repair_retry_counts = {}
        self._repair_handled_failures = set()
        if subscription_only:
            self._set_progress(0.02, f"已提交 {len(target_ids)} 个模组，等待 Steam 下载信息…")
            self._set_gate(
                "已订阅全部缺失模组，下载由 Steam 官方队列处理…",
                "#e6c07b",
            )
        else:
            self._set_progress(
                0.02,
                f"按顺序修理 {len(target_ids)} 个模组；当前只向 Steam 下达第 1 个…",
            )
            self._set_gate(
                "正在逐个更新：只处理 Steam 明确标记的项目，不做深度完整性验证…",
                "#e6c07b",
            )
        self._poll_repair_once(0, token)

    def _poll_repair_once(self, ticks: int, token: OperationToken) -> None:
        if not self._operations.is_current(token):
            return
        targets = list(self._repair_targets)
        active_target = self._repair_active_target
        repair_queue = list(self._repair_queue)
        subscription_only = bool(self._repair_subscription_only)
        content_log_offset = int(self._repair_content_log_offset)
        workshop_log_offset = int(self._repair_workshop_log_offset)
        if not targets:
            return

        step = {
            "active": active_target,
            "queue": repair_queue,
            "started": None,
            "retried": None,
            "terminal_failure": None,
            "retry_counts": dict(self._repair_retry_counts),
            "handled_failures": set(self._repair_handled_failures),
        }

        def worker():
            err = None
            prog = None
            try:
                # 下载期间只做低频轻量读取。每 4 轮（约 32 秒）
                # 才刷新一次完整本地状态，避免反复初始化多个
                # SteamUGC 会话与 Steam 下载争用资源。
                report = self.service.last_report
                if report is None:
                    self.service.query_and_evaluate(operation_id=token.operation_id)
                elif ticks > 0 and ticks % 4 == 0:
                    self.service.refresh_current_report(
                        refresh_remote=False,
                        operation_id=token.operation_id,
                    )

                report = self.service.last_report
                if (
                    not subscription_only
                    and report is not None
                    and step["active"] is not None
                    and ticks > 0
                    and ticks % 4 == 0
                ):
                    by_id = {s.workshop_id: s for s in report.statuses}
                    active_status = by_id.get(int(step["active"]))
                    if active_status is not None and not active_status.blocked:
                        step["active"] = None

                # 上一项完成后才选择下一项；已被 Steam 自动更新好的直接跳过。
                while (
                    not subscription_only
                    and step["active"] is None
                    and step["queue"]
                ):
                    candidate = int(step["queue"].pop(0))
                    report = self.service.last_report
                    by_id = {s.workshop_id: s for s in report.statuses} if report else {}
                    candidate_status = by_id.get(candidate)
                    if candidate_status is not None and not candidate_status.blocked:
                        continue
                    self.service.trigger_repair_item(
                        candidate,
                        operation_id=token.operation_id,
                        workshop_log_offset=workshop_log_offset,
                    )
                    step["active"] = candidate
                    step["started"] = candidate
                    break
                prog = self.service.progress_for(
                    targets,
                    content_log_offset=content_log_offset,
                    workshop_log_offset=workshop_log_offset,
                )
                # 字节已完成时立即做一次最终状态确认，不必再等
                # 下一个 32 秒完整刷新周期。
                if prog.total > 0 and prog.done >= prog.total:
                    # 完成判定必须和“进入服务器”使用同一套完整查询。
                    # 轻量本地刷新不能证明线上版本已经安装完成。
                    self.service.query_and_evaluate(
                        steam_verify=False,
                        operation_id=token.operation_id,
                    )
                if (
                    not subscription_only
                    and
                    prog.failed_id is not None
                    and prog.failure_key
                    and prog.failure_key not in step["handled_failures"]
                ):
                    failed_id = int(prog.failed_id)
                    step["handled_failures"].add(prog.failure_key)
                    retries = int(step["retry_counts"].get(failed_id, 0))
                    if retries < 2:
                        self.service.trigger_repair_item(
                            failed_id,
                            operation_id=token.operation_id,
                            workshop_log_offset=workshop_log_offset,
                        )
                        step["retry_counts"][failed_id] = retries + 1
                        step["retried"] = (
                            failed_id,
                            retries + 1,
                            prog.failure_detail,
                        )
                    else:
                        step["terminal_failure"] = (
                            failed_id,
                            prog.failure_detail,
                        )
            except Exception as e:
                err = e

            def done():
                if not self._operations.is_current(token):
                    log_event(
                        "stale_repair_callback_ignored",
                        operation_id=token.operation_id,
                        category="state",
                    )
                    return
                if err is not None:
                    self._set_gate(f"修理进度刷新失败：{err}", "#ff6b6b")
                    self._set_status("进度刷新失败")
                    self._set_busy(False)
                    self._stop_repair_poll()
                    return

                assert prog is not None
                self._repair_active_target = step["active"]
                self._repair_queue = list(step["queue"])
                self._repair_retry_counts = dict(step["retry_counts"])
                self._repair_handled_failures = set(step["handled_failures"])
                self._set_progress(prog.fraction, prog.detail)
                self._render_report()
                if step["terminal_failure"] is not None:
                    failed_id, failure_detail = step["terminal_failure"]
                    self._set_gate(
                        f"Steam 更新失败（WorkshopID {failed_id}）：{failure_detail}。"
                        "启动器已重试 2 次，请稍后再点「快速修复」。",
                        "#ff6b6b",
                    )
                    self._set_status("Steam 更新失败")
                    self._set_busy(False)
                    self._stop_repair_poll()
                    return
                if prog.done >= prog.total and prog.total > 0:
                    report = self.service.last_report
                    if report is not None and report.can_join:
                        finish_text = "订阅模组已全部下载完成" if subscription_only else "修理完成"
                        self._set_gate(f"{finish_text}：可以进入服务器。", "#3dd68c")
                        self._set_status(finish_text)
                        self._set_busy(False)
                        self._stop_repair_poll()
                        return
                    if subscription_only and not self.service.missing_workshop_ids():
                        self._set_gate(
                            "缺失模组已下载完成；如仍有待更新项，请点击「快速修复」。",
                            "#e6c07b",
                        )
                        self._set_status("订阅下载完成")
                        self._set_busy(False)
                        self._stop_repair_poll()
                        return
                    self._set_gate(
                        f"Steam 下载已返回完成，但本地清单仍未放行（{prog.detail}）。正在继续刷新…",
                        "#e6c07b",
                    )

                # 8 秒一次，最长等待约 20 分钟。
                if ticks >= 150:
                    self._set_gate(
                        f"仍有模组未完成（{prog.done}/{prog.total}）。可稍后再点检测，或确认 Steam 正在下载。",
                        "#e6c07b",
                    )
                    self._set_status("等待超时")
                    self._set_busy(False)
                    self._stop_repair_poll()
                    return

                if step["retried"] is not None:
                    failed_id, retry_no, failure_detail = step["retried"]
                    self._set_gate(
                        f"Steam 返回失败（{failure_detail}），正在自动重试 "
                        f"{retry_no}/2（WorkshopID {failed_id}）…",
                        "#e6c07b",
                    )
                elif step["started"] is not None:
                    started_id = int(step["started"])
                    report = self.service.last_report
                    by_id = {s.workshop_id: s.name for s in report.statuses} if report else {}
                    started_name = by_id.get(started_id, str(started_id))
                    self._set_gate(
                        f"上一项已完成；现在开始下一项：{started_name}。仍保持单项下达。",
                        "#e6c07b",
                    )
                elif ticks >= 4 and prog.done == 0:
                    self._set_gate(
                        f"Steam 正在校验、排队或等待内容源（{prog.detail}）。"
                        "启动器不会打开 Steam 下载页。",
                        "#e6c07b",
                    )
                else:
                    self._set_gate(
                        f"正在下载/更新模组… {prog.detail}（保持 Steam 在线）",
                        "#e6c07b",
                    )
                next_tick = (
                    1
                    if step["started"] is not None or step["retried"] is not None
                    else ticks + 1
                )
                self._repair_poll_job = self.after(
                    8000, lambda: self._poll_repair_once(next_tick, token)
                )

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _render_report(self) -> None:
        report = self.service.last_report
        if report is None:
            return

        self._show_population(report.player_count, report.max_players)
        self._schedule_population_refresh()

        ready_count = sum(1 for status in report.statuses if not status.blocked)
        blocked_count = len(report.statuses) - ready_count
        remote_bytes = sum(int(status.remote_size or 0) for status in report.statuses)
        if remote_bytes >= 1024**3:
            size_text = f"{remote_bytes / 1024**3:.1f} GB"
        elif remote_bytes > 0:
            size_text = f"{remote_bytes / 1024**2:.1f} MB"
        else:
            size_text = "未知大小"
        self.mod_ready_value.configure(text=f"{ready_count}\n最新")
        self.mod_update_value.configure(text=f"{blocked_count}\n需要处理")
        self.mod_total_value.configure(text=f"总大小\n{size_text}")
        self.mod_sync_title.configure(
            text=f"┃ 模组同步  （共 {ready_count} / {len(report.statuses)}）"
        )
        self._populate_mod_rows(report.statuses)
        # 修理轮询中不覆盖 gate 文案
        if not self._repair_targets:
            warnings = list(getattr(report, "source_warnings", []) or [])
            if report.can_join and warnings:
                color = "#e6c07b"
                warning_text = "；".join(warnings[:2])
                gate_text = f"{report.gate_message} 检测降级: {warning_text}"
            else:
                color = "#3dd68c" if report.can_join else "#ff6b6b"
                gate_text = report.gate_message
            self.gate_label.configure(text=gate_text, text_color=color)
            # 非下载中：进度条保持满格；有缺失/待更新时用完成比例提示
            if report.can_join:
                self._set_progress(1.0, "全部就绪")
            else:
                total = len(report.statuses) or 1
                ok = sum(1 for s in report.statuses if not s.blocked)
                self._set_progress(ok / total, f"已就绪 {ok}/{total}（有缺失或待更新）")
        self.btn_join.configure(
            state="normal"
            if report.can_join and not self._busy and not self._update_required
            else "disabled"
        )
        if self._update_required:
            version = self._pending_update.version if self._pending_update else "新版"
            self._set_gate(f"启动器必须更新到 v{version} 后才能进入服务器。", "#ff6b6b")

    def _run_bg(self, title: str, fn) -> None:
        if self._busy:
            return
        self._persist_quiet()
        self._set_busy(True, title)
        self._set_gate(title, "#e6c07b")

        def worker():
            err = None
            try:
                fn()
            except Exception as e:
                err = e

            def done():
                self._set_busy(False)
                if err is not None:
                    self._set_status("失败")
                    self._set_gate(str(err), "#ff6b6b")
                else:
                    self._render_report()
                    self._set_status("完成")

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _on_clean_cache(self) -> None:
        if self._busy:
            return
        root = dayz_localappdata()
        count, nbytes = estimate_cache_bytes(root)
        if count == 0:
            self._set_gate(f"没有可清理的缓存日志（目录：{root}）", "#3dd68c")
            self._set_status("无需清理")
            return

        if is_dayz_running():
            ok = messagebox.askyesno(
                "DayZ 正在运行",
                "检测到 DayZ 正在运行，部分日志可能删不掉。\n"
                "建议先关闭游戏再清理。\n\n仍要继续吗？",
            )
            if not ok:
                self._set_gate("已取消清理缓存。", "#e6c07b")
                return

        ok = messagebox.askyesno(
            "清理 DayZ 缓存",
            f"将清理：\n{root}\n\n"
            f"预计删除 {count} 个日志/崩溃文件（约 {format_bytes(nbytes)}）。\n"
            "不会删除模组配置文件夹。\n\n确认清理？",
        )
        if not ok:
            self._set_gate("已取消清理缓存。", "#e6c07b")
            return

        self._set_busy(True, "清理中…")
        self._set_gate("正在清理 DayZ 缓存…", "#e6c07b")

        def worker():
            err = None
            result = None
            try:
                result = clear_dayz_cache(root)
            except Exception as e:
                err = e

            def done():
                self._set_busy(False)
                if err is not None:
                    self._set_status("清理失败")
                    self._set_gate(f"清理失败：{err}", "#ff6b6b")
                    return
                assert result is not None
                self._set_status("清理完成")
                self._set_gate(result.message, "#3dd68c")

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _on_close_game(self) -> None:
        if self._closing_game:
            return
        if not is_dayz_running():
            self._set_status("游戏未运行")
            self._set_gate("DayZ 游戏客户端当前未运行。", "#3dd68c")
            return
        if not messagebox.askyesno(
            "关闭游戏",
            "确定要关闭正在运行的 DayZ 吗？\n\n"
            "这只会关闭玩家客户端，不会关闭 Steam 或 DayZ 服务器进程。",
        ):
            return

        self._closing_game = True
        self.btn_close_game.configure(state="disabled", text="正在关闭…")
        self._set_status("正在关闭 DayZ…")

        def worker() -> None:
            result = close_dayz_client()

            def done() -> None:
                self._closing_game = False
                self.btn_close_game.configure(state="normal", text="关闭游戏")
                if result.errors:
                    self._set_status("关闭失败")
                    self._set_gate(result.message, "#ff6b6b")
                elif result.closed:
                    self._set_status("游戏已关闭")
                    self._set_gate(result.message, "#3dd68c")
                else:
                    self._set_status("游戏未运行")
                    self._set_gate(result.message, "#3dd68c")

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _show_check_failure(self, err: BaseException) -> None:
        """检测失败时清掉旧报告，避免「超时」和「全部最新」同时出现。"""
        from .server_query import format_query_error

        srv = self.service.server
        msg = format_query_error(
            err,
            ip=str(srv.get("server_ip", "") or ""),
            query_port=int(srv.get("query_port") or 0),
        )
        self.service.last_report = None
        self._show_population(None, None)
        self._schedule_population_refresh()
        self._set_status("检测失败")
        self._set_progress(0.0, "检测失败")
        self._set_gate(msg, "#ff6b6b")
        self.btn_join.configure(state="disabled")
        self.mod_ready_value.configure(text="0\n最新")
        self.mod_update_value.configure(text="0\n需要处理")
        self.mod_total_value.configure(text="总大小\n—")
        self.mod_sync_title.configure(text="┃ 模组同步")
        self._set_mod_list_message(
            "查询服务器失败，尚未取得当前服模组列表。\n"
            "请确认服务器在线后，再点「一键对齐模组 / 检测更新」。\n",
            "#e6c07b",
        )

    def _on_check(self) -> None:
        """检测模组状态；有缺失项时询问是否一次订阅全部。"""
        if self._busy:
            return
        self._stop_repair_poll()
        token = self._operations.begin("check")
        self._persist_quiet()
        self._set_busy(True, "检测中…")
        self._set_gate("正在对齐模组 / 检测更新…", "#e6c07b")
        self._set_progress(0.0, "查询服务器中…")

        def worker():
            err = None
            try:
                # 检测必须只读。DownloadItem 只能由“修理”按钮调用，
                # 否则仅检测状态也会创建 Workshop 下载任务。
                self.service.query_and_evaluate(
                    steam_verify=False,
                    operation_id=token.operation_id,
                )
            except Exception as e:
                err = e

            def done():
                if not self._operations.is_current(token):
                    log_event(
                        "stale_check_callback_ignored",
                        operation_id=token.operation_id,
                        category="state",
                    )
                    return
                self._set_busy(False)
                if err is not None:
                    self._show_check_failure(err)
                    return

                self._render_report()
                self._set_status("检测完成")
                self._offer_subscribe_missing()

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _on_repair(self, skip_requery: bool = False) -> None:
        """逐个修理缺失/需更新的模组，避免同时向 Steam 下达多个任务。"""
        if self._busy:
            return
        self._persist_quiet()
        self._stop_repair_poll()
        token = self._operations.begin("repair")
        self._set_busy(True, "修理中…")
        self._set_gate("正在快速修复 !Workshop 链接，并筛选 Steam 明确需更新的项目…", "#e6c07b")
        self._set_progress(0.0, "准备中…")

        def worker():
            err = None
            count = 0
            ids: list[int] = []
            content_log_offset = 0
            workshop_log_offset = 0
            try:
                content_log_offset = self.service.content_log_offset()
                workshop_log_offset = self.service.workshop_log_offset()
                if not skip_requery or self.service.last_report is None:
                    self.service.query_and_evaluate(operation_id=token.operation_id)
                count, ids = self.service.repair_outdated_and_missing(
                    force_all=False,
                    operation_id=token.operation_id,
                    workshop_log_offset=workshop_log_offset,
                )
                if count == 0:
                    # 链接修复或本地轻量刷新后再执行一次与进服相同的完整门禁。
                    # 若 Steam 在线元数据刚传播到本机，立即重新筛选并下达修复，
                    # 不能先显示“修复完成”再由进服按钮把玩家拦下。
                    final_report = self.service.query_and_evaluate(
                        steam_verify=False,
                        operation_id=token.operation_id,
                    )
                    if not final_report.can_join:
                        count, ids = self.service.repair_outdated_and_missing(
                            force_all=False,
                            operation_id=token.operation_id,
                            workshop_log_offset=workshop_log_offset,
                        )
            except Exception as e:
                err = e

            def done():
                if not self._operations.is_current(token):
                    log_event(
                        "stale_repair_start_callback_ignored",
                        operation_id=token.operation_id,
                        category="state",
                    )
                    return
                if err is not None:
                    self._set_busy(False)
                    self._set_status("失败")
                    self._set_gate(f"修理失败：{err}", "#ff6b6b")
                    self._set_progress(0.0, "失败")
                    if self.service.last_report:
                        self._render_report()
                    return

                self._render_report()
                link_count = int(getattr(self.service, "last_fast_link_repairs", 0) or 0)
                link_errors = list(getattr(self.service, "last_fast_link_errors", []) or [])
                if count == 0:
                    self._set_busy(False)
                    report = self.service.last_report
                    if report is None or not report.can_join:
                        gate_message = (
                            report.gate_message
                            if report is not None
                            else "尚未取得可用于进服的最终检测结果。"
                        )
                        self._set_status("修复尚未完成")
                        self._set_gate(
                            f"快速修复尚未完成：{gate_message}",
                            "#ff6b6b",
                        )
                        self._set_progress(0.0, "仍有缺失或待更新项目")
                    elif link_count:
                        self._set_status("快速修复完成")
                        self._set_gate(
                            f"快速修复完成：已重建 {link_count} 个 !Workshop 链接，未触发模组下载。",
                            "#3dd68c",
                        )
                        self._set_progress(1.0, "链接修复完成")
                    elif link_errors:
                        self._set_status("链接修复受阻")
                        self._set_gate(f"未触发下载；链接修复受阻：{link_errors[0]}", "#e6c07b")
                        self._set_progress(1.0, "未触发下载")
                    else:
                        self._set_status("无需修理")
                        self._set_gate("没有缺失/待更新模组，未触发深度校验或下载。", "#3dd68c")
                        self._set_progress(1.0, "无需修理")
                    return

                names = []
                if self.service.last_report:
                    by_id = {s.workshop_id: s.name for s in self.service.last_report.statuses}
                    names = [by_id.get(i, str(i)) for i in ids[:3]]
                tip = "、".join(names)
                if count > 3:
                    tip += f" 等 {count} 个"
                self._set_gate(
                    f"快速链接修复 {link_count} 个；将逐个更新 {count} 个 Steam 明确目标（{tip}）。",
                    "#e6c07b",
                )
                self._start_repair_poll(
                    ids,
                    content_log_offset=content_log_offset,
                    workshop_log_offset=workshop_log_offset,
                    token=token,
                )

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _on_join(self) -> None:
        if self._update_required:
            self._set_gate("请先完成启动器更新，再进入服务器。", "#ff6b6b")
            return
        if self._busy:
            return
        token = self._operations.begin("join")

        def job():
            self.service.join_if_allowed(operation_id=token.operation_id)

        self._persist_quiet()
        self._set_busy(True, "启动中…")
        self._set_gate("正在设置模组/DLC 并加入服务器…", "#e6c07b")

        def worker():
            err = None
            try:
                job()
            except Exception as e:
                err = e

            def done():
                if not self._operations.is_current(token):
                    log_event(
                        "stale_join_callback_ignored",
                        operation_id=token.operation_id,
                        category="state",
                    )
                    return
                self._set_busy(False)
                if err is not None:
                    self._set_status("禁止进入")
                    self._set_gate(str(err), "#ff6b6b")
                    if self.service.last_report:
                        self._render_report()
                else:
                    self._set_status("已启动 DayZ")
                    self._set_gate("已设置模组/DLC 并启动进服。", "#3dd68c")
                    if self.service.last_report:
                        self._render_report()
                    if self.var_minimize.get():
                        self.iconify()

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _offer_subscribe_missing(self) -> None:
        """首次/手动检测后，让玩家确认是否批量订阅缺失模组。"""
        ids = self.service.missing_workshop_ids()
        if not ids or self._busy:
            return
        report = self.service.last_report
        by_id = {s.workshop_id: s.name for s in report.statuses} if report else {}
        preview = "\n".join(f"• {by_id.get(wid, wid)}" for wid in ids[:6])
        if len(ids) > 6:
            preview += f"\n• 其他 {len(ids) - 6} 个"
        confirmed = messagebox.askyesno(
            "订阅服务器模组",
            f"检测到 {len(ids)} 个未安装的 Workshop 模组：\n\n"
            f"{preview}\n\n"
            "是否使用当前 Steam 账号订阅全部模组？\n"
            "确认后下载由 Steam 官方队列处理，启动器只显示进度。",
            parent=self,
        )
        if confirmed:
            self._subscribe_missing_workshop_items(ids)

    def _subscribe_missing_workshop_items(self, ids: list[int]) -> None:
        """批量交给 Steam 订阅，随后进入低频只读进度监控。"""
        if self._busy or not ids:
            return
        targets = list(dict.fromkeys(int(wid) for wid in ids if int(wid) > 0))
        if not targets:
            return
        token = self._operations.begin("subscribe")
        self._set_busy(True, "正在提交订阅…")
        self._set_gate("正在向 Steam 提交全部缺失模组…", "#e6c07b")
        self._set_progress(0.0, "准备订阅…")

        def worker():
            err = None
            accepted = 0
            message = ""
            offset = 0
            workshop_offset = 0
            try:
                offset = self.service.content_log_offset()
                workshop_offset = self.service.workshop_log_offset()
                accepted, message = self.service.subscribe_workshop_items(targets)
            except Exception as exc:
                err = exc

            def done():
                if not self._operations.is_current(token):
                    log_event(
                        "stale_subscribe_callback_ignored",
                        operation_id=token.operation_id,
                        category="state",
                    )
                    return
                if err is not None or accepted <= 0:
                    self._set_busy(False)
                    detail = str(err) if err is not None else message
                    self._set_status("订阅失败")
                    self._set_gate(f"无法向 Steam 提交订阅：{detail}", "#ff6b6b")
                    self._set_progress(0.0, "订阅失败")
                    return
                if accepted < len(targets):
                    messagebox.showwarning(
                        "部分订阅未提交",
                        f"Steam 已接受 {accepted}/{len(targets)} 个项目。\n"
                        "启动器将继续监控；未提交项可稍后再点检测。",
                        parent=self,
                    )
                self._set_status("已提交 Steam 订阅")
                self._start_repair_poll(
                    targets,
                    subscription_only=True,
                    content_log_offset=offset,
                    workshop_log_offset=workshop_offset,
                    token=token,
                )

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _check_app_update_on_startup(self) -> None:
        self._start_app_update_check(manual=False)

    def _on_manual_app_update(self) -> None:
        self._start_app_update_check(manual=True)

    def _start_app_update_check(self, manual: bool) -> None:
        if self._update_checking or self._update_in_progress:
            if manual:
                self._set_status("正在检查/更新中…")
            return
        manifest_urls = get_update_manifest_urls()
        if not manifest_urls:
            self._update_checking = False
            if manual:
                self._set_update_button_state("未配置更新", "error")
                self._set_status("未配置更新地址")
                self._set_gate("启动器没有配置更新清单地址。", "#ff6b6b")
            return

        self._update_checking = True
        self._set_update_button_state("检查中…", "busy", "disabled")
        if manual:
            self._set_status("正在检查启动器更新…")
            self._set_gate("正在连接更新服务并检查新版本…", "#e6c07b")

        def worker() -> None:
            manifest = None
            error = None
            try:
                manifest = fetch_update_manifest_from_urls(manifest_urls)
            except Exception as exc:
                error = exc

            def done() -> None:
                self._update_checking = False
                if error is not None or manifest is None:
                    # 自动检查失败不影响进服；手动检查必须给出明确反馈。
                    if manual:
                        self._set_update_button_state("重试更新", "error")
                        self._set_status("更新检查失败")
                        self._set_gate(f"无法连接更新服务：{error}", "#ff6b6b")
                    else:
                        self._set_update_button_state("检查更新")
                    return
                if not is_newer_version(manifest.version, __version__):
                    self._set_update_button_state("已是最新版", "ok")
                    if manual:
                        self._set_status("已是最新版")
                        self._set_gate(f"当前启动器 v{__version__} 已是最新版。", "#3dd68c")
                    return
                self._pending_update = manifest
                self._set_update_button_state(f"发现 v{manifest.version}")
                if manifest.mandatory:
                    self._update_required = True
                    self._begin_app_update(manifest)
                    return
                notes = f"\n\n{manifest.notes}" if manifest.notes else ""
                if messagebox.askyesno(
                    "发现启动器更新",
                    f"发现新版 v{manifest.version}，是否现在更新？{notes}",
                ):
                    self._begin_app_update(manifest)

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    def _begin_app_update(self, manifest: UpdateManifest) -> None:
        if self._update_in_progress:
            return
        self._pending_update = manifest
        self._update_required = bool(manifest.mandatory)
        self._update_in_progress = True
        self._set_busy(True, f"正在更新到 v{manifest.version}…")
        self._set_update_button_state("更新中…", "busy", "disabled")
        self._set_gate(f"正在下载启动器 v{manifest.version}，完成后会自动安装并重启…", "#e6c07b")
        self._set_progress(0.0, "启动器更新 0%")

        def progress(done: int, total: int) -> None:
            fraction = done / total if total else 0.0
            detail = f"启动器更新 {fraction * 100:.1f}% · {done / 1048576:.1f}/{total / 1048576:.1f} MB"
            self.after(0, lambda: self._set_progress(fraction, detail))

        def worker() -> None:
            installer = None
            error = None
            try:
                installer = download_update(manifest, progress=progress)
            except Exception as exc:
                error = exc

            def done() -> None:
                self._update_in_progress = False
                if error is not None or installer is None:
                    self._set_busy(False)
                    self._set_update_button_state("更新失败", "error")
                    self._set_status("启动器更新失败")
                    self._set_gate(f"启动器更新失败：{error}。请重新打开启动器重试。", "#ff6b6b")
                    self._set_progress(0.0, "启动器更新失败")
                    return
                try:
                    self._set_status("正在安装新版…")
                    self._set_gate("安装包校验通过，正在退出旧版并静默安装…", "#3dd68c")
                    self._set_progress(1.0, "校验完成，准备安装")
                    launch_update_helper(
                        installer,
                        expected_version=manifest.version,
                    )
                    self.after(150, self.destroy)
                except Exception as exc:
                    self._set_busy(False)
                    self._set_update_button_state("重试更新", "error")
                    self._set_status("启动更新助手失败")
                    self._set_gate(f"无法启动更新安装：{exc}", "#ff6b6b")

            self.after(0, done)

        threading.Thread(target=worker, daemon=True).start()


def run_app() -> None:
    app = LauncherApp()
    app.mainloop()
