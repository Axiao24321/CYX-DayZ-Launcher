from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def app_root() -> Path:
    """开发态用源码目录；打包成 EXE 后用 exe 所在目录（配置可读写）。"""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resource_root() -> Path:
    """只读资源目录：开发态=项目根；打包后=PyInstaller 临时解压目录。"""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(getattr(sys, "_MEIPASS"))
    return Path(__file__).resolve().parent.parent


def app_icon_path(ext: str = "png") -> Path:
    return resource_root() / "assets" / f"app_icon.{ext.lstrip('.')}"


def app_background_path() -> Path:
    return resource_root() / "assets" / "launcher_background.png"


def app_asset_path(*parts: str) -> Path:
    return resource_root() / "assets" / Path(*parts)


ROOT = app_root()
SERVER_CONFIG_PATH = ROOT / "server_config.json"
LAUNCHER_CONFIG_PATH = ROOT / "launcher_config.json"

# 社区服内置列表：随启动器分发，玩家只能选择，不能改地址
BUILTIN_SERVERS: list[dict[str, Any]] = [
    {
        "id": "main",
        "label": "CYX 饥荒 简单生存",
        "server_name": "CYX 饥荒 简单生存",
        "server_ip": "202.189.15.35",
        "server_port": 2302,
        "query_port": 2305,
    },
    {
        "id": "second",
        "label": "CYX 饥荒 硬核生存",
        "server_name": "CYX 饥荒 硬核生存",
        "server_ip": "202.189.15.35",
        "server_port": 2333,
        "query_port": 2336,
    },
]

DEFAULT_LAUNCHER = {
    "player_name": "",
    "dayz_path": "",
    "steam_path": "",
    "steam_api_key": "",
    "use_battleye": True,
    "auto_check_updates_before_join": True,
    "minimize_on_join": True,
    "selected_server_id": "main",
}


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k: v for k, v in raw.items() if not str(k).startswith("_")}


def _save_json(path: Path, data: dict[str, Any], comment: str) -> None:
    out = {"_comment": comment, **data}
    with path.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
        f.write("\n")


def get_builtin_servers() -> list[dict[str, Any]]:
    """优先读同目录 server_config.json 的 servers 列表；没有则用内置默认。"""
    raw = _load_json(SERVER_CONFIG_PATH)
    servers = raw.get("servers")
    if isinstance(servers, list) and servers:
        cleaned: list[dict[str, Any]] = []
        for item in servers:
            if not isinstance(item, dict):
                continue
            cleaned.append(
                {
                    "id": str(item.get("id", "")).strip() or f"srv{len(cleaned)+1}",
                    "label": str(item.get("label", "")).strip()
                    or str(item.get("server_name", "")).strip()
                    or f"服务器{len(cleaned)+1}",
                    "server_name": str(item.get("server_name", "")).strip() or "CYX 服务器",
                    "server_ip": str(item.get("server_ip", "")).strip(),
                    "server_port": int(item.get("server_port", 2302)),
                    "query_port": int(item.get("query_port", 27016)),
                }
            )
        if cleaned:
            return cleaned
    return [dict(s) for s in BUILTIN_SERVERS]


def get_update_manifest_urls() -> list[str]:
    """读取启动器更新源，按顺序故障切换。

    优先使用新版 update_manifest_urls，同时兼容 1.2.2 及更早的
    update_manifest_url 单地址配置。
    """
    raw = _load_json(SERVER_CONFIG_PATH)
    values = raw.get("update_manifest_urls")
    candidates: list[str] = []
    if isinstance(values, list):
        candidates.extend(str(value).strip() for value in values)
    legacy = str(raw.get("update_manifest_url", "")).strip()
    if legacy:
        candidates.append(legacy)

    result: list[str] = []
    for value in candidates:
        if value and value not in result:
            result.append(value)
    return result


def get_update_manifest_url() -> str:
    """返回首选更新源，保留给旧调用方兼容。"""
    urls = get_update_manifest_urls()
    return urls[0] if urls else ""


def ensure_server_presets_file() -> None:
    """保证分发目录有一份可读的服务器列表（玩家无需编辑）。"""
    if SERVER_CONFIG_PATH.exists():
        raw = _load_json(SERVER_CONFIG_PATH)
        if isinstance(raw.get("servers"), list) and raw["servers"]:
            return
    _save_json(
        SERVER_CONFIG_PATH,
        {"servers": BUILTIN_SERVERS},
        "社区服列表（随启动器分发）。玩家端只读选择，不要改 IP/端口除非你是服主。",
    )


def resolve_selected_server(selected_id: str = "") -> dict[str, Any]:
    servers = get_builtin_servers()
    sid = (selected_id or "").strip()
    for s in servers:
        if s["id"] == sid:
            return dict(s)
    return dict(servers[0])


def load_launcher_config() -> dict[str, Any]:
    ensure_server_presets_file()
    merged = dict(DEFAULT_LAUNCHER)
    merged.update(_load_json(LAUNCHER_CONFIG_PATH))
    # 校正无效选择
    ids = {s["id"] for s in get_builtin_servers()}
    if merged.get("selected_server_id") not in ids:
        merged["selected_server_id"] = next(iter(ids))
    return merged


def save_launcher_config(data: dict[str, Any]) -> None:
    ids = {s["id"] for s in get_builtin_servers()}
    selected = str(data.get("selected_server_id", "main")).strip()
    if selected not in ids:
        selected = next(iter(ids))
    clean = {
        "player_name": str(data.get("player_name", "")).strip(),
        "dayz_path": str(data.get("dayz_path", "")).strip(),
        "steam_path": str(data.get("steam_path", "")).strip(),
        "steam_api_key": str(data.get("steam_api_key", "")).strip(),
        "use_battleye": True,
        "auto_check_updates_before_join": bool(data.get("auto_check_updates_before_join", True)),
        "minimize_on_join": bool(data.get("minimize_on_join", True)),
        "selected_server_id": selected,
    }
    _save_json(LAUNCHER_CONFIG_PATH, clean, "启动器本地设置（角色名、选中的服务器等）。")


def server_option_labels() -> list[str]:
    return [f"{s['label']}  ({s['server_ip']}:{s['server_port']})" for s in get_builtin_servers()]


def server_by_option_label(label: str) -> dict[str, Any]:
    servers = get_builtin_servers()
    options = server_option_labels()
    for opt, srv in zip(options, servers):
        if opt == label:
            return dict(srv)
    return dict(servers[0])
