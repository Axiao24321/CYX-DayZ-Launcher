from __future__ import annotations

import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path


def _bohemia_launcher_roots() -> list[Path]:
    local = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    root = local / "Bohemia_Interactive_a.s"
    if not root.is_dir():
        return []
    return sorted(
        [p for p in root.iterdir() if p.is_dir() and "DayZLauncher" in p.name],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )


def _iter_user_configs() -> list[Path]:
    files: list[Path] = []
    for launcher_root in _bohemia_launcher_roots():
        for cfg in launcher_root.rglob("user.config"):
            if cfg.is_file():
                files.append(cfg)
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files


def _setting_value(root: ET.Element, setting_name: str) -> str | None:
    for node in root.findall(".//setting"):
        if node.attrib.get("name") != setting_name:
            continue
        value = node.find("value")
        if value is None:
            continue
        return (value.text or "").strip()
    return None


def read_official_dayz_launcher_name() -> str:
    """读取官方 DayZLauncher 参数页里的 Profile Name（NameValue）。"""
    for cfg in _iter_user_configs():
        try:
            tree = ET.parse(cfg)
            root = tree.getroot()
        except ET.ParseError:
            text = cfg.read_text(encoding="utf-8", errors="ignore")
            m = re.search(
                r'<setting name="NameValue"[^>]*>\s*<value>([^<]*)</value>',
                text,
            )
            if m:
                name = m.group(1).strip()
                if name:
                    return name
            continue

        name = _setting_value(root, "NameValue")
        if name:
            return name
    return ""


def resolve_player_name(saved_name: str = "") -> tuple[str, str]:
    """
    返回 (最终名字, 来源说明)。
    - 已有本地保存：始终用 CYX 配置里的名字（玩家改过也一样）
    - 首次（本地为空）：才读官方 DayZLauncher NameValue
    """
    saved = (saved_name or "").strip()
    if saved:
        return saved, "本地保存"
    official = read_official_dayz_launcher_name().strip()
    if official:
        return official, "官方 DayZLauncher（首次）"
    return "", "空"
