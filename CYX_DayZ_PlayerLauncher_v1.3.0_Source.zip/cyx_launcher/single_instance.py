from __future__ import annotations

import ctypes
from ctypes import wintypes


ERROR_ALREADY_EXISTS = 183
SW_RESTORE = 9
MUTEX_NAME = "Local\\CYX_DayZ_PlayerLauncher_A8C7E2F1_4B3D_4E9A_9C21_7D6E5F4A3B2C"

_mutex_handle: int | None = None


def acquire_single_instance() -> bool:
    """获取启动器全局单实例锁。"""
    global _mutex_handle
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.GetLastError.restype = wintypes.DWORD

    handle = kernel32.CreateMutexW(None, False, MUTEX_NAME)
    if not handle:
        # 锁创建失败时不阻断启动，避免因系统环境异常导致启动器完全打不开。
        return True
    if kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
        kernel32.CloseHandle(handle)
        return False
    _mutex_handle = int(handle)
    return True


def activate_existing_window() -> None:
    """尝试恢复并前置已运行的启动器窗口。"""
    user32 = ctypes.windll.user32
    enum_proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def visit(hwnd: int, _lparam: int) -> bool:
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        title = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, title, length + 1)
        if "CYX Dayz 启动器" not in title.value:
            return True
        user32.ShowWindow(hwnd, SW_RESTORE)
        user32.SetForegroundWindow(hwnd)
        return False

    callback = enum_proc_type(visit)
    user32.EnumWindows(callback, 0)


def release_single_instance() -> None:
    """释放单实例锁。"""
    global _mutex_handle
    if _mutex_handle is None:
        return
    ctypes.windll.kernel32.CloseHandle(_mutex_handle)
    _mutex_handle = None
