from __future__ import annotations

import ctypes
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import requests
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .diagnostics import log_event


ProgressCallback = Callable[[int, int], None]
UPDATE_SIGNATURE_KEY_ID = "cyx-update-2026-01"
UPDATE_PUBLIC_KEY_B64 = "yFMtRlOKBLJYkP6Y+vU1Y+9oOPl3MrPIvaaBmGWbtA0="


@dataclass(frozen=True)
class UpdatePart:
    url: str
    sha256: str
    size: int
    mirrors: tuple[str, ...] = ()


@dataclass(frozen=True)
class UpdateManifest:
    version: str
    mandatory: bool
    url: str
    sha256: str
    size: int
    notes: str = ""
    parts: tuple[UpdatePart, ...] = ()
    mirrors: tuple[str, ...] = ()


def version_tuple(version: str) -> tuple[int, ...]:
    text = str(version).strip().lstrip("vV")
    parts = text.split(".")
    if not parts or any(not p.isdigit() for p in parts):
        raise ValueError(f"无效版本号：{version}")
    return tuple(int(p) for p in parts)


def is_newer_version(candidate: str, current: str) -> bool:
    left = version_tuple(candidate)
    right = version_tuple(current)
    width = max(len(left), len(right))
    return left + (0,) * (width - len(left)) > right + (0,) * (width - len(right))


def _require_https(url: str, field: str) -> str:
    value = str(url).strip()
    parsed = urlsplit(value)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise ValueError(f"{field} 必须是有效的 HTTPS 地址")
    return value


def _parse_mirrors(raw: object, field: str, primary: str) -> tuple[str, ...]:
    if raw in (None, ""):
        return ()
    if not isinstance(raw, list):
        raise ValueError(f"{field}必须是地址列表")
    result: list[str] = []
    for index, item in enumerate(raw, start=1):
        value = _require_https(str(item), f"{field} {index}")
        if value != primary and value not in result:
            result.append(value)
    return tuple(result)


def parse_manifest(raw: dict) -> UpdateManifest:
    if not isinstance(raw, dict):
        raise ValueError("更新清单格式错误")
    version = str(raw.get("version", "")).strip()
    version_tuple(version)
    url = _require_https(str(raw.get("url", "")), "安装包地址")
    mirrors = _parse_mirrors(raw.get("mirrors"), "安装包镜像", url)
    sha256 = str(raw.get("sha256", "")).strip().lower()
    if len(sha256) != 64 or any(c not in "0123456789abcdef" for c in sha256):
        raise ValueError("更新清单的 SHA-256 无效")
    size = int(raw.get("size", 0))
    if size <= 0:
        raise ValueError("更新清单的安装包大小无效")
    parts: list[UpdatePart] = []
    raw_parts = raw.get("parts", [])
    if raw_parts:
        if not isinstance(raw_parts, list):
            raise ValueError("更新清单的分片列表无效")
        for index, item in enumerate(raw_parts, start=1):
            if not isinstance(item, dict):
                raise ValueError(f"更新分片 {index} 格式无效")
            part_url = _require_https(str(item.get("url", "")), f"更新分片 {index} 地址")
            part_mirrors = _parse_mirrors(item.get("mirrors"), f"更新分片 {index} 镜像", part_url)
            part_hash = str(item.get("sha256", "")).strip().lower()
            part_size = int(item.get("size", 0))
            if len(part_hash) != 64 or any(c not in "0123456789abcdef" for c in part_hash):
                raise ValueError(f"更新分片 {index} 的 SHA-256 无效")
            if part_size <= 0:
                raise ValueError(f"更新分片 {index} 的大小无效")
            parts.append(UpdatePart(part_url, part_hash, part_size, part_mirrors))
        if sum(part.size for part in parts) != size:
            raise ValueError("更新分片总大小与安装包大小不一致")
    return UpdateManifest(
        version=version,
        mandatory=bool(raw.get("mandatory", False)),
        url=url,
        sha256=sha256,
        size=size,
        notes=str(raw.get("notes", "")).strip(),
        parts=tuple(parts),
        mirrors=mirrors,
    )


def canonical_manifest_payload(raw: dict) -> bytes:
    payload = {key: value for key, value in raw.items() if key != "signature"}
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def verify_manifest_signature(raw: dict) -> str:
    signature = raw.get("signature") if isinstance(raw, dict) else None
    if not isinstance(signature, dict):
        raise ValueError("更新清单缺少 Ed25519 签名")
    algorithm = str(signature.get("algorithm", "")).strip().lower()
    key_id = str(signature.get("key_id", "")).strip()
    encoded = str(signature.get("value", "")).strip()
    if algorithm != "ed25519":
        raise ValueError("更新清单签名算法无效")
    if key_id != UPDATE_SIGNATURE_KEY_ID:
        raise ValueError("更新清单签名密钥不受信任")
    try:
        signature_bytes = base64.b64decode(encoded, validate=True)
        public_bytes = base64.b64decode(UPDATE_PUBLIC_KEY_B64, validate=True)
        public_key = Ed25519PublicKey.from_public_bytes(public_bytes)
        public_key.verify(signature_bytes, canonical_manifest_payload(raw))
    except (ValueError, InvalidSignature) as exc:
        raise ValueError("更新清单 Ed25519 签名校验失败") from exc
    return key_id


def _cache_busted(url: str) -> str:
    parsed = urlsplit(url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query["_ts"] = str(int(time.time()))
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))


def fetch_update_manifest(url: str, timeout: float = 8.0) -> UpdateManifest:
    manifest_url = _require_https(url, "更新清单地址")
    response = requests.get(
        _cache_busted(manifest_url),
        timeout=timeout,
        headers={"User-Agent": "CYX-DayZ-Launcher-Updater/1"},
    )
    response.raise_for_status()
    try:
        raw = response.json()
    except (json.JSONDecodeError, requests.exceptions.JSONDecodeError) as exc:
        raise ValueError("更新清单不是有效 JSON") from exc
    key_id = verify_manifest_signature(raw)
    log_event(
        "update_manifest_signature_verified",
        category="updater",
        manifest_url=manifest_url,
        key_id=key_id,
        version=raw.get("version", ""),
    )
    return parse_manifest(raw)


def fetch_update_manifest_from_urls(urls: list[str] | tuple[str, ...], timeout: float = 8.0) -> UpdateManifest:
    """按配置顺序尝试更新源，主源不可用时自动切到备用源。"""
    errors: list[str] = []
    for url in urls:
        try:
            return fetch_update_manifest(url, timeout=timeout)
        except Exception as exc:
            errors.append(f"{url}: {exc}")
    if not errors:
        raise ValueError("未配置更新源")
    raise RuntimeError("所有更新源均无法连接：" + " | ".join(errors))


def download_update(
    manifest: UpdateManifest,
    progress: ProgressCallback | None = None,
    destination_dir: Path | None = None,
) -> Path:
    root = destination_dir or Path(tempfile.gettempdir()) / "CYX_DayZ_Launcher_Update"
    root.mkdir(parents=True, exist_ok=True)
    final_path = root / f"CYX_Dayz_启动器_{manifest.version}_安装包.exe"
    part_path = final_path.with_suffix(".exe.part")
    if part_path.exists():
        part_path.unlink()

    downloaded = 0
    digest = hashlib.sha256()
    chunk_paths: list[Path] = []
    try:
        sources = manifest.parts or (UpdatePart(manifest.url, manifest.sha256, manifest.size, manifest.mirrors),)
        with part_path.open("wb") as output:
            for index, source in enumerate(sources, start=1):
                chunk_path = root / f".{final_path.name}.chunk{index}"
                chunk_paths.append(chunk_path)
                source_error: Exception | None = None
                for source_url in (source.url, *source.mirrors):
                    chunk_path.unlink(missing_ok=True)
                    part_digest = hashlib.sha256()
                    part_downloaded = 0
                    try:
                        with chunk_path.open("wb") as chunk_output, requests.get(
                            source_url,
                            stream=True,
                            timeout=(10, 60),
                            headers={"User-Agent": "CYX-DayZ-Launcher-Updater/1"},
                        ) as response:
                            response.raise_for_status()
                            for chunk in response.iter_content(chunk_size=1024 * 256):
                                if not chunk:
                                    continue
                                chunk_output.write(chunk)
                                part_digest.update(chunk)
                                part_downloaded += len(chunk)
                                if part_downloaded > source.size:
                                    raise ValueError(f"更新分片 {index} 下载大小超出清单记录值")
                        if part_downloaded != source.size:
                            raise ValueError(f"更新分片 {index} 大小校验失败")
                        if part_digest.hexdigest().lower() != source.sha256:
                            raise ValueError(f"更新分片 {index} SHA-256 校验失败")
                        source_error = None
                        break
                    except Exception as exc:
                        source_error = exc
                        chunk_path.unlink(missing_ok=True)
                if source_error is not None:
                    raise source_error
                if not chunk_path.is_file():
                    raise RuntimeError(f"更新分片 {index} 的所有镜像均下载失败")

                with chunk_path.open("rb") as chunk_input:
                    while True:
                        chunk = chunk_input.read(1024 * 256)
                        if not chunk:
                            break
                        output.write(chunk)
                        digest.update(chunk)
                        downloaded += len(chunk)
                        if downloaded > manifest.size:
                            raise ValueError("安装包下载大小超出清单记录值")
                        if progress:
                            progress(downloaded, manifest.size)
                chunk_path.unlink(missing_ok=True)
        if downloaded != manifest.size:
            raise ValueError(f"安装包大小校验失败：{downloaded} / {manifest.size}")
        if digest.hexdigest().lower() != manifest.sha256:
            raise ValueError("安装包 SHA-256 校验失败，已阻止安装")
        os.replace(part_path, final_path)
        return final_path
    except Exception:
        if part_path.exists():
            part_path.unlink()
        for chunk_path in chunk_paths:
            chunk_path.unlink(missing_ok=True)
        raise


def launch_update_helper(
    installer_path: Path,
    installed_exe: Path | None = None,
    expected_version: str = "",
) -> None:
    installer = installer_path.resolve()
    target = (installed_exe or Path(sys.executable)).resolve()
    if not installer.is_file():
        raise FileNotFoundError(f"更新安装包不存在：{installer}")

    args = [
        "--apply-update",
        str(installer),
        str(os.getpid()),
        str(target),
        str(expected_version).strip(),
    ]
    if getattr(sys, "frozen", False):
        helper = Path(tempfile.gettempdir()) / f"CYX_Update_Helper_{os.getpid()}.exe"
        shutil.copy2(sys.executable, helper)
        command = [str(helper), *args]
    else:
        main_py = Path(__file__).resolve().parent.parent / "main.py"
        command = [sys.executable, str(main_py), *args]
    subprocess.Popen(command, close_fds=True)


def _wait_for_process_exit(pid: int, timeout_ms: int = 120_000) -> None:
    if os.name != "nt":
        return
    synchronize = 0x00100000
    handle = ctypes.windll.kernel32.OpenProcess(synchronize, False, int(pid))
    if not handle:
        return
    try:
        ctypes.windll.kernel32.WaitForSingleObject(handle, timeout_ms)
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def _show_helper_error(message: str) -> None:
    if os.name == "nt":
        ctypes.windll.user32.MessageBoxW(None, message, "CYX 启动器更新失败", 0x10)


def _windows_file_version(path: Path) -> str:
    if os.name != "nt" or not path.is_file():
        return ""
    size = ctypes.windll.version.GetFileVersionInfoSizeW(str(path), None)
    if not size:
        return ""
    buffer = ctypes.create_string_buffer(size)
    if not ctypes.windll.version.GetFileVersionInfoW(str(path), 0, size, buffer):
        return ""
    value = ctypes.c_void_p()
    length = ctypes.c_uint(0)
    if not ctypes.windll.version.VerQueryValueW(
        buffer,
        "\\",
        ctypes.byref(value),
        ctypes.byref(length),
    ):
        return ""
    fixed = ctypes.cast(value, ctypes.POINTER(ctypes.c_uint32 * 13)).contents
    most_significant = int(fixed[2])
    least_significant = int(fixed[3])
    return (
        f"{most_significant >> 16}.{most_significant & 0xFFFF}."
        f"{least_significant >> 16}.{least_significant & 0xFFFF}"
    )


def _version_matches(actual: str, expected: str) -> bool:
    if not expected:
        return True
    actual_tuple = version_tuple(actual)
    expected_tuple = version_tuple(expected)
    width = max(len(actual_tuple), len(expected_tuple))
    return actual_tuple + (0,) * (width - len(actual_tuple)) == expected_tuple + (0,) * (
        width - len(expected_tuple)
    )


def _restore_previous_exe(backup: Path, installed_exe: Path) -> None:
    if not backup.is_file():
        raise FileNotFoundError("找不到更新前的启动器备份")
    restore_temp = installed_exe.with_suffix(installed_exe.suffix + ".restore")
    shutil.copy2(backup, restore_temp)
    os.replace(restore_temp, installed_exe)


def run_update_helper(
    installer: Path,
    parent_pid: int,
    installed_exe: Path,
    expected_version: str = "",
) -> int:
    from .diagnostics import configure_diagnostics, log_event

    configure_diagnostics(installed_exe.resolve().parent)
    _wait_for_process_exit(parent_pid)
    backup = installer.resolve().parent / f".{installed_exe.name}.rollback"
    if installed_exe.is_file():
        shutil.copy2(installed_exe, backup)
    log_event(
        "update_install_started",
        category="updater",
        expected_version=expected_version,
        backup_created=backup.is_file(),
    )
    command = [
        str(installer),
        "/VERYSILENT",
        "/SUPPRESSMSGBOXES",
        "/NORESTART",
        "/SP-",
        "/CLOSEAPPLICATIONS",
    ]
    try:
        result = subprocess.run(command, timeout=900, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"安装程序退出码：{result.returncode}")
        if not installed_exe.is_file():
            raise FileNotFoundError("安装完成后找不到启动器主程序")
        actual_version = _windows_file_version(installed_exe)
        if expected_version and not actual_version:
            raise RuntimeError("无法读取安装后启动器版本")
        if not _version_matches(actual_version, expected_version):
            raise RuntimeError(
                f"安装后版本校验失败：期望 {expected_version}，实际 {actual_version}"
            )
        log_event(
            "update_install_verified",
            category="updater",
            expected_version=expected_version,
            actual_version=actual_version,
        )
        subprocess.Popen([str(installed_exe)], close_fds=True)
        try:
            installer.unlink(missing_ok=True)
            backup.unlink(missing_ok=True)
        except OSError:
            pass
        return 0
    except Exception as exc:
        rollback_error = None
        try:
            _restore_previous_exe(backup, installed_exe)
        except Exception as restore_exc:
            rollback_error = restore_exc
        log_event(
            "update_install_failed",
            category="updater",
            error=str(exc),
            rollback_ok=rollback_error is None,
            rollback_error=str(rollback_error or ""),
        )
        if rollback_error is None:
            detail = "已自动恢复更新前版本。"
        else:
            detail = f"自动恢复失败：{rollback_error}"
        _show_helper_error(f"新版安装失败：{exc}\n\n{detail}")
        if installed_exe.is_file():
            try:
                subprocess.Popen([str(installed_exe)], close_fds=True)
            except OSError:
                pass
        return 1


def maybe_run_update_helper(argv: list[str] | None = None) -> int | None:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] != "--apply-update":
        return None
    if len(args) not in (4, 5):
        _show_helper_error("更新助手参数不完整。")
        return 2
    try:
        expected_version = args[4] if len(args) == 5 else ""
        return run_update_helper(
            Path(args[1]),
            int(args[2]),
            Path(args[3]),
            expected_version,
        )
    except (OSError, ValueError) as exc:
        _show_helper_error(f"更新助手启动失败：{exc}")
        return 2
