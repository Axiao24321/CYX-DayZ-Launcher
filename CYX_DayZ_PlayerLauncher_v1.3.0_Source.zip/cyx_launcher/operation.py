from __future__ import annotations

import threading
from dataclasses import dataclass

from .diagnostics import new_operation_id


@dataclass(frozen=True)
class OperationToken:
    generation: int
    kind: str
    operation_id: str


class OperationController:
    """线程安全的 UI 操作代次；旧后台结果不得覆盖新操作。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._generation = 0
        self._active_kind = ""

    def begin(self, kind: str) -> OperationToken:
        with self._lock:
            self._generation += 1
            self._active_kind = str(kind)
            return OperationToken(
                generation=self._generation,
                kind=self._active_kind,
                operation_id=new_operation_id(kind),
            )

    def cancel(self) -> int:
        with self._lock:
            self._generation += 1
            self._active_kind = ""
            return self._generation

    def is_current(self, token: OperationToken | None) -> bool:
        if token is None:
            return False
        with self._lock:
            return (
                token.generation == self._generation
                and token.kind == self._active_kind
            )

    @property
    def active_kind(self) -> str:
        with self._lock:
            return self._active_kind
