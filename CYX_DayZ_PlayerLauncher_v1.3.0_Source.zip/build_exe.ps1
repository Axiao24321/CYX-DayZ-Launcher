$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

Write-Host "==> 安装打包依赖..."
python -m pip install -r requirements.txt pyinstaller -q

$dist = Join-Path $PSScriptRoot "dist"
$iconIco = Join-Path $PSScriptRoot "assets\app_icon.ico"
$iconPng = Join-Path $PSScriptRoot "assets\app_icon.png"
$backgroundPng = Join-Path $PSScriptRoot "assets\launcher_background.png"
$iconsDir = Join-Path $PSScriptRoot "assets\icons"
$versionInfo = Join-Path $PSScriptRoot "version_info.txt"
$appName = "CYX Dayz 启动器"

if (-not (Test-Path -LiteralPath $iconIco)) {
    throw "缺少图标文件: $iconIco"
}
if (-not (Test-Path -LiteralPath $backgroundPng)) {
    throw "缺少启动器背景: $backgroundPng"
}
if (-not (Test-Path -LiteralPath $iconsDir)) {
    throw "缺少 UI 图标目录: $iconsDir"
}
New-Item -ItemType Directory -Force -Path $dist | Out-Null

Write-Host "==> PyInstaller 打包单文件 EXE..."
# Windows --add-data 用分号分隔 src;dest
$dataPng = "$iconPng;assets"
$dataIco = "$iconIco;assets"
$dataBackground = "$backgroundPng;assets"
$dataIcons = "$iconsDir;assets\icons"
python -m PyInstaller `
  --noconfirm `
  --clean `
  --onefile `
  --windowed `
  --name $appName `
  --icon $iconIco `
  --version-file $versionInfo `
  --add-data $dataPng `
  --add-data $dataIco `
  --add-data $dataBackground `
  --add-data $dataIcons `
  --paths $PSScriptRoot `
  --hidden-import customtkinter `
  --hidden-import a2s `
  --hidden-import dayzquery `
  --hidden-import requests `
  --collect-all customtkinter `
  --collect-all dayzquery `
  main.py
if ($LASTEXITCODE -ne 0) {
    throw "PyInstaller 打包失败，退出码 $LASTEXITCODE"
}

# 服务器列表可覆盖；玩家本地设置（上次选服/目录）不要覆盖，避免每次打包把选择重置成默认
Copy-Item -Force "server_config.json" (Join-Path $dist "server_config.json")
$launcherCfg = Join-Path $dist "launcher_config.json"
if (-not (Test-Path -LiteralPath $launcherCfg)) {
    Copy-Item -Force "launcher_config.json" $launcherCfg
    Write-Host "已写入默认 launcher_config.json"
} else {
    Write-Host "保留已有 launcher_config.json（不覆盖玩家上次选择）"
}

$exe = Join-Path $dist "$appName.exe"
if (-not (Test-Path -LiteralPath $exe)) {
    throw "打包失败：未找到 $exe"
}

# 清理旧英文文件名，避免玩家点到旧版
$legacy = Join-Path $dist "CYX_DayZ_PlayerLauncher.exe"
if (Test-Path -LiteralPath $legacy) {
    Remove-Item -LiteralPath $legacy -Force -ErrorAction SilentlyContinue
    Write-Host "已删除旧文件: CYX_DayZ_PlayerLauncher.exe"
}

Write-Host ""
Write-Host "完成: $exe"
Write-Host "请把 dist 里的 exe 与两个 json 一起发给玩家（json 与 exe 同目录）。"
