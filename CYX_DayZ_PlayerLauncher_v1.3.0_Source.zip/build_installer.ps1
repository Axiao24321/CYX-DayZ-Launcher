$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

$iscc = Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"
if (-not (Test-Path -LiteralPath $iscc)) {
    $iscc = Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe"
}
if (-not (Test-Path -LiteralPath $iscc)) {
    throw "未找到 Inno Setup 6（ISCC.exe）。请先安装：https://jrsoftware.org/isinfo.php"
}

$appExe = Join-Path $PSScriptRoot "dist\CYX Dayz 启动器.exe"
if (-not (Test-Path -LiteralPath $appExe)) {
    Write-Host "==> 未找到已打包 EXE，先执行 build_exe.ps1 ..."
    powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "build_exe.ps1")
}
if (-not (Test-Path -LiteralPath $appExe)) {
    throw "缺少主程序: $appExe"
}

# 保证安装包内的服务器列表最新
Copy-Item -Force (Join-Path $PSScriptRoot "server_config.json") (Join-Path $PSScriptRoot "dist\server_config.json")

$iss = Join-Path $PSScriptRoot "installer\CYX_Dayz_Launcher.iss"
$outDir = Join-Path $PSScriptRoot "installer_output"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Write-Host "==> 编译 Inno Setup 安装包..."
& $iscc $iss
if ($LASTEXITCODE -ne 0) {
    throw "ISCC 编译失败，退出码 $LASTEXITCODE"
}

$setup = Get-ChildItem -LiteralPath $outDir -Filter "*.exe" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $setup) {
    throw "未生成安装包"
}

Write-Host ""
Write-Host "完成: $($setup.FullName)"
Write-Host "把这个安装包发给玩家即可（安装向导 + 桌面快捷方式 + 开始菜单 + 卸载）。"
