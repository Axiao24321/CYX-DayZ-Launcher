from cyx_launcher.updater import maybe_run_update_helper
from cyx_launcher.diagnostics import configure_diagnostics, log_event


if __name__ == "__main__":
    try:
        configure_diagnostics()
    except OSError:
        pass
    log_event("process_started")
    helper_result = maybe_run_update_helper()
    if helper_result is not None:
        raise SystemExit(helper_result)

    from cyx_launcher.ui import run_app
    from cyx_launcher.single_instance import (
        acquire_single_instance,
        activate_existing_window,
        release_single_instance,
    )

    if not acquire_single_instance():
        activate_existing_window()
    else:
        try:
            run_app()
        finally:
            release_single_instance()
