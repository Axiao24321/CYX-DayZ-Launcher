from __future__ import annotations

import argparse
import base64
import ctypes
import json
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


KEY_ID = "cyx-update-2026-01"
DEFAULT_KEY_PATH = (
    Path(os.environ.get("LOCALAPPDATA", ""))
    / "CYX Dayz Launcher Publisher"
    / "update_signing_key.dpapi"
)
CRYPTPROTECT_UI_FORBIDDEN = 0x1


class DataBlob(ctypes.Structure):
    _fields_ = [
        ("cbData", ctypes.c_uint32),
        ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
    ]


def _input_blob(data: bytes) -> tuple[DataBlob, ctypes.Array]:
    buffer = ctypes.create_string_buffer(data)
    pointer = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
    return DataBlob(len(data), pointer), buffer


def _dpapi_protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("发布签名私钥只允许使用 Windows DPAPI 保护")
    source, keepalive = _input_blob(data)
    output = DataBlob()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(source),
        "CYX Dayz Launcher update signing key",
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(output),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(output.pbData)


def _dpapi_unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("发布签名私钥只允许在创建它的 Windows 用户下使用")
    source, keepalive = _input_blob(data)
    output = DataBlob()
    description = ctypes.c_wchar_p()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(source),
        ctypes.byref(description),
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(output),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        if description:
            ctypes.windll.kernel32.LocalFree(description)
        ctypes.windll.kernel32.LocalFree(output.pbData)


def canonical_manifest_payload(raw: dict) -> bytes:
    payload = {key: value for key, value in raw.items() if key != "signature"}
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def load_private_key(path: Path = DEFAULT_KEY_PATH) -> Ed25519PrivateKey:
    if not path.is_file():
        raise FileNotFoundError(f"更新签名私钥不存在: {path}")
    raw = _dpapi_unprotect(path.read_bytes())
    return Ed25519PrivateKey.from_private_bytes(raw)


def public_key_b64(private_key: Ed25519PrivateKey) -> str:
    public = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(public).decode("ascii")


def generate_key(path: Path = DEFAULT_KEY_PATH) -> str:
    if path.exists():
        raise FileExistsError(f"拒绝覆盖已有更新签名私钥: {path}")
    key = Ed25519PrivateKey.generate()
    private_raw = key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    protected = _dpapi_protect(private_raw)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(protected)
    return public_key_b64(key)


def sign_manifest(manifest_path: Path, key_path: Path = DEFAULT_KEY_PATH) -> str:
    raw = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("更新清单必须是 JSON 对象")
    private_key = load_private_key(key_path)
    signature = private_key.sign(canonical_manifest_payload(raw))
    raw["signature"] = {
        "algorithm": "ed25519",
        "key_id": KEY_ID,
        "value": base64.b64encode(signature).decode("ascii"),
    }
    manifest_path.write_text(
        json.dumps(raw, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return public_key_b64(private_key)


def main() -> int:
    parser = argparse.ArgumentParser(description="CYX 启动器更新清单签名工具")
    parser.add_argument("action", choices=("generate", "public", "sign"))
    parser.add_argument("manifest", nargs="?", type=Path)
    parser.add_argument("--key", type=Path, default=DEFAULT_KEY_PATH)
    args = parser.parse_args()

    if args.action == "generate":
        public = generate_key(args.key)
        print(f"KEY_ID={KEY_ID}")
        print(f"PUBLIC_KEY_B64={public}")
        return 0
    if args.action == "public":
        print(f"KEY_ID={KEY_ID}")
        print(f"PUBLIC_KEY_B64={public_key_b64(load_private_key(args.key))}")
        return 0
    if args.manifest is None:
        parser.error("sign 操作需要 manifest 路径")
    public = sign_manifest(args.manifest, args.key)
    print(f"SIGNED={args.manifest}")
    print(f"KEY_ID={KEY_ID}")
    print(f"PUBLIC_KEY_B64={public}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
