import { readFile } from "node:fs/promises";
import { webcrypto } from "node:crypto";


const PUBLIC_KEY_B64 = "yFMtRlOKBLJYkP6Y+vU1Y+9oOPl3MrPIvaaBmGWbtA0=";
const KEY_ID = "cyx-update-2026-01";

const sortedValue = value => {
  if (Array.isArray(value)) return value.map(sortedValue);
  if (value && typeof value === "object") {
    return Object.keys(value).sort().reduce((result, key) => {
      result[key] = sortedValue(value[key]);
      return result;
    }, {});
  }
  return value;
};

const path = process.argv[2];
if (!path) throw new Error("需要 latest.json 路径");
const manifest = JSON.parse(await readFile(path, "utf8"));
const signature = manifest.signature;
if (!signature || signature.algorithm !== "ed25519" || signature.key_id !== KEY_ID) {
  throw new Error("签名元数据无效");
}
const unsigned = {...manifest};
delete unsigned.signature;
const payload = new TextEncoder().encode(JSON.stringify(sortedValue(unsigned)));
const key = await webcrypto.subtle.importKey(
  "raw",
  Buffer.from(PUBLIC_KEY_B64, "base64"),
  {name: "Ed25519"},
  false,
  ["verify"],
);
const valid = await webcrypto.subtle.verify(
  {name: "Ed25519"},
  key,
  Buffer.from(signature.value, "base64"),
  payload,
);
if (!valid) throw new Error("浏览器规范化签名校验失败");
console.log(`WEB_SIGNATURE_OK=${signature.key_id}`);
