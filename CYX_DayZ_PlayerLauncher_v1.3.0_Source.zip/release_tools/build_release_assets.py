from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def build_assets(
    installer: Path,
    output_dir: Path,
    version: str,
    base_url: str,
    notes: str,
    chunk_size: int,
) -> Path:
    if not installer.is_file():
        raise FileNotFoundError(installer)
    output_dir.mkdir(parents=True, exist_ok=True)
    prefix = f"CYX_Dayz_Launcher_v{version}_Setup.exe.part"
    for stale in output_dir.glob(f"{prefix}*"):
        stale.unlink()

    parts: list[dict[str, object]] = []
    with installer.open("rb") as source:
        index = 1
        while True:
            payload = source.read(chunk_size)
            if not payload:
                break
            name = f"{prefix}{index:02d}"
            path = output_dir / name
            path.write_bytes(payload)
            parts.append(
                {
                    "url": f"{base_url.rstrip('/')}/{name}",
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "size": len(payload),
                }
            )
            index += 1

    manifest = {
        "version": version,
        "mandatory": True,
        "url": parts[0]["url"],
        "sha256": sha256_file(installer),
        "size": installer.stat().st_size,
        "parts": parts,
        "notes": notes,
    }
    manifest_path = output_dir / "latest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return manifest_path


def main() -> int:
    parser = argparse.ArgumentParser(description="生成 CYX 启动器发布分片和未签名清单")
    parser.add_argument("installer", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--version", required=True)
    parser.add_argument(
        "--base-url",
        default="https://axiao24321.github.io/CYX-DayZ-Launcher",
    )
    parser.add_argument("--notes", required=True)
    parser.add_argument("--chunk-size", type=int, default=18 * 1024 * 1024)
    args = parser.parse_args()
    path = build_assets(
        args.installer,
        args.output_dir,
        args.version,
        args.base_url,
        args.notes,
        args.chunk_size,
    )
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
